"""Verify the actual delivery ZIP in fresh processes; output QA stays outside it."""
import hashlib
import csv
import argparse
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    base=ROOT/'.ml-work/incident_scenarios'
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip',required=True,help='Exact delivered ZIP to verify')
    parser.add_argument('--qa-dir',default=str(base/'robust_combination_v1/package_qa'))
    args=parser.parse_args()
    qa=Path(args.qa_dir).resolve();qa.mkdir(parents=True,exist_ok=True)
    target=Path(tempfile.mkdtemp(prefix='extracted-',dir=qa))
    archive_path=Path(args.zip).resolve()
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))
        for name in archive.namelist():
            path=PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
            dest=target.joinpath(*path.parts);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(archive.read(name))
    sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
    hashes=json.loads((target/'SHA256.json').read_text())
    assert {p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()}=={*hashes,'SHA256.json'}
    for name,digest in hashes.items():assert sha(target/name)==digest,name
    assert sha(target/'models/gas_cross_v3_bundle.zip')=='1747b09c0a289f8509b1ef066442936f315c4f7958d1815825a7f90296503e20'
    assert sha(target/'models/incident_sensor_integrated_v2.zip')=='a5cf7b2d9034cc27108992b6541eb4c9603b870cd5f36dde81ea4c963f5daccb'
    assert sha(target/'fire_candidate/model.json')=='3887d5c8663cde8c2e634fa15cdcca36a8da498df6e1ba80e9518fbe4d3d6830'
    environment={**os.environ,'PYTHONPATH':str(target),'OMP_NUM_THREADS':'4','POLARS_MAX_THREADS':'4'}
    def run(args):
        result=subprocess.run([sys.executable,'-X','utf8',*args],cwd=target,env=environment,
            capture_output=True,text=True,encoding='utf-8',timeout=90)
        if result.returncode:raise RuntimeError(result.stderr[-1800:])
    run(['-m','ml.incident_scenarios.command','--bundle','models/incident_sensor_integrated_v2.zip',
         '--journal','examples/journal.csv','--catalogue','examples/catalogue.csv','--coverage','examples/coverage.json',
         '--as-of','2025-08-15','--replay','--output','qa_sensor.json'])
    run(['-m','ml.incident_scenarios.command','--bundle','models/incident_sensor_integrated_v2.zip',
         '--daily','examples/daily.json','--catalogue','examples/catalogue.csv','--coverage','examples/coverage.json',
         '--as-of','2025-08-15','--replay','--output','qa_sensor_daily.json'])
    run(['predict_fire_candidate_with_binding.py','--sdk-root','.',
         '--daily','examples/daily.json','--catalogue','examples/catalogue.csv','--coverage','examples/coverage.json',
         '--as-of','2025-08-15','--replay','--output','qa_fire.json'])
    common=['-m','ml.incident_scenarios.combined_command','--gas-output','examples/gas_output.json',
        '--sensor-output','qa_sensor.json','--registry','examples/registry.json','--catalogue','examples/catalogue.csv',
        '--decision-at','2025-08-16T07:00:00+03:00','--recorded-gas-issued-at','2025-08-16T06:00:00+03:00']
    run([*common,'--fire-output','qa_fire.json','--output','qa_combined.json'])
    read=lambda name:json.loads((target/name).read_text(encoding='utf-8'))
    policy=read('ENABLEMENT_POLICY.json')
    assert policy['models']['fire']['enabled'] is True
    assert policy['models']['fire']['visibility']=='visible_experimental'
    assert policy['automated_action_allowed'] is False
    fire=read('qa_fire.json')
    assert fire['default_activation_allowed'] is True
    assert fire['activation_scope']=='experimental_manual_review'
    assert fire['operational_ready'] is False and fire['automated_action_allowed'] is False
    suite_status=read('reports/status.json')
    if suite_status['status']=='completed':
        CASES=('shared_baseline','missing_10pct','delay_2d','benign_only','weak_precursor',
               'no_precursor','family_C','seed_2','overlap')
        assert suite_status['bounded_suite_complete'] and not suite_status['full_archive_protocol_complete']
        for case in CASES:assert read('reports/'+case+'.json')['status']=='completed'
        with (target/'reports/quality.csv').open(encoding='utf-8-sig',newline='') as handle:
            assert len(list(csv.DictReader(handle)))==len(CASES)*2*3
    actual=read('qa_combined.json');original=read('examples/actual_three_model_replay.json')
    assert read('qa_sensor_daily.json')['predictions']==read('qa_sensor.json')['predictions']
    assert actual['gas']==original['gas']
    assert actual['evidence_context']['complete']
    for key in ('sensor_failure_output','fire_output'):
        a=sorted(actual[key]['predictions'],key=lambda row:row['entity_key'])
        b=sorted(original[key]['predictions'],key=lambda row:row['entity_key'])
        assert len(a)==len(b)
        for left,right in zip(a,b):
            assert left['model_version']==right['model_version']
            assert abs(left['score']-right['score'])<1e-12
    run([*common,'--output','qa_missing.json'])
    missing=read('qa_missing.json')
    assert missing['gas']==actual['gas'] and missing['sensor_failure_output']==actual['sensor_failure_output']
    assert not missing['evidence_context']['complete']
    assert missing['evidence_context']['workers']['fire']['status']=='unavailable'
    invalid=read('qa_sensor.json');invalid['predictions'][0]['score']=float('nan')
    (target/'invalid_sensor.json').write_text(json.dumps(invalid),encoding='utf-8')
    broken=[('invalid_sensor.json' if value=='qa_sensor.json' else value) for value in common]
    run([*broken,'--fire-output','qa_fire.json','--output','qa_invalid.json'])
    invalid_result=read('qa_invalid.json')
    assert invalid_result['gas']==actual['gas']
    assert invalid_result['evidence_context']['workers']['sensor_failure']['status']=='invalid'
    assert invalid_result['evidence_context']['workers']['fire']['status']=='available'
    # Exercise the simultaneous rule example through the packaged API itself.
    run(['-c',"import json;from ml.incident_scenarios.evidence import combine_evidence;d=json.load(open('examples/actual_inputs.json',encoding='utf-8'));s=json.load(open('examples/simultaneous_rule_fixture.json',encoding='utf-8'))['combined'];r=combine_evidence({k:v for k,v in s.items() if k not in ('sensor_failure_output','fire_output','evidence_context')},s['sensor_failure_output'],s['fire_output'],**d['combine_options']);assert any(x['code']=='VERIFY_RELEVANT_SENSOR_INDEPENDENTLY' for x in r['evidence_context']['recommendations'])"])
    result={'status':'passed','archive_sha256':sha(archive_path),'files_verified':len(hashes),
        'bounded_validation_status':suite_status['status'],
        'frozen_h2_sensor_fire_hashes':True,'fresh_process_actual_sensor_fire_predictions':True,
        'fresh_process_combined_cli':True,'gas_records_unchanged':True,'missing_worker_usable':True,
        'simultaneous_recommendation_checked':True,'raw_h2_replay':'separate actual-model acceptance in examples/acceptance.json',
        'daily_raw_binding_parity':True,'malformed_worker_isolated':True,
        'fire_enabled_experimental_manual_review':True,
        'scope':'technical acceptance on synthetic fixtures; not predictive accuracy'}
    (qa/'ACCEPTANCE.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))


if __name__=='__main__':main()
