"""Fresh-process acceptance of the exported bundle, using <=200 fixture rows."""
from __future__ import annotations

from dataclasses import asdict
from datetime import date, timedelta
import json
from pathlib import Path
import shutil
import zipfile

from .artifacts import atomic_json, verify_stage, write_stage
from .contracts import (CHANNEL, DAY, OBJECT, SENSOR_TYPE, SYSTEM_TYPE, COUNT_COLUMNS,
                        NUMERIC_COLUMNS, HEADS, Coverage, ContractError, scenario_evidence)


def canonical_fixture():
    import numpy as np
    import pandas as pd
    start, decision = date(2025, 1, 1), date(2025, 2, 15)
    types = ("Газовый датчик", "Датчик уровня воды насос", "Дверь доступа", "Состояние вентилятора")
    rows = []
    for i, kind in enumerate(types):
        for j in range(48):
            row = {DAY: start + timedelta(days=j), CHANNEL: f"fixture-channel-{i}",
                   OBJECT: "fixture-object", SENSOR_TYPE: kind, SYSTEM_TYPE: "Система вентиляции",
                   **{c: 0 for c in COUNT_COLUMNS}, **{c: np.nan for c in NUMERIC_COLUMNS},
                   "row_present": True, "source_covered": True, "numeric_missing": i != 0}
            row.update(n_events=2, n_alarm=int(j % 7 == 0))
            if i == 0:
                row.update(n_numeric=2, num_mean=.2, num_min=.1, num_max=.3,
                           num_std=.1, num_last=.3, gas_max=.3, gas_last=.3)
            rows.append(row)
    return pd.DataFrame(rows), decision, Coverage(date(2019, 1, 1), date(2026, 1, 1))


def check_bundle(bundle, expected, *, weather=None):
    import numpy as np
    from .runtime import predict_day
    daily, d, coverage = canonical_fixture()
    output = predict_day(bundle, daily, d, coverage=coverage, weather=weather,
                         replay=True, request_id="artifact-acceptance")
    fields = ("entity_key", "incident_type", "score", "eligible", "above_threshold", "model_version")
    def rows(value):
        return [{k: r[k] for k in fields} for r in value["predictions"]]
    if rows(output) != rows(expected) or set(output["head_status"]) != set(HEADS):
        raise ContractError("EXPORTED_BUNDLE_PREDICTION_MISMATCH")
    if not output["predictions"] or output["actual_min_lead_hours"] < 24:
        raise ContractError("EMPTY_OR_LATE_ACCEPTANCE")
    modified = daily.copy()
    outside = (modified[DAY] > d) | (modified[DAY] < d - timedelta(days=29))
    modified.loc[outside, "n_alarm"] = modified.loc[outside, "n_events"]
    if not (modified.loc[modified[DAY] > d, "n_alarm"] != daily.loc[daily[DAY] > d, "n_alarm"]).any():
        raise ContractError("ACCEPTANCE_FUTURE_PERTURBATION_EMPTY")
    repeated = predict_day(bundle, modified, d, coverage=coverage, weather=weather,
                           replay=True, request_id="artifact-acceptance")
    if rows(repeated) != rows(output):
        raise ContractError("FUTURE_OR_UNBOUNDED_HISTORY_LEAKAGE")
    bad = daily.copy()
    bad.loc[:, list(COUNT_COLUMNS)] = 0
    bad.loc[:, list(NUMERIC_COLUMNS)] = np.nan
    bad["source_covered"] = False
    bad["numeric_missing"] = True
    abstained = predict_day(bundle, bad, d, coverage=coverage, weather=weather, replay=True)
    if any(r["score"] is not None or r["above_threshold"] for r in abstained["predictions"]):
        raise ContractError("ABSTAIN_LEAKED_SCORE")
    try:
        predict_day(bundle, daily, d, coverage=coverage, weather=weather,
                    issued_at="2025-02-17T12:00:00+03:00")
    except ContractError as error:
        if str(error) != "LATE_RUN":
            raise
    else:
        raise ContractError("LATE_RUN_ACCEPTED")
    return {"fixture_input_rows": len(daily), "all_five_heads": True,
            "export_reload_equal": True, "finite_history_future_invariance": True,
            "source_gap_abstain": True, "late_run_rejected": True,
            "bundle_sha256": output["bundle_sha256"], "evidence": scenario_evidence()}


def stage_accept(evaluation, output, *, models, background, mode, resources, environment, code):
    evaluation, output, models = map(Path, (evaluation, output, models))
    evaluated = verify_stage(evaluation, expected_stage="04_evaluate")
    fitted = verify_stage(models, expected_stage="03_fit")
    if evaluated["parents"]["models"] != fitted["fingerprint"]:
        raise ContractError("ACCEPTANCE_LINEAGE_MISMATCH")
    for manifest in (evaluated, fitted):
        if manifest["environment"] != environment or manifest["code"] != code or manifest["config"]["mode"] != mode:
            raise ContractError("ACCEPTANCE_RUNTIME_IDENTITY_MISMATCH")
    from .pipeline import _resume, VARIANTS
    cfg = {"mode": mode, "resources": asdict(resources)}
    parents = {"evaluation": evaluated["fingerprint"], "models": fitted["fingerprint"]}
    if _resume(output, "05_accept", cfg, parents, environment, code):
        return
    from .weather import prepare_weather, load_cached_weather
    checks = {}
    for variant in VARIANTS:
        path = models / variant / "incident_scenarios_v1.zip"
        expected = json.loads((path.parent / "acceptance_expected.json").read_text(encoding="utf-8"))
        weather = prepare_weather(load_cached_weather()) if variant != "sensors_only" else None
        checks[variant] = check_bundle(path, expected, weather=weather)
        target = output / "backend_handoff" / variant
        target.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target / path.name)
        shutil.copy2(path.with_suffix(".zip.sha256"), target / (path.name + ".sha256"))
    atomic_json(output / "acceptance.json", {"checks": checks, "mode": mode,
                "deployment_status": "demo_candidate_only" if mode == "FULL" else "smoke_only_not_deliverable",
                "evidence": scenario_evidence()})
    docs = Path(__file__).resolve().parents[2] / "docs"
    for name in ("INCIDENT_SCENARIOS_PROTOCOL_RU.md", "INCIDENT_SCENARIOS_BACKEND_RU.md"):
        if (docs / name).exists():
            shutil.copy2(docs / name, output / "backend_handoff" / name)
    shutil.copytree(evaluation / "metrics", output / "backend_handoff" / "metrics", dirs_exist_ok=True)
    write_stage(output, stage="05_accept", config=cfg, parents=parents, environment=environment, code=code)
