"""Explicit raw/pseudonym aliases; metadata is never a model feature."""
import math
from .contracts import ContractError
from ml.sensor_failure.event_panel_v3 import pseudo_key


def identifier(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    text=str(value).strip()
    return text or None


def catalogue_rows(catalogue):
    if catalogue is None:return []
    if hasattr(catalogue,'to_dict'):catalogue=catalogue.to_dict('records')
    if not isinstance(catalogue,list) or any(not isinstance(row,dict) for row in catalogue):
        raise ContractError('INVALID_CATALOGUE')
    seen=set()
    for row in catalogue:
        channel=identifier(row.get('ид_канала_данных'))
        if channel is None:raise ContractError('MISSING_CATALOGUE_CHANNEL')
        if channel in seen:raise ContractError('DUPLICATE_CATALOGUE_CHANNEL')
        seen.add(channel)
    return catalogue


def aliases(catalogue):
    rows=catalogue_rows(catalogue)
    channels={};objects={}
    for row in rows:
        channel=identifier(row.get('ид_канала_данных'));obj=identifier(row.get('ид_объект'))
        channels[channel]=channel;channels[pseudo_key(channel)]=channel
        if obj is not None:objects[obj]=obj;objects[pseudo_key(obj)]=obj
    return rows,channels,objects


def bind_predictions(result,catalogue):
    _,channels,objects=aliases(catalogue)
    for row in result['predictions']:
        row['ид_канала_данных']=channels.get(identifier(row.get('d_channel_key')))
        row['ид_объект']=objects.get(identifier(row.get('d_object_key')))
    return result
