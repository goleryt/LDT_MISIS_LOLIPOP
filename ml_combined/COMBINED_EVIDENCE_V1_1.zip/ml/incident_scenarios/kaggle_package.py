"""Package reviewed source and notebook authoring assets, never project data."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile

SUPPORT_FILES = ("ml/sensor_failure/weather_data.py", "ml/sensor_failure/event_panel_v3.py",
                 "ml/sensor_failure/config/state_taxonomy_v3.json",
                 "docs/INCIDENT_SCENARIOS_PROTOCOL_RU.md", "docs/INCIDENT_SCENARIOS_BACKEND_RU.md")


def source_files(root: Path) -> list[Path]:
    package = root / "ml" / "incident_scenarios"
    files = [*package.glob("*.py"), package / "requirements.txt",
             *(root / name for name in SUPPORT_FILES), *root.glob("tests/test_incident_scenario_*.py")]
    missing = [str(p) for p in files if not p.is_file()]
    if missing:
        raise FileNotFoundError("Required source missing: " + ", ".join(missing))
    return sorted(set(files), key=lambda p: p.relative_to(root).as_posix())


def build_source_zip(root: str | Path) -> tuple[bytes, str]:
    root = Path(root).resolve()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in source_files(root):
            info = zipfile.ZipInfo(path.relative_to(root).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    data = buffer.getvalue()
    return data, hashlib.sha256(data).hexdigest()


def build_upload_package(root: str | Path, destination: str | Path) -> Path:
    from .generate_kaggle_notebooks import generate_notebooks
    root, destination = Path(root).resolve(), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    data, digest = build_source_zip(root)
    source = destination / "incident_scenarios_source.zip"
    source.write_bytes(data)
    source.with_suffix(".zip.sha256").write_text(digest + "\n", encoding="ascii")
    notebook_paths = generate_notebooks(root, destination / "notebooks", source_zip=data)
    target = destination / "incident_scenarios_kaggle_private_upload.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in [source, source.with_suffix(".zip.sha256"), *notebook_paths]:
            archive.write(path, path.relative_to(destination).as_posix())
        archive.write(root / "docs/INCIDENT_SCENARIOS_KAGGLE_RU.md", "START_HERE_RU.md")
        checksums = root / ".ml-work/incident_scenarios/INPUT_CHECKSUMS.json"
        if checksums.exists():
            archive.write(checksums, "INPUT_CHECKSUMS.json")
        archive.writestr("UPLOAD_MANIFEST.json", json.dumps({"visibility": "private",
                         "source_sha256": digest, "data_included": False, "models_included": False,
                         "stages": [p.name for p in notebook_paths]}, indent=2))
    target.with_suffix(".zip.sha256").write_text(hashlib.sha256(target.read_bytes()).hexdigest() + "\n", encoding="ascii")
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, default=Path(".ml-work/incident_scenarios/kaggle"))
    args = parser.parse_args()
    print(build_upload_package(args.root, args.output))
