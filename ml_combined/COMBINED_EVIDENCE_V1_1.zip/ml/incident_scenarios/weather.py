"""Causal city-level weather. No oracle forecasts or object coordinates."""
from __future__ import annotations

import io
from datetime import timedelta

import numpy as np
import pandas as pd

from .contracts import ContractError

RAW_COLUMNS = ("temperature_2m_mean", "temperature_2m_min", "temperature_2m_max",
               "precipitation_sum", "snowfall_sum", "wind_gusts_10m_max")
WEATHER_FEATURES = ("w_temperature_lag1", "w_min_temperature_lag1", "w_max_temperature_lag1",
                    "w_precipitation_lag1", "w_snowfall_lag1", "w_gust_lag1",
                    "w_precipitation_3d", "w_precipitation_7d", "w_snowfall_7d",
                    "w_temperature_7d", "w_freeze_thaw_7d")


def load_cached_weather() -> pd.DataFrame:
    # The source module contains a hash-checked CSV, not executable old features.
    from ml.sensor_failure.weather_data import weather_csv_bytes
    return pd.read_csv(io.BytesIO(weather_csv_bytes()))


def prepare_weather(raw: pd.DataFrame, *, availability: str = "historical_reconstruction",
                    issued_at=None) -> pd.DataFrame:
    """Row D uses calendar days at most D-1; live rows require availability times.

    ERA5 reconstruction does not establish historical publication availability.
    In live mode late observations are masked before feature construction.
    """
    if availability not in {"historical_reconstruction", "live"}:
        raise ContractError("INVALID_WEATHER_AVAILABILITY")
    missing = set(("date", *RAW_COLUMNS)) - set(raw.columns)
    if missing:
        raise ContractError("WEATHER_COLUMNS_MISSING")
    w = raw.loc[:, ["date", *RAW_COLUMNS] + (["available_at"] if "available_at" in raw else [])].copy()
    w["date"] = pd.to_datetime(w["date"]).dt.normalize()
    if w["date"].duplicated().any() or w["date"].isna().any():
        raise ContractError("INVALID_WEATHER_DATES")
    w = w.sort_values("date").set_index("date")
    w = w.reindex(pd.date_range(w.index.min(), w.index.max() + timedelta(days=1), freq="D"))
    for c in RAW_COLUMNS:
        w[c] = pd.to_numeric(w[c], errors="raise")
        if np.isinf(w[c]).any():
            raise ContractError("NONFINITE_WEATHER")
    if availability == "live":
        if "available_at" not in w or issued_at is None:
            raise ContractError("WEATHER_AVAILABILITY_REQUIRED")
        issued = pd.Timestamp(issued_at)
        if issued.tzinfo is None:
            raise ContractError("WEATHER_ISSUED_TIMEZONE_REQUIRED")
        av = pd.to_datetime(w["available_at"], utc=True)
        w.loc[av.isna() | (av > issued), list(RAW_COLUMNS)] = np.nan
    lag = w[list(RAW_COLUMNS)].shift(1)
    out = pd.DataFrame(index=w.index)
    out[list(WEATHER_FEATURES[:6])] = lag.to_numpy()
    out["w_precipitation_3d"] = lag["precipitation_sum"].rolling(3, min_periods=3).sum()
    out["w_precipitation_7d"] = lag["precipitation_sum"].rolling(7, min_periods=7).sum()
    out["w_snowfall_7d"] = lag["snowfall_sum"].rolling(7, min_periods=7).sum()
    out["w_temperature_7d"] = lag["temperature_2m_mean"].rolling(7, min_periods=7).mean()
    freeze = ((lag["temperature_2m_min"] < 0) & (lag["temperature_2m_max"] > 0)).astype(float)
    freeze.loc[lag["temperature_2m_min"].isna() | lag["temperature_2m_max"].isna()] = np.nan
    out["w_freeze_thaw_7d"] = freeze.rolling(7, min_periods=7).sum()
    out["as_of_date"] = out.index.date
    out["weather_source_mode"] = availability
    if "available_at" in w:
        out["weather_available_at"] = w["available_at"].shift(1).to_numpy()
    return out.reset_index(drop=True)


def train_weather_placebo(weather: pd.DataFrame, *, seed: int, train_start="2022-02-01", train_end="2024-01-01") -> pd.DataFrame:
    """Development-only negative control drawn exclusively from train dates."""
    dates = pd.to_datetime(weather["as_of_date"])
    pool = weather.loc[(dates >= pd.Timestamp(train_start)) & (dates < pd.Timestamp(train_end)), list(WEATHER_FEATURES)].dropna()
    if pool.empty:
        raise ContractError("EMPTY_WEATHER_PLACEBO_POOL")
    rng = np.random.default_rng(seed)
    result = weather.copy()
    # Same calendar month across train years; no future or held-out values.
    pool_month = pd.to_datetime(weather.loc[pool.index, "as_of_date"]).dt.month
    for month in range(1, 13):
        target = dates.dt.month == month
        candidates = pool.loc[pool_month == month]
        if target.any() and candidates.empty:
            raise ContractError("EMPTY_SEASON_MATCHED_PLACEBO_POOL")
        if target.any():
            result.loc[target, list(WEATHER_FEATURES)] = candidates.iloc[
                rng.integers(0, len(candidates), int(target.sum()))].to_numpy()
    result["weather_source_mode"] = "train_only_placebo"
    return result
