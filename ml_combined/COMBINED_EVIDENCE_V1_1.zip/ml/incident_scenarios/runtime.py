"""Independent bounded incident runtime; never imports the existing gas runtime."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .bundle import artifact_fingerprint, load_bundle, validate_head_transforms
from .contracts import Coverage, ContractError, HEADS, FEATURE_VERSION, SCHEMA_VERSION, as_date, forecast_times, scenario_evidence
from .models import HeadArtifact, feature_columns, predict_scores


def predict_day(bundle: dict[str, HeadArtifact] | str | Path, daily, as_of_date, *,
                coverage: Coverage | dict, weather=None, issued_at=None,
                replay: bool = False, request_id: str | None = None,
                heads: tuple[str, ...] | list[str] | None = None) -> dict[str, Any]:
    from .features import build_features
    d = as_date(as_of_date)
    cov = Coverage.from_dict(coverage) if isinstance(coverage, dict) else coverage
    if not isinstance(cov, Coverage):
        raise ContractError("COVERAGE_REQUIRED")
    cov.validate(d)
    times = forecast_times(d, issued_at, replay=replay)
    if times["late"]:
        raise ContractError("LATE_RUN")
    if weather is not None:
        from .weather import prepare_weather
        if "date" in weather.columns:
            weather = prepare_weather(weather, availability="historical_reconstruction" if replay else "live", issued_at=times["issued_at"])
        elif not replay:
            raise ContractError("LIVE_WEATHER_REQUIRES_RAW_AVAILABILITY_BINDING")
    artifacts = load_bundle(bundle) if isinstance(bundle, (str, Path)) else bundle
    if set(artifacts) != set(HEADS):
        raise ContractError("BUNDLE_REQUIRES_ALL_FIVE_HEADS")
    metadata = getattr(artifacts, "manifest", {}).get("metadata", {})
    selected_heads = tuple(metadata.get("default_enabled_heads", HEADS) if heads is None else heads)
    if (not selected_heads or len(set(selected_heads)) != len(selected_heads)
            or set(selected_heads) - set(HEADS)):
        raise ContractError("INVALID_ENABLED_HEADS")
    transforms = getattr(artifacts, "head_transforms", {})
    validate_head_transforms(artifacts, transforms)
    outputs, head_status = [], {}
    for head in selected_heads:
        transform = transforms.get(head)
        if transform:
            from .rescue_features import build_transformed_day
            frame = build_transformed_day(daily, head, cov, d)
        else:
            frame = build_features(daily, head, cov, weather=weather, as_of_date=d)
        artifact = artifacts[head]
        if artifact.head != head:
            raise ContractError("HEAD_ARTIFACT_MISMATCH")
        model_version = artifact_fingerprint(artifact, transform)
        if frame.empty:
            head_status[head] = "NO_ELIGIBLE_ENTITIES"
            continue
        if not (frame.incident_type == head).all() or not frame.as_of_date.map(as_date).eq(d).all():
            raise ContractError("FEATURE_DAY_OR_HEAD_MISMATCH")
        canonical = feature_columns(frame)
        if not set(artifact.features) <= set(canonical):
            raise ContractError("FEATURE_SCHEMA_MISMATCH")
        # Ablations share the canonical eligibility cohort; only their frozen
        # feature allowlist changes. Extras originate from the shared builder.
        model_frame = frame[[c for c in frame if not c.startswith("x_")] + artifact.features]
        scores = predict_scores(artifact, model_frame)
        head_status[head] = artifact.status
        for (_, row), score in zip(frame.iterrows(), scores):
            from .bindings import identifier
            obj=identifier(row.d_object_key)
            untrained = artifact.status == "insufficient_training_support"
            eligible = bool(row.eligible) and not untrained and obj is not None
            if not np.isfinite(score):
                raise ContractError("NONFINITE_MODEL_SCORE")
            outputs.append({"entity_key": str(row.entity_key), "d_object_key": obj,
                            "d_channel_key": identifier(row.get("d_channel_key")), "incident_type": head,
                            "score": float(score) if eligible else None,
                            "eligible": eligible, "abstain_reason": None if eligible else ("MODEL_UNTRAINED" if untrained else 'UNBOUND_CHANNEL' if obj is None else row.abstain_reason),
                            "above_threshold": bool(eligible and score >= artifact.threshold),
                            "threshold": artifact.threshold, "model_candidate": artifact.candidate,
                            "model_maturity": metadata.get("head_maturity", {}).get(head, "experimental"),
                            "feature_version": transform or FEATURE_VERSION, "model_version": model_version,
                            "input_history_days": 33 if transform else 30,
                            "request_id": request_id, **times, **scenario_evidence()})
    return {"request_id": request_id, "feature_version": FEATURE_VERSION, "schema_version": SCHEMA_VERSION,
            "bundle_sha256": getattr(artifacts, "zip_sha256", None),
            "bundle_metadata": getattr(artifacts, "manifest", {}).get("metadata", {}),
            "head_transforms": transforms,
            "enabled_heads": list(selected_heads),
            "head_status": head_status, **times, **scenario_evidence(), "predictions": outputs,
            "attention_policy": "Apply 3-day per-entity/type cooldown in the consuming demo job; no automatic action."}
