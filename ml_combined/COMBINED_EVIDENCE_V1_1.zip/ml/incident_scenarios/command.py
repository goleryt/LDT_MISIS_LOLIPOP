"""Backend entry point for the sensor research module; gas runs separately."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from .artifacts import atomic_json
from .contracts import HEADS, ContractError
from .runtime import predict_day


def read_table(path):
    path = Path(path)
    if path.suffix.lower() == '.csv':
        # Preserve journal identifiers and comma decimal strings for the taxonomy.
        return pd.read_csv(path, dtype=str, keep_default_na=False)
    return pd.DataFrame(json.loads(path.read_text(encoding='utf-8')))


def score_journal(bundle, records, catalogue, as_of_date, *, coverage, **kwargs):
    """Raw Russian journal -> shared daily builder -> selected incident head(s)."""
    from .daily import raw_to_daily, to_pandas
    from .bindings import bind_predictions
    cat = to_pandas(catalogue)
    daily = raw_to_daily(records, cat)
    result = predict_day(bundle, daily, as_of_date, coverage=coverage, **kwargs)
    # Private identifiers are returned only to the caller, never printed.
    return bind_predictions(result,cat)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', required=True)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--daily')
    inputs.add_argument('--journal')
    parser.add_argument('--catalogue')
    parser.add_argument('--coverage', required=True)
    parser.add_argument('--as-of', required=True)
    parser.add_argument('--weather')
    parser.add_argument('--issued-at')
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--request-id')
    parser.add_argument('--gas-output', help='Existing H2 runtime JSON; append context without changing gas rows')
    parser.add_argument('--head', action='append', choices=HEADS)
    parser.add_argument('--allow-experimental-heads', action='store_true')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    heads = args.head or ['sensor_failure']
    if set(heads) - {'sensor_failure'} and not args.allow_experimental_heads:
        raise ContractError('EXPERIMENTAL_HEADS_REQUIRE_EXPLICIT_OPT_IN')
    options = dict(coverage=json.loads(Path(args.coverage).read_text()),
                   weather=read_table(args.weather) if args.weather else None,
                   issued_at=args.issued_at, replay=args.replay, request_id=args.request_id,
                   heads=heads)
    if args.journal:
        if not args.catalogue:
            parser.error('--journal requires --catalogue')
        result = score_journal(args.bundle, read_table(args.journal), read_table(args.catalogue), args.as_of, **options)
    else:
        result = predict_day(args.bundle, read_table(args.daily), args.as_of, **options)
        if args.catalogue:
            from .bindings import bind_predictions
            result=bind_predictions(result,read_table(args.catalogue))
    enabled = result['enabled_heads']
    predictions = len(result['predictions'])
    if args.gas_output:
        from .gas_sensor_context import combine_product_outputs
        result = combine_product_outputs(json.loads(Path(args.gas_output).read_text(encoding='utf-8')), result)
    atomic_json(args.output, result)
    print(json.dumps({'status': 'completed', 'predictions': predictions,
                      'enabled_heads': enabled, 'output': str(Path(args.output).resolve()),
                      'operational_ready': False}))


if __name__ == '__main__':
    main()
