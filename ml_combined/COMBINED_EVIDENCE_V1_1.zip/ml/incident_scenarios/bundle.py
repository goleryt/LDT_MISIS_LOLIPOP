"""Portable JSON/text model bundles; no executable pickle payloads."""
from __future__ import annotations

from dataclasses import fields
import hashlib
import json
from pathlib import Path
import platform
import tempfile
from typing import Any
import zipfile

import numpy as np

from .contracts import ContractError, FEATURE_VERSION, HEADS, SCHEMA_VERSION, scenario_evidence
from .models import HeadArtifact


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def artifact_fingerprint(artifact: HeadArtifact, preprocessing: str | None = None) -> str:
    record = {field.name: getattr(artifact, field.name) for field in fields(artifact) if not field.name.startswith("_")}
    if preprocessing is not None:
        record["preprocessing"] = preprocessing
    return _sha(json.dumps(record, ensure_ascii=False, allow_nan=False, sort_keys=True).encode("utf-8"))


def validate_head_transforms(artifacts, transforms):
    """Never silently send a transformed model through the old feature builder."""
    from .rescue_features import TRANSFORM_VERSION, transform_config
    if not isinstance(transforms, dict) or set(transforms) - {"sensor_failure"}:
        raise ContractError("UNSUPPORTED_HEAD_TRANSFORM")
    for head, artifact in artifacts.items():
        derived = {name for name in artifact.features if name.startswith("x_rescue_")}
        version = transforms.get(head)
        if version is None:
            if derived:
                raise ContractError("MODEL_REQUIRES_HEAD_TRANSFORM")
            continue
        if version != TRANSFORM_VERSION or any(name.startswith("x_weather_") for name in artifact.features):
            raise ContractError("UNSUPPORTED_HEAD_TRANSFORM")
        expected = set()
        for signal in transform_config(head)["signals"]:
            short = signal.removeprefix("x_")
            for lag in (1, 3):
                expected.update({f"x_rescue_{short}_diff_{lag}d", f"x_rescue_{short}_relative_diff_{lag}d"})
            expected.add(f"x_rescue_{short}_ratio_7to30")
        if derived != expected:
            raise ContractError("TRANSFORM_FEATURE_SCHEMA_MISMATCH")


def _validate_model(artifact):
    n = len(artifact.features)
    if (not 1 <= n <= 64 or len(set(artifact.features)) != n
            or any(not feature.startswith("x_") for feature in artifact.features)
            or any(len(values) != n for values in (artifact.medians, artifact.means, artifact.scales))
            or not np.isfinite([*artifact.medians, *artifact.means, *artifact.scales, artifact.threshold]).all()
            or any(value <= 0 for value in artifact.scales)):
        raise ContractError("INVALID_MODEL_CONTRACT")
    if artifact.calibration.get("method") not in {"identity", "platt"}:
        raise ContractError("INVALID_CALIBRATOR")
    if artifact.calibration["method"] == "platt" and not np.isfinite([artifact.calibration.get("coefficient", np.nan), artifact.calibration.get("intercept", np.nan)]).all():
        raise ContractError("INVALID_CALIBRATOR")
    p = artifact.parameters
    if artifact.candidate == "frequency":
        valid = 0 <= p.get("prior", -1) <= 1
    elif artifact.candidate == "rule":
        valid = (len(p.get("indices", [])) == len(p.get("reference", []))
                 and all(isinstance(i, int) and 0 <= i < n for i in p.get("indices", []))
                 and all(np.isfinite(v) and v > 0 for v in p.get("reference", []))
                 and 0 <= p.get("prior", -1) <= 1)
    elif artifact.candidate == "logistic":
        valid = len(p.get("coefficients", [])) == n and np.isfinite([*p.get("coefficients", []), p.get("intercept", np.nan)]).all()
    elif artifact.candidate == "lightgbm":
        valid = bool(artifact.model_text)
    else:
        valid = False
    if not valid:
        raise ContractError("INVALID_MODEL_PARAMETERS")


class LoadedBundle(dict):
    """Mapping-compatible models with verified provenance retained for runtime."""
    manifest: dict[str, Any]
    zip_sha256: str
    head_transforms: dict[str, str]


def export_bundle(artifacts: dict[str, HeadArtifact] | list[HeadArtifact], output_dir: str | Path,
                  *, metadata: dict[str, Any] | None = None,
                  head_transforms: dict[str, str] | None = None,
                  filename: str = "incident_scenarios_v1.zip") -> Path:
    values = list(artifacts.values()) if isinstance(artifacts, dict) else list(artifacts)
    if Path(filename).name != filename or not filename.endswith(".zip"):
        raise ContractError("INVALID_BUNDLE_FILENAME")
    if set(a.head for a in values) != set(HEADS) or len(values) != len(HEADS):
        raise ContractError("BUNDLE_REQUIRES_ALL_FIVE_HEADS")
    transforms = head_transforms if head_transforms is not None else getattr(artifacts, "head_transforms", {})
    validate_head_transforms({a.head: a for a in values}, transforms)
    files = {}
    for artifact in values:
        _validate_model(artifact)
        record = {field.name: getattr(artifact, field.name) for field in fields(artifact)
                  if not field.name.startswith("_") and field.name != "model_text"}
        if artifact.model_text is not None:
            record["model_file"] = f"{artifact.head}.lgb.txt"
            files[record["model_file"]] = artifact.model_text.encode("utf-8")
        files[f"{artifact.head}.json"] = json.dumps(record, ensure_ascii=False, allow_nan=False, sort_keys=True).encode("utf-8")
    manifest = {"schema_version": SCHEMA_VERSION, "feature_version": FEATURE_VERSION,
                "python_minor": ".".join(platform.python_version_tuple()[:2]),
                "heads": list(HEADS), "files": {name: _sha(data) for name, data in files.items()},
                "metadata": metadata or {}, "evidence": scenario_evidence()}
    if transforms:
        manifest["head_transforms"] = transforms
        manifest["runtime_capability"] = "incident-head-transforms-v1"
    files["manifest.json"] = json.dumps(manifest, ensure_ascii=False, allow_nan=False, sort_keys=True).encode("utf-8")
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / filename
    with tempfile.NamedTemporaryFile(dir=directory, suffix=".zip", delete=False) as handle:
        temporary = Path(handle.name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(files.items()):
                archive.writestr(name, data)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    target.with_suffix(target.suffix + ".sha256").write_text(_sha(target.read_bytes()) + "\n", encoding="ascii")
    return target


def load_bundle(path: str | Path, *, verify_python: bool = True) -> dict[str, HeadArtifact]:
    path = Path(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    if not sidecar.is_file() or sidecar.read_text(encoding="ascii").strip() != _sha(path.read_bytes()):
        raise ContractError("BUNDLE_CHECKSUM_MISMATCH")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or any("/" in n or "\\" in n or n.startswith(".") for n in names):
            raise ContractError("UNSAFE_BUNDLE_MEMBERS")
        if sum(info.file_size for info in archive.infolist()) > 100 * 1024**2:
            raise ContractError("BUNDLE_TOO_LARGE")
        manifest = json.loads(archive.read("manifest.json"))
        if manifest.get("schema_version") != SCHEMA_VERSION or manifest.get("feature_version") != FEATURE_VERSION:
            raise ContractError("BUNDLE_SCHEMA_MISMATCH")
        if set(manifest.get("heads", [])) != set(HEADS):
            raise ContractError("BUNDLE_REQUIRES_ALL_FIVE_HEADS")
        if verify_python and manifest["python_minor"] != ".".join(platform.python_version_tuple()[:2]):
            raise ContractError("PYTHON_MINOR_MISMATCH")
        if set(names) != set(manifest["files"]) | {"manifest.json"}:
            raise ContractError("BUNDLE_FILE_LIST_MISMATCH")
        for name, checksum in manifest["files"].items():
            if _sha(archive.read(name)) != checksum:
                raise ContractError("MODEL_CHECKSUM_MISMATCH")
        out = LoadedBundle()
        out.manifest = manifest
        out.zip_sha256 = _sha(path.read_bytes())
        out.head_transforms = manifest.get("head_transforms", {})
        for head in HEADS:
            record = json.loads(archive.read(f"{head}.json"))
            model_file = record.pop("model_file", None)
            if record.get("head") != head or len(record.get("features", [])) > 64:
                raise ContractError("INVALID_MODEL_CONTRACT")
            if model_file:
                record["model_text"] = archive.read(model_file).decode("utf-8")
            out[head] = HeadArtifact(**record)
            _validate_model(out[head])
        validate_head_transforms(out, out.head_transforms)
    return out
