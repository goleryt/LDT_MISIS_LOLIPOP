"""Artifact-gated Kaggle stages. No full archive rebuild or local full training."""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from datetime import date, timedelta
import gc
import json
from pathlib import Path
import sys
import zipfile
from contextlib import nullcontext

from .artifacts import (atomic_json, check_resources, configure_threads, environment_identity,
                        fingerprint, sha256, source_identity, verify_stage, write_stage)
from .contracts import (CHANNEL, DAILY_COLUMNS, DAY, HEADS, OBJECT, PARTITIONS, PRIMARY_SEED,
                        ContractError, Coverage, GeneratorConfig, ResourceConfig, scenario_evidence)

VARIANTS = ("sensors_weather", "sensors_only", "weather_only")
N_BUCKETS = 64
BACKGROUND_MANIFEST = "event_panel_v3/panel_manifest_v3.json"


def _save(frame, path):
    import polars as pl
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp.parquet")
    pl.from_pandas(frame, include_index=False).write_parquet(temporary, compression="zstd")
    temporary.replace(path)


def _read(path):
    import polars as pl
    import pandas as pd
    frame = pl.read_parquet(path).to_pandas()
    # Arrow restores Date as datetime64, including empty partitions. Canonical
    # calendar keys are Python dates; episode timestamps retain their timezone.
    for column in (DAY, "as_of_date"):
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], errors="raise").dt.date.astype(object)
    return frame


def _variant(frame, name):
    if name not in VARIANTS:
        raise ContractError("UNKNOWN_FEATURE_VARIANT")
    return frame.drop(columns=[c for c in frame if c.startswith("x_") and
                              ((name == "sensors_only" and c.startswith("x_weather_")) or
                               (name == "weather_only" and not c.startswith("x_weather_")))])


def _resume(root, stage, cfg, parents, environment, code):
    if not (root / "stage_manifest.json").exists():
        return False
    m = verify_stage(root, expected_stage=stage)
    expected = fingerprint({"schema": m["schema"], "stage": stage, "config": cfg,
                            "parents": parents, "environment": environment, "code": code})
    if m["fingerprint"] != expected:
        raise ContractError("RESUME_FINGERPRINT_MISMATCH_USE_NEW_OUTPUT")
    print(json.dumps({"stage": stage, "status": "verified_existing_artifact"}))
    return True


def _require_parent(manifest, environment, code, mode):
    from .compatibility import upstream_code_compatible
    if manifest["environment"] != environment or not upstream_code_compatible(manifest, code) or manifest["config"]["mode"] != mode:
        raise ContractError("UPSTREAM_RUNTIME_IDENTITY_MISMATCH")


def stage_background(source, output, *, mode, resources, environment, code):
    """Extract only manifest-verified daily primitives; complete objects per shard."""
    import polars as pl
    from .daily import adapt_cached_panel
    source, output = Path(source), Path(output)
    cfg = {"mode": mode, "buckets": N_BUCKETS, "resources": asdict(resources)}
    if source.is_dir():
        candidates = [source / BACKGROUND_MANIFEST, source / "panel_manifest_v3.json"]
        found = [p for p in candidates if p.is_file()]
        if len(found) != 1:
            raise ContractError("PANEL_MANIFEST_MISSING_OR_AMBIGUOUS")
        manifest_path = found[0]
        parents = {"full_panel_manifest_sha256": sha256(manifest_path)}
    else:
        parents = {"full_panel_zip_sha256": sha256(source)}
    if _resume(output, "01_background", cfg, parents, environment, code):
        return
    output.mkdir(parents=True, exist_ok=True)
    with (nullcontext(None) if source.is_dir() else zipfile.ZipFile(source)) as archive:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if archive is None else json.loads(archive.read(BACKGROUND_MANIFEST))
        if manifest.get("mode") != "FULL" or manifest.get("status") != "completed" or manifest.get("rows") != 11_094_458:
            raise ContractError("FULL_V3_PANEL_REQUIRED")
        if manifest.get("missing_years") or not set(map(str, range(2019, 2026))) <= set(manifest["stage"]["years"]):
            raise ContractError("INCOMPLETE_SOURCE_YEAR_COVERAGE")
        panel_dir = output / "verified_input"
        panel_dir.mkdir(exist_ok=True)
        for part in manifest["parts"]:
            member = "event_panel_v3/" + part["file"]
            if Path(part["file"]).name != part["file"]:
                raise ContractError("UNSAFE_PANEL_MEMBER")
            target = panel_dir / part["file"]
            if not target.exists() or sha256(target) != part["sha256"]:
                part_path = (manifest_path.parent / part["file"]).resolve() if archive is None else None
                if part_path is not None and not part_path.is_relative_to(source.resolve()):
                    raise ContractError("UNSAFE_PANEL_MEMBER")
                with (part_path.open("rb") if archive is None else archive.open(member)) as src, target.open("wb") as dst:
                    import shutil
                    shutil.copyfileobj(src, dst, 1024 * 1024)
            if sha256(target) != part["sha256"]:
                raise ContractError("PANEL_PART_CHECKSUM_MISMATCH")
    lazy = pl.scan_parquet(str(panel_dir / "*.parquet"))
    cols = [c for c in DAILY_COLUMNS if c in lazy.collect_schema().names()]
    # Legacy zero-event grid rows are artificial, unlike explicit canonical rows.
    lazy = lazy.filter(pl.col("n_events") > 0)
    # Channel history stays with its object. No mixed-object feature shards.
    roster = (lazy.select(OBJECT).unique().collect().to_series().drop_nulls().to_list())
    import hashlib
    bucket = {v: int(hashlib.sha256(str(v).encode()).hexdigest()[:8], 16) % N_BUCKETS for v in roster}
    if mode == "SMOKE":
        from .features import GROUP_PATTERNS
        from .contracts import SENSOR_TYPE, SYSTEM_TYPE
        train = lazy.filter((pl.col(DAY) >= date(2022, 2, 1)) & (pl.col(DAY) < date(2024, 1, 1)))
        metadata = train.select(CHANNEL, OBJECT, SENSOR_TYPE, SYSTEM_TYPE).unique().collect().to_pandas()
        text = metadata[SENSOR_TYPE].fillna("") + " " + metadata[SYSTEM_TYPE].fillna("")
        keep_channels = []
        for head in HEADS:
            relevant = metadata[text.str.contains(GROUP_PATTERNS[head], case=False, regex=True)]
            if relevant.empty:
                raise ContractError("SMOKE_REQUIRED_TYPE_ABSENT:" + head)
            keep_channels.append(sorted(relevant[CHANNEL], key=lambda v: hashlib.sha256(str(v).encode()).hexdigest())[0])
        lazy = lazy.filter(pl.col(CHANNEL).is_in(keep_channels))
        bucket = {v: 0 for v in metadata.loc[metadata[CHANNEL].isin(keep_channels), OBJECT].dropna()}
    row_count = 0
    for index in sorted(set(bucket.values())):
        objects = [v for v, b in bucket.items() if b == index]
        count = lazy.filter(pl.col(OBJECT).is_in(objects)).select(pl.len()).collect().item()
        if count > resources.shard_rows:
            raise ContractError(f"BACKGROUND_SHARD_TOO_LARGE:{count}:REGISTER_MORE_BUCKETS")
        chunk = lazy.filter(pl.col(OBJECT).is_in(objects)).select(cols).collect(engine="streaming")
        # SMOKE retains the scientific partitions but only a tiny roster.
        if chunk.height > resources.shard_rows:
            raise ContractError("BACKGROUND_SHARD_TOO_LARGE_INCREASE_REGISTERED_BUCKET_COUNT")
        daily = adapt_cached_panel(chunk)
        row_count += len(daily)
        _save(daily, output / "daily" / f"part{index:03}.parquet")
        del chunk, daily
        gc.collect()
        check_resources(resources, output)
    coverage = {"start": "2019-01-01", "end_exclusive": "2026-01-01"}
    atomic_json(output / "background.json", {"coverage": coverage, "rows": row_count,
                "excluded_unmapped_object_rows": int(lazy.filter(pl.col(OBJECT).is_null()).select(pl.len()).collect().item()),
                "source_panel_manifest": manifest, "mode": mode,
                "smoke_partial_object_roster": mode == "SMOKE"})
    # Verified source copies are redundant. Keep data immutable, remove only these known files.
    for part in manifest["parts"]:
        (panel_dir / part["file"]).unlink()
    panel_dir.rmdir()
    write_stage(output, stage="01_background", config=cfg, parents=parents,
                environment=environment, code=code)


def _label_features(daily, head, generator, coverage, weather, *, frozen_heldout=None):
    import pandas as pd
    from .features import build_features
    from .simulation import generate_scenarios, apply_overlays, attach_targets, heldout_objects
    overlay, episodes, audit = generate_scenarios(daily, head, generator, coverage, frozen_heldout=frozen_heldout)
    changed = apply_overlays(daily, overlay)
    frame = attach_targets(build_features(changed, head, coverage, weather=weather), episodes)
    heldout = heldout_objects(daily, generator.heldout_object_share) if frozen_heldout is None else set(frozen_heldout)
    frame["heldout_object"] = frame[OBJECT].isin(heldout)
    episodes["heldout_object"] = episodes[OBJECT].isin(heldout)
    frame["partition"] = None
    for name, (lo, hi) in PARTITIONS.items():
        # A D+3 window must fit entirely in its declared partition.
        mask = (frame.as_of_date >= lo) & (frame.as_of_date + timedelta(days=4) <= hi)
        frame.loc[mask, "partition"] = name
    frame = frame[frame.partition.notna()].copy()
    if len(episodes):
        episode_map = episodes.copy()
        episode_map["as_of_date"] = pd.to_datetime(episode_map.onset).dt.date - timedelta(days=3)
        frame = frame.merge(episode_map[["entity_key", "as_of_date", "episode_id"]],
                            on=["entity_key", "as_of_date"], how="left", validate="one_to_one")
    else:
        frame["episode_id"] = None
    return frame, episodes, audit


def stage_scenarios(background, output, *, mode, resources, environment, code):
    from .weather import load_cached_weather, prepare_weather
    background, output = Path(background), Path(output)
    parent = verify_stage(background, expected_stage="01_background")
    _require_parent(parent, environment, code, mode)
    coverage = Coverage.from_dict(json.loads((background / "background.json").read_text())["coverage"])
    generator = GeneratorConfig()
    cfg = {"mode": mode, "generator": generator.to_dict(), "resources": asdict(resources),
           "primary_features": "sensors_weather"}
    parents = {"background": parent["fingerprint"]}
    if _resume(output, "02_scenarios", cfg, parents, environment, code):
        return
    weather = prepare_weather(load_cached_weather())
    for head in HEADS:
        for part in sorted((background / "daily").glob("*.parquet")):
            checkpoint = output / head / part.stem / "checkpoint.json"
            identity = fingerprint({"cfg": cfg, "parent": parents, "part": sha256(part), "head": head, "code": code})
            if checkpoint.exists():
                saved = json.loads(checkpoint.read_text())
                if saved["identity"] != identity or any(sha256(checkpoint.parent / p) != s for p, s in saved["files"].items()):
                    raise ContractError("SHARD_RESUME_MISMATCH")
                continue
            frame, episodes, audit = _label_features(_read(part), head, generator, coverage, weather)
            if mode == "SMOKE" and len(frame) > 20_000:
                raise ContractError("SMOKE_HEAD_ROSTER_TOO_LARGE")
            root = checkpoint.parent
            for partition in PARTITIONS:
                rows = frame[frame.partition == partition]
                if partition != "test":
                    rows = rows[~rows.heldout_object]
                _save(rows, root / f"{partition}.parquet")
                _save(episodes[episodes.partition == partition], root / f"{partition}_episodes.parquet")
            atomic_json(root / "audit.json", audit)
            files = {p.name: sha256(p) for p in root.iterdir() if p.is_file() and p.name != checkpoint.name}
            atomic_json(checkpoint, {"identity": identity, "files": files})
            del frame, episodes
            gc.collect()
            check_resources(resources, output)
        print(json.dumps({"stage": "02_scenarios", "head": head, "status": "complete"}))
    write_stage(output, stage="02_scenarios", config=cfg, parents=parents, environment=environment, code=code,
                extra={"coverage": coverage.to_dict(), "evidence": scenario_evidence()})


def _partition_frames(scenarios, head, partition):
    import pandas as pd
    files = sorted((Path(scenarios) / head).glob(f"*/{partition}.parquet"))
    return pd.concat([_read(p) for p in files], ignore_index=True) if files else pd.DataFrame()


def _episodes(scenarios, head, partition):
    import pandas as pd
    files = sorted((Path(scenarios) / head).glob(f"*/{partition}_episodes.parquet"))
    return pd.concat([_read(p) for p in files], ignore_index=True) if files else pd.DataFrame()


def _bounded_train(scenarios, head, limit, seed):
    """Uniform reservoirs per class; final weights recover declared training mixture."""
    import numpy as np
    import pandas as pd
    rng = np.random.default_rng(seed)
    reservoirs, counts = {0: [], 1: []}, {0: 0, 1: 0}
    for p in sorted((Path(scenarios) / head).glob("*/train.parquet")):
        f = _read(p)
        f = f[f.eligible].copy()
        f["_priority"] = rng.random(len(f))
        for label in (0, 1):
            rows = f[f.target == label]
            counts[label] += len(rows)
            combined = pd.concat([*reservoirs[label], rows], ignore_index=True)
            reservoirs[label] = [combined.nsmallest(limit, "_priority")]
        del f
    positive_limit = min(counts[1], limit - 1)
    sizes = {1: positive_limit, 0: min(counts[0], limit - positive_limit)}
    chunks = []
    for label in (0, 1):
        rows = reservoirs[label][0].nsmallest(sizes[label], "_priority").copy()
        rows["sample_weight"] = counts[label] / len(rows) if len(rows) else 1.0
        chunks.append(rows.drop(columns="_priority"))
    return pd.concat(chunks, ignore_index=True), {"source_rows": counts,
           "sampled_rows": sizes, "method": "uniform_class_reservoir_inverse_probability",
           "positive_group_unit": "one_D_plus_3_target_row_per_episode"}


def stage_fit(scenarios, output, *, mode, resources, environment, code):
    from .bundle import export_bundle
    from .models import fit_head
    from .evaluation import evaluate_head
    from .weather import load_cached_weather, prepare_weather, train_weather_placebo, WEATHER_FEATURES
    from .models import predict_scores
    scenarios, output = Path(scenarios), Path(output)
    parent = verify_stage(scenarios, expected_stage="02_scenarios")
    _require_parent(parent, environment, code, mode)
    cfg = {"mode": mode, "variants": VARIANTS, "resources": asdict(resources), "refit": False}
    parents = {"scenarios": parent["fingerprint"]}
    if _resume(output, "03_fit", cfg, parents, environment, code):
        return
    artifacts = {v: {} for v in VARIANTS}
    for head in HEADS:
        train, sampling = _bounded_train(scenarios, head, resources.max_train_rows, PRIMARY_SEED)
        calibration = _partition_frames(scenarios, head, "calibration")
        development = _partition_frames(scenarios, head, "development")
        episodes = _episodes(scenarios, head, "development")
        for variant in VARIANTS:
            a, report = fit_head(*[_variant(f, variant) for f in (train, calibration, development)],
                                 head, max_train_rows=resources.max_train_rows, development_episodes=episodes)
            artifacts[variant][head] = a
            report["upstream_sampling"] = sampling
            atomic_json(output / "selection" / f"{head}_{variant}.json", report)
            check_resources(resources, output)
        placebo = train_weather_placebo(prepare_weather(load_cached_weather()), seed=PRIMARY_SEED)
        dev_placebo = development.copy()
        mapping = placebo.set_index("as_of_date")
        for name in WEATHER_FEATURES:
            dev_placebo["x_weather_" + name[2:]] = dev_placebo.as_of_date.map(mapping[name])
        weather_cols = [c for c in dev_placebo if c.startswith("x_weather_") and c != "x_weather_missing"]
        dev_placebo["x_weather_missing"] = dev_placebo[weather_cols].isna().any(axis=1).astype("float32")
        dev_placebo["score"] = predict_scores(artifacts["sensors_weather"][head], dev_placebo)
        atomic_json(output / "selection" / f"{head}_development_weather_placebo.json",
                    evaluate_head(dev_placebo, episodes, head=head,
                                  threshold=artifacts["sensors_weather"][head].threshold, bootstrap_replicates=0))
        del train, calibration, development, episodes
        gc.collect()
        print(json.dumps({"stage": "03_fit", "head": head, "status": "frozen"}))
    for variant, values in artifacts.items():
        bundle = export_bundle(values, output / variant, metadata={"source_fingerprint": parent["fingerprint"],
                      "environment": environment, "resources": asdict(resources), "variant": variant})
        from .acceptance import canonical_fixture
        from .runtime import predict_day
        fixture, fixture_date, fixture_coverage = canonical_fixture()
        _save(fixture, output / variant / "acceptance_daily.parquet")
        atomic_json(output / variant / "acceptance_expected.json",
                    predict_day(values, fixture, fixture_date, coverage=fixture_coverage,
                                weather=prepare_weather(load_cached_weather()) if variant != "sensors_only" else None,
                                replay=True, request_id="artifact-acceptance"))
    write_stage(output, stage="03_fit", config=cfg, parents=parents, environment=environment, code=code)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["background", "scenarios", "fit", "evaluate", "accept"])
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--background", type=Path)
    parser.add_argument("--models", type=Path)
    parser.add_argument("--mode", choices=["SMOKE", "FULL"], default="SMOKE")
    args = parser.parse_args()
    resources = ResourceConfig()
    configure_threads(resources)
    environment = environment_identity()
    code = source_identity(Path(__file__).parent)
    shared = dict(mode=args.mode, resources=resources, environment=environment, code=code)
    if args.stage == "background":
        stage_background(args.input, args.output, **shared)
    elif args.stage == "scenarios":
        stage_scenarios(args.input, args.output, **shared)
    elif args.stage == "fit":
        stage_fit(args.input, args.output, **shared)
    elif args.stage == "evaluate":
        from .sealed_evaluation import stage_evaluate
        stage_evaluate(args.input, args.output, background=args.background, models=args.models, **shared)
    else:
        from .acceptance import stage_accept
        stage_accept(args.input, args.output, models=args.models, background=args.background, **shared)


if __name__ == "__main__":
    main()
