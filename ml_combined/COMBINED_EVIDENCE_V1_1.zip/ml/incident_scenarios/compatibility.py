"""Narrow approval for reusing immutable pre-calibration FULL artifacts.

Only the two verified stages from failed Kaggle version 4 are eligible.
Their generation code is unchanged; model fitting was not used by these stages.
Original manifests remain untouched, preserving the historical code identity.
"""

APPROVED_UPSTREAM = {
    "01_background": "b766ab92195daf9eefe4dae32a44fcdb1654be67be07f5d6bd1e1edc8e98a1a7",
    "02_scenarios": "fa4d6689602a843ac63344f09c619fff7badc19b76df8b33e5e25c7843be32ff",
}
OLD_MODELS = "c93118e8f5acaca31cb3ba4f975412396f463ca1767dd2780ce05c34c69822b8"
OLD_PIPELINE = "e866b98ab46bedc90e4be6323f2f7a729e1ac302f6c069c0994162d8c3507373"
OLD_EVALUATION = "ceeef96fdee93f887cadf5ea2c46922936f70ec11461f0574b4c82c437de936f"
RECOVERY_FIT_CODE = "a0f8dec8bc31d4a07c7c2515bab77c14852ca8362fa9c76920c8a44e316e49ee"


def trained_code_compatible(old, current):
    """Separate approval for genuine completed 03 from the fixed recovery SDK.

    No feature, sampling, fitting, calibration or model-parameter code may differ.
    Threshold counting is accepted only as the differentially tested equivalent.
    """
    from .artifacts import fingerprint
    if old == current:
        return True
    if fingerprint(old) != RECOVERY_FIT_CODE:
        return False
    allowed = {"evaluation.py", "compatibility.py", "jobs.py", "task_support.py"}
    return ({k:v for k,v in old.items() if k not in allowed}
            == {k:v for k,v in current.items() if k not in allowed})


def upstream_code_compatible(manifest, current_code):
    old = manifest["code"]
    if old == current_code:
        return True
    if (manifest.get("config", {}).get("mode") != "FULL"
            or APPROVED_UPSTREAM.get(manifest.get("stage")) != manifest.get("fingerprint")
            or old.get("models.py") != OLD_MODELS
            or old.get("pipeline.py") != OLD_PIPELINE
            or old.get("sealed_evaluation.py") != OLD_EVALUATION):
        return False
    if old.get("evaluation.py") != "048bfd830b530d90895cdbfa9ce1e3a4d66794ae7791cd63117a7e5b7d75cac8":
        return False
    allowed = {"models.py", "pipeline.py", "sealed_evaluation.py", "compatibility.py", "evaluation.py", "jobs.py", "task_support.py"}
    # pipeline changes are restricted by regression to the parent identity gate;
    # feature/label/generator/environment identities may never change here.
    return ({k: v for k, v in old.items() if k not in allowed}
            == {k: v for k, v in current_code.items() if k not in allowed}
            and all(k in current_code for k in old))
