"""Author standalone Kaggle CPU notebooks with immutable embedded source."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path

STAGES = (("00_environment_preflight", None), ("01_background", "background"),
          ("02_scenarios", "scenarios"), ("03_fit", "fit"),
          ("04_sealed_evaluate", "evaluate"), ("05_export_acceptance", "accept"))

PREFLIGHT = '''import importlib.metadata, json, platform, sys
from pathlib import Path
import numpy as np
import pandas as pd
import polars as pl
import pyarrow
import scipy
import sklearn
import lightgbm as lgb
x = np.array([[0., 0.], [1., 0.], [0., 1.], [1., 1.]], dtype=np.float32)
y = np.array([0, 1, 0, 1])
m = lgb.LGBMClassifier(n_estimators=3, min_child_samples=1, num_leaves=3, n_jobs=1, verbosity=-1)
m.fit(x, y)
restored = lgb.Booster(model_str=m.booster_.model_to_string())
assert np.allclose(m.predict_proba(x)[:, 1], restored.predict(x, num_threads=1))
sample = Path(sys.argv[2]) / 'tiny.parquet'
pl.DataFrame({'x': [1, 2]}).write_parquet(sample)
assert pl.read_parquet(sample).height == 2
sample.unlink()
packages = ('numpy', 'pandas', 'polars', 'polars-runtime-32', 'lightgbm', 'pyarrow', 'scikit-learn', 'scipy')
report = {'status': 'passed', 'tiny_fit_reload': True, 'parquet_roundtrip': True,
          'python_minor': '.'.join(platform.python_version_tuple()[:2]), 'python': sys.version,
          'platform': platform.platform(), 'libc': platform.libc_ver(),
          'packages': {p: importlib.metadata.version(p) for p in packages}}
Path(sys.argv[1]).write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({'preflight': 'passed', 'python_minor': report['python_minor'], 'packages': report['packages']}))
'''


def _cell(source, kind="code"):
    cell = {"cell_type": kind, "metadata": {}, "source": source.splitlines(keepends=True)}
    if kind == "code":
        cell.update(execution_count=None, outputs=[])
    return cell


def _source_cell(data):
    encoded = base64.b64encode(data).decode("ascii")
    digest = hashlib.sha256(data).hexdigest()
    return f'''# Standard library only in the notebook kernel.
import base64, hashlib, io, json, os, pathlib, subprocess, sys, tempfile, zipfile
SOURCE_SHA256 = {digest!r}
SOURCE_BASE64 = {encoded!r}
payload = base64.b64decode(SOURCE_BASE64, validate=True)
if hashlib.sha256(payload).hexdigest() != SOURCE_SHA256:
    raise RuntimeError("EMBEDDED_SOURCE_CHECKSUM_MISMATCH")
temporary = pathlib.Path(tempfile.mkdtemp(prefix="incident-scenarios-"))
source_root = temporary / "source"
source_root.mkdir()
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    if len(archive.namelist()) != len(set(archive.namelist())):
        raise RuntimeError("DUPLICATE_SOURCE_MEMBERS")
    for info in archive.infolist():
        name = pathlib.PurePosixPath(info.filename)
        if name.is_absolute() or ".." in name.parts or "\\\\" in info.filename or ":" in info.filename:
            raise RuntimeError("UNSAFE_SOURCE_MEMBER")
        destination = source_root.joinpath(*name.parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(archive.read(info))
sys.path.insert(0, str(source_root))
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "POLARS_MAX_THREADS"):
    os.environ[key] = "4"
os.environ["PYTHONPATH"] = str(source_root)
os.environ["PYTHONHASHSEED"] = "20261016"
from ml.incident_scenarios.bootstrap import prepare
print(json.dumps({{"source_sha256": SOURCE_SHA256, "stage": CONFIG["stage"]}}))
'''


def _config(index, name, command):
    config = {"stage": name, "mode": "SMOKE", "output": f"/kaggle/working/{name}",
              "private_outputs_required": True}
    if index:
        config.update(wheelhouse="/kaggle/input/REPLACE_PRIVATE_00_VERSION/00_environment_preflight/wheelhouse",
                      expected_wheelhouse_manifest_sha256="REPLACE_WITH_00_WHEELHOUSE_JSON_SHA256",
                      input="/kaggle/input/REPLACE_PINNED_INPUT_VERSION",
                      expected_input_fingerprint="REPLACE_WITH_UPSTREAM_STAGE_FINGERPRINT")
        if command == "background":
            config["input"] = "/kaggle/input/REPLACE_PRIVATE_FULL_V3_VERSION/results_14_v3.zip"
            config["expected_input_fingerprint"] = "REPLACE_WITH_SOURCE_ZIP_SHA256"
            config["expected_panel_manifest_sha256"] = "REPLACE_IF_INPUT_IS_EXTRACTED_DIRECTORY"
        if command in {"evaluate", "accept"}:
            config.update(background="/kaggle/input/REPLACE_PRIVATE_01_VERSION/01_background",
                          expected_background_fingerprint="REPLACE_WITH_01_FINGERPRINT",
                          models="/kaggle/input/REPLACE_PRIVATE_03_VERSION/03_fit",
                          expected_models_fingerprint="REPLACE_WITH_03_FINGERPRINT")
    return config


def _run_cell(index, command):
    if index == 0:
        return f'''output = pathlib.Path(CONFIG["output"])
output.mkdir(parents=True, exist_ok=True)
wheelhouse = output / "wheelhouse"
python = prepare(wheelhouse, temporary / "venv", online=True)
preflight = {PREFLIGHT!r}
subprocess.run([str(python), "-c", preflight, str(output / "environment.json"), str(temporary)], check=True, cwd=source_root)
report_path = output / "environment.json"
report = json.loads(report_path.read_text(encoding="utf-8"))
report["source_sha256"] = SOURCE_SHA256
report["wheelhouse_manifest_sha256"] = hashlib.sha256((wheelhouse / "wheelhouse.json").read_bytes()).hexdigest()
report["kaggle_image_commit"] = pathlib.Path("/etc/git_commit").read_text().strip() if pathlib.Path("/etc/git_commit").exists() else "unavailable"
report["kaggle_image_build_date"] = pathlib.Path("/etc/build_date").read_text().strip() if pathlib.Path("/etc/build_date").exists() else "unavailable"
report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps({{"status": "ready", "environment": str(report_path), "wheelhouse_manifest_sha256": report["wheelhouse_manifest_sha256"]}}))
'''
    return f'''def require_expected(actual, expected, label):
    if not expected or expected.startswith("REPLACE") or actual != expected:
        raise RuntimeError(label + "_FINGERPRINT_MISMATCH_OR_UNSET")
def validate_stage(path, expected, label):
    manifest = json.loads((pathlib.Path(path) / "stage_manifest.json").read_text(encoding="utf-8"))
    require_expected(manifest["fingerprint"], expected, label)
wheelhouse = pathlib.Path(CONFIG["wheelhouse"])
require_expected(hashlib.sha256((wheelhouse / "wheelhouse.json").read_bytes()).hexdigest(), CONFIG["expected_wheelhouse_manifest_sha256"], "WHEELHOUSE")
input_path = pathlib.Path(CONFIG["input"])
if {command!r} == "background":
    h = hashlib.sha256()
    if input_path.is_dir():
        found = [p for p in (input_path / "event_panel_v3/panel_manifest_v3.json", input_path / "panel_manifest_v3.json") if p.is_file()]
        if len(found) != 1:
            raise RuntimeError("PANEL_MANIFEST_MISSING_OR_AMBIGUOUS")
        fingerprint_path = found[0]
        expected = CONFIG["expected_panel_manifest_sha256"]
    else:
        fingerprint_path = input_path
        expected = CONFIG["expected_input_fingerprint"]
    with fingerprint_path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    require_expected(h.hexdigest(), expected, "SOURCE")
else:
    validate_stage(input_path, CONFIG["expected_input_fingerprint"], "INPUT")
for key in ("background", "models"):
    if key in CONFIG:
        validate_stage(CONFIG[key], CONFIG["expected_" + key + "_fingerprint"], key.upper())
python = prepare(wheelhouse, temporary / "venv", online=False)
arguments = [str(python), "-m", "ml.incident_scenarios.pipeline", {command!r}, "--input", str(input_path), "--output", CONFIG["output"], "--mode", CONFIG["mode"]]
for key in ("background", "models"):
    if key in CONFIG:
        arguments.extend(["--" + key, CONFIG[key]])
subprocess.run(arguments, check=True, cwd=source_root)
'''


def generate_notebooks(root: str | Path, output: str | Path, *, source_zip: bytes | None = None) -> list[Path]:
    if source_zip is None:
        from .kaggle_package import build_source_zip
        source_zip, _ = build_source_zip(root)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    paths = []
    for index, (name, command) in enumerate(STAGES):
        config = _config(index, name, command)
        description = ("Private Kaggle CPU execution. This stage produces versioned artifacts. "
                       "Keep notebook and outputs private. Set explicit input versions and expected hashes before running. "
                       + ("Internet ON only for wheelhouse bootstrap." if index == 0 else "Internet OFF. SMOKE metrics are not final results."))
        notebook = {"nbformat": 4, "nbformat_minor": 5,
                    "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                                 "language_info": {"name": "python"},
                                 "kaggle": {"accelerator": "none", "isInternetEnabled": index == 0, "isGpuEnabled": False}},
                    "cells": [_cell(name + "\n\n" + description, "markdown"),
                              _cell("CONFIG = " + repr(config) + "\n"),
                              _cell(_source_cell(source_zip)), _cell(_run_cell(index, command))]}
        path = output / (name + ".ipynb")
        path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8")
        paths.append(path)
    return paths


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, default=Path(".ml-work/incident_scenarios/kaggle/notebooks"))
    args = parser.parse_args()
    print("\n".join(map(str, generate_notebooks(args.root, args.output))))
