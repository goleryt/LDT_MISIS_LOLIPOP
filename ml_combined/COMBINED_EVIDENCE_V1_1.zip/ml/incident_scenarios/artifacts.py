"""Content-addressed stages, bounded resources and safe private files."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path

from .contracts import ContractError, ResourceConfig, SCHEMA_VERSION


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: str | Path, value) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     suffix=".tmp", delete=False) as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False, default=str)
        temporary = f.name
    os.replace(temporary, path)


def fingerprint(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), default=str).encode()).hexdigest()


def environment_identity() -> dict:
    from importlib.metadata import version
    packages = {p: version(p) for p in ("numpy", "pandas", "polars", "polars-runtime-32",
                                       "lightgbm", "pyarrow", "scikit-learn", "scipy")}
    return {"python_minor": f"{sys.version_info.major}.{sys.version_info.minor}",
            "platform": platform.system(), "packages": packages}


def source_identity(root: str | Path) -> dict:
    root = Path(root)
    files = {p.name: sha256(p) for p in sorted(root.glob("*.py"))}
    legacy = root.parent / "sensor_failure"
    for name in ("weather_data.py", "event_panel_v3.py", "config/state_taxonomy_v3.json"):
        files["legacy/" + name] = sha256(legacy / name)
    files["requirements.txt"] = sha256(root / "requirements.txt")
    return files


def check_resources(config: ResourceConfig, output: str | Path | None = None) -> dict:
    """Check before each bounded shard; hard fail, never trim evaluation cohorts."""
    if sys.platform.startswith("linux"):
        resident_pages = int(Path("/proc/self/statm").read_text().split()[1])
        rss = resident_pages * os.sysconf("SC_PAGE_SIZE")
    else:
        # Local fixture verification only; Kaggle uses Linux /proc above.
        import ctypes
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        handle = ctypes.windll.kernel32.GetCurrentProcess()
        if not ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
            raise ContractError("RESOURCE_MEASUREMENT_UNAVAILABLE")
        rss = counters.WorkingSetSize
    limit = config.max_rss_gib * 1024**3
    for path in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            value = Path(path).read_text().strip()
            if value != "max":
                limit = min(limit, int(value) * config.cgroup_fraction)
        except (OSError, ValueError):
            pass
    if rss > limit:
        raise ContractError("RSS_BUDGET_EXCEEDED_REDUCE_BATCH")
    output_bytes = sum(p.stat().st_size for p in Path(output).rglob("*") if p.is_file()) if output else 0
    if output_bytes > config.saved_output_budget_gib * 1024**3:
        raise ContractError("OUTPUT_BUDGET_EXCEEDED")
    return {"rss_bytes": rss, "rss_limit_bytes": int(limit), "output_bytes": output_bytes}


def configure_threads(config: ResourceConfig) -> int:
    available = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    n = min(config.max_threads, available)
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "POLARS_MAX_THREADS"):
        os.environ[name] = str(n)
    return n


def write_stage(root: str | Path, *, stage: str, config: dict, parents: dict,
                environment: dict, code: dict, extra: dict | None = None) -> dict:
    root = Path(root)
    payload = {"schema": SCHEMA_VERSION, "stage": stage, "config": config,
               "parents": parents, "environment": environment, "code": code}
    identity = fingerprint(payload)
    files = {p.relative_to(root).as_posix(): sha256(p) for p in sorted(root.rglob("*"))
             if p.is_file() and p.name != "stage_manifest.json" and not p.name.endswith(".tmp")}
    manifest = {**payload, "fingerprint": identity, "files": files, "extra": extra or {}}
    atomic_json(root / "stage_manifest.json", manifest)
    return manifest


def verify_stage(root: str | Path, *, expected_stage: str | None = None,
                 expected_fingerprint: str | None = None) -> dict:
    root = Path(root)
    m = json.loads((root / "stage_manifest.json").read_text(encoding="utf-8"))
    if m["schema"] != SCHEMA_VERSION or (expected_stage and m["stage"] != expected_stage):
        raise ContractError("STAGE_SCHEMA_MISMATCH")
    if expected_fingerprint and m["fingerprint"] != expected_fingerprint:
        raise ContractError("UPSTREAM_FINGERPRINT_MISMATCH")
    payload = {k: m[k] for k in ("schema", "stage", "config", "parents", "environment", "code")}
    if fingerprint(payload) != m["fingerprint"]:
        raise ContractError("STAGE_IDENTITY_MISMATCH")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.name != "stage_manifest.json"}
    if actual != set(m["files"]):
        raise ContractError("STAGE_FILE_LIST_MISMATCH")
    for relative, expected in m["files"].items():
        p = (root / relative).resolve()
        if not p.is_relative_to(root.resolve()) or not p.is_file() or sha256(p) != expected:
            raise ContractError("STAGE_FILE_MISMATCH")
    return m
