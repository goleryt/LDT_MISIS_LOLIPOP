"""Parallel evidence and declared recommendations; never a blended risk score."""
from copy import deepcopy
from datetime import date, datetime, time, timedelta
import math
import json
from zoneinfo import ZoneInfo

from .contracts import ContractError, TIMEZONE
from .bindings import aliases,identifier

VERSION = 'evidence-combination-v1'
IMPLEMENTATION_VERSION = 'evidence-combination-v1.1'
FIRE_TYPES = ('газ', 'дым', 'тепл', 'температ', 'пожар', 'пламен', 'извещат')


def moment(value):
    stamp = datetime.fromisoformat(str(value))
    if stamp.tzinfo is None:
        raise ContractError('EVIDENCE_TIMESTAMP_REQUIRES_TIMEZONE')
    return stamp


def boundary(value):
    if len(str(value)) == 10:
        return datetime.combine(date.fromisoformat(value), time(), ZoneInfo(TIMEZONE))
    return moment(value)


def combine_evidence(gas_output, sensor_output=None, fire_output=None, *, decision_at,
                     registry, catalogue=None, worker_issued_at=None):
    """Invalid workers are rejected from context; other forecasts remain usable.

    Legacy H2 has no issue timestamp: the caller must supply a recorded worker
    timestamp through worker_issued_at, never invent it from the cutoff date.
    """
    decision = moment(decision_at)
    supplied_times = worker_issued_at or {}
    payloads = {'gas': gas_output, 'sensor_failure': sensor_output, 'fire': fire_output}
    rejected={}
    for name,payload in payloads.items():
        try:json.dumps(payload,allow_nan=False)
        except (TypeError,ValueError,OverflowError):
            rejected[name]='NON_JSON_WORKER_PAYLOAD';payloads[name]=None
    gas_output,sensor_output,fire_output=(payloads[n] for n in ('gas','sensor_failure','fire'))
    if not isinstance(registry,dict):registry={}
    if not isinstance(registry.get('workers'),dict):registry={}
    result = deepcopy(gas_output) if isinstance(gas_output, dict) else {'gas': []}
    result['sensor_failure_output'] = deepcopy(sensor_output)
    result['fire_output'] = deepcopy(fire_output)
    statuses, records, recommendations = {}, {}, []
    valid_dates = []
    for name, payload in payloads.items():
        if payload is not None:
            try:
                valid_dates.append(date.fromisoformat(payload['as_of_date']))
            except (KeyError, TypeError, ValueError):
                pass
    # H2 is the compatibility anchor; otherwise all supplied workers must agree.
    anchor = None
    if gas_output is not None:
        try:
            anchor = date.fromisoformat(gas_output['as_of_date'])
        except (KeyError, TypeError, ValueError):
            pass
    if anchor is None and valid_dates:
        anchor = max(valid_dates)
    catalogue_error=None
    try:catalogue_rows,channel_aliases,object_aliases=aliases(catalogue)
    except (TypeError,ValueError,AttributeError):
        catalogue_rows,channel_aliases,object_aliases=[],{},{}
        catalogue_error='INVALID_OR_DUPLICATE_CATALOGUE'
    bindings = {}
    for row in catalogue_rows:
        channel = row.get('ид_канала_данных')
        if channel is None:
            continue
        channel = str(channel)
        if channel in bindings:
            catalogue_error = True
        bindings[channel] = row

    def recommend(code, refs=(), obj=None, channel=None, text='', **extra):
        recommendations.append({'code': code, 'forecast_refs': list(refs), 'd_object_key': obj,
            'channel': channel, 'text_ru': text, 'recommendation_source': 'declared_rule',
            'automated_action_allowed': False, **extra})

    def known_binding(channel, obj):
        row = bindings.get(channel)
        if row is None or catalogue_error or str(row.get('ид_объект')) != obj:
            return None
        try:
            if row.get('effective_from') and date.fromisoformat(str(row['effective_from'])[:10]) > anchor:
                return None
            if row.get('effective_to_exclusive') and date.fromisoformat(str(row['effective_to_exclusive'])[:10]) <= anchor:
                return None
            if row.get('available_at') and moment(row['available_at']) > decision:
                return None
        except (TypeError, ValueError):
            return None
        return row

    for name, payload in payloads.items():
        if payload is None:
            statuses[name] = {'status': 'invalid' if name in rejected else 'unavailable',
                              'reason': rejected.get(name,'WORKER_UNAVAILABLE')}
            records[name] = []
            continue
        try:
            if not isinstance(payload, dict):
                raise ContractError('INVALID_WORKER_PAYLOAD')
            if registry.get('schema_version') != VERSION or name not in registry.get('workers', {}):
                raise ContractError('UNSUPPORTED_EVIDENCE_VERSION')
            cutoff = date.fromisoformat(payload['as_of_date'])
            if cutoff != anchor:
                raise ContractError('EVIDENCE_CUTOFF_MISMATCH')
            spec = registry['workers'][name]
            if (not isinstance(spec,dict) or not isinstance(spec.get('model_versions'),list)
                or not spec['model_versions'] or any(not isinstance(v,str) for v in spec['model_versions'])
                or spec.get('start_offset_days') != (2 if name=='gas' else 3)):
                raise ContractError('INVALID_WORKER_REGISTRY')
            if payload.get('issued_at') and moment(payload['issued_at'])>decision:
                raise ContractError('EVIDENCE_ISSUE_TIME_INVALID')
            source = payload.get('gas', []) if name == 'gas' else payload.get('predictions', [])
            if not isinstance(source, list) or any(not isinstance(r, dict) for r in source):
                raise ContractError('INVALID_WORKER_FORECASTS')
            source = source if name == 'gas' else [r for r in source if r.get('incident_type') == name]
            seen, accepted = set(), []
            for row in source:
                if row.get('as_of_date') != str(cutoff):
                    raise ContractError('ROW_CUTOFF_MISMATCH')
                if row.get('cutoff_at') and moment(row['cutoff_at']) != datetime.combine(cutoff+timedelta(days=1),time(),ZoneInfo(TIMEZONE)):
                    raise ContractError('ROW_CUTOFF_MISMATCH')
                if row.get('model_version') not in spec['model_versions']:
                    raise ContractError('UNSUPPORTED_MODEL_VERSION')
                if spec.get('feature_versions') and row.get('feature_version') not in spec['feature_versions']:
                    raise ContractError('UNSUPPORTED_FEATURE_VERSION')
                if spec.get('feature_contract_versions') and row.get('feature_contract_version') not in spec['feature_contract_versions']:
                    raise ContractError('UNSUPPORTED_FEATURE_VERSION')
                issued = moment(row.get('issued_at') or payload.get('issued_at') or supplied_times.get(name))
                midnight = datetime.combine(cutoff+timedelta(days=1), time(), ZoneInfo(TIMEZONE))
                if issued > decision or issued < midnight:
                    raise ContractError('EVIDENCE_ISSUE_TIME_INVALID')
                start, end = boundary(row['window_start']), boundary(row['window_end_exclusive'])
                expected_start = datetime.combine(cutoff+timedelta(days=spec['start_offset_days']), time(), ZoneInfo(TIMEZONE))
                if start != expected_start or end != expected_start+timedelta(days=1):
                    raise ContractError('EVIDENCE_FORECAST_WINDOW_MISMATCH')
                if start <= decision:
                    raise ContractError('STALE_FORECAST')
                if name != 'gas' and (row.get('late') or start-issued < timedelta(hours=24)):
                    raise ContractError('INSUFFICIENT_FORECAST_LEAD')
                channel=identifier(row.get('ид_канала_данных')) or identifier(row.get('d_channel_key'))
                obj=identifier(row.get('ид_объект')) or identifier(row.get('d_object_key'))
                channel=channel_aliases.get(channel,channel);obj=object_aliases.get(obj,obj)
                entity = obj if name == 'fire' else channel
                if entity is None or str(entity) in seen:
                    raise ContractError('DUPLICATE_OR_MISSING_FORECAST_ENTITY')
                seen.add(str(entity))
                score = row.get('score')
                if name != 'gas' and (not isinstance(row.get('eligible'), bool) or not isinstance(row.get('above_threshold'), bool)):
                    raise ContractError('INVALID_ELIGIBILITY_FLAG')
                eligible = (row.get('decision_status') != 'abstain' and score is not None) if name == 'gas' else bool(row.get('eligible'))
                if eligible and (isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(score) or not 0 <= score <= 1):
                    raise ContractError('INVALID_EVIDENCE_SCORE')
                if name != 'gas' and eligible:
                    threshold = row.get('threshold')
                    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not math.isfinite(threshold) or not 0 <= threshold <= 1:
                        raise ContractError('INVALID_EVIDENCE_THRESHOLD')
                    if bool(row.get('above_threshold')) != (score >= threshold):
                        raise ContractError('EVIDENCE_THRESHOLD_MISMATCH')
                    if 'thresholds' in spec and (not isinstance(spec['thresholds'],dict) or spec['thresholds'].get(row['model_version']) != threshold):
                        raise ContractError('FROZEN_THRESHOLD_MISMATCH')
                # H2 has an existing policy; do not invent a gas threshold here.
                warning = (bool(eligible and (row.get('selected') is True or row.get('above_threshold') is True)) if name == 'gas'
                           else bool(eligible and row.get('above_threshold')))
                accepted.append({'ref': name+':'+str(entity)+':'+str(cutoff)+':'+row['model_version'], 'worker': name,
                    'entity': str(entity), 'object': None if obj is None else str(obj),
                    'channel': None if channel is None else str(channel), 'eligible': eligible,
                    'warning': warning, 'model_version': row['model_version'], 'cutoff': str(cutoff),
                    'issued_at': issued.isoformat(), 'window_start': start.isoformat(), 'window_end_exclusive': end.isoformat(),
                    'data_status': 'available' if eligible else 'abstained',
                    'reason': row.get('abstain_reason') or row.get('reason_codes') or (None if eligible else 'FORECAST_UNAVAILABLE'),
                    'score': score if eligible else None, 'threshold': row.get('threshold'),
                    'evidence_level': row.get('evidence_level', payload.get('evidence_level')),
                    'label_source': row.get('label_source', payload.get('label_source')),
                    'score_kind': row.get('score_kind', payload.get('score_kind')),
                    'target': row.get('target_code', row.get('target_description', row.get('target')))})
            records[name] = accepted
            statuses[name] = {'status': 'available' if accepted else 'empty', 'forecasts': len(accepted),
                              'availability_scope': payload.get('availability_scope', 'declared_or_reconstructed')}
        except (KeyError, TypeError, ValueError, OverflowError) as error:
            records[name] = []
            statuses[name] = {'status': 'invalid', 'reason': str(error)}
    for worker, state in statuses.items():
        if state['status'] in {'invalid', 'unavailable', 'empty'}:
            recommend('EVIDENCE_UNAVAILABLE', text='Контекст '+worker+' недоступен; отсутствие прогноза не означает безопасность.',
                      worker=worker, missing_reason=state.get('reason', 'EMPTY_COHORT'))
    missing_channel_context = []
    sensor_bindings = {(r['channel'], r['object']) for r in records['sensor_failure']}
    for row in records['gas']:
        if statuses['sensor_failure']['status'] == 'available' and (row['channel'], row['object']) not in sensor_bindings:
            missing_channel_context.append({'worker':'sensor_failure','channel':row['channel'],
                                            'object':row['object'],'reason':'CHANNEL_FORECAST_UNAVAILABLE'})
            recommend('EVIDENCE_UNAVAILABLE', [row['ref']], row['object'], row['channel'],
                      'Прогноз отказа для этого канала и объекта отсутствует; исправность датчика не установлена.',
                      worker='sensor_failure',missing_reason='CHANNEL_FORECAST_UNAVAILABLE')
        if row['warning']:
            recommend('PRESERVE_GAS_HANDLING', [row['ref']], row['object'], row['channel'],
                      'Сохранить действующий приоритет и регламент обработки газового прогноза.')
    for row in records['sensor_failure']:
        if row['warning']:
            recommend('INSPECT_SENSOR', [row['ref']], row['object'], row['channel'],
                      'Запланировать техническую проверку канала. Будущий отказ не доказывает неисправность сейчас.')
    for fire in records['fire']:
        if not fire['warning']:
            continue
        recommend('REVIEW_FIRE_EVIDENCE', [fire['ref']], fire['object'], text=
                  'Вручную проверить доступные показания газа, дыма и температуры. Это исследовательский сценарный прогноз.')
        for sensor in records['sensor_failure']:
            if not sensor['warning'] or sensor['object'] != fire['object']:
                continue
            binding = known_binding(sensor['channel'], fire['object'])
            if binding is None:
                recommend('BINDING_UNAVAILABLE', [fire['ref'], sensor['ref']], fire['object'], sensor['channel'],
                          'Связь канала с объектом на дату решения не подтверждена; совместный вывод недоступен.')
                continue
            text = str(binding.get('тип_датчика', ''))+' '+str(binding.get('тип_инж_системы', ''))
            if not text.strip():
                recommend('BINDING_UNAVAILABLE', [fire['ref'], sensor['ref']], fire['object'], sensor['channel'],
                          'Тип канала не указан; связь с пожарными признаками не установлена.')
                continue
            relevant = any(part in text.lower() for part in FIRE_TYPES)
            overlap = max(moment(fire['window_start']), moment(sensor['window_start'])) < min(moment(fire['window_end_exclusive']), moment(sensor['window_end_exclusive']))
            if relevant and overlap:
                recommend('VERIFY_RELEVANT_SENSOR_INDEPENDENTLY', [fire['ref'], sensor['ref']], fire['object'], sensor['channel'],
                          'Проверить пожарные признаки и независимо сверить этот канал; ни один прогноз не подавлять.',
                          forecast_windows_overlap=True, current_measurement_unreliable=None)
        for gas in records['gas']:
            if gas['object'] != fire['object'] or not gas['eligible']:
                continue
            if known_binding(gas['channel'], fire['object']) is None:
                recommend('BINDING_UNAVAILABLE', [gas['ref'], fire['ref']], fire['object'], gas['channel'],
                          'Связь газового канала с объектом на дату решения не подтверждена.')
                continue
            adjacent = moment(gas['window_end_exclusive']) == moment(fire['window_start'])
            if adjacent:
                recommend('ADJACENT_GAS_FIRE_WINDOWS', [gas['ref'], fire['ref']], fire['object'], gas['channel'],
                          'Газовый и пожарный прогнозы относятся к соседним окнам; показать временную шкалу без заявления независимого подтверждения.',
                          forecast_windows_overlap=False, independent_confirmation=False)
    result['evidence_context'] = {'schema_version': VERSION, 'decision_at': decision.isoformat(),
        'implementation_version':IMPLEMENTATION_VERSION,'catalogue_error':catalogue_error,
        'as_of_date': str(anchor) if anchor else None, 'workers': statuses,
        'forecasts': [row for rows in records.values() for row in rows], 'recommendations': recommendations,
        'missing_inputs': [name for name, status in statuses.items() if status['status'] != 'available'],
        'missing_channel_context': missing_channel_context,
        'complete': all(s['status'] == 'available' for s in statuses.values()),
        'all_forecasts_available': not missing_channel_context and all(s['status'] == 'available' for s in statuses.values()) and all(r['eligible'] for rows in records.values() for r in rows),
        'combined_incident_probability': None, 'gas_scores_changed': False,
        'gas_queue_order_changed': False, 'automated_action_allowed': False}
    return result
