"""Shared, versioned contracts. No training or filesystem work at import time."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta
from enum import Enum
from typing import Any
from zoneinfo import ZoneInfo

SCHEMA_VERSION = "incident-scenarios-v1"
DAILY_VERSION = "scenario-daily-v1"
FEATURE_VERSION = "scenario-bounded-30d-v1"
TIMEZONE = "Europe/Moscow"
DAY = "d_cutoff_date"
CHANNEL = "d_channel_key"
OBJECT = "d_object_key"
SENSOR_TYPE = "тип_датчика"
SYSTEM_TYPE = "тип_инж_системы"
LOOKBACK_DAYS = 30
PRIMARY_SEED = 20261016
HEADS = ("fire", "flood", "intrusion", "sensor_failure", "system_failure")
OBJECT_HEADS = frozenset(set(HEADS) - {"sensor_failure"})
COUNT_COLUMNS = ("n_events", "n_alarm", "n_link_fault", "n_power_off", "n_service", "n_tech_like", "n_numeric")
NUMERIC_COLUMNS = ("num_mean", "num_min", "num_max", "num_std", "num_last", "gas_max", "gas_last")
DAILY_COLUMNS = (DAY, CHANNEL, OBJECT, SENSOR_TYPE, SYSTEM_TYPE, *COUNT_COLUMNS,
                 *NUMERIC_COLUMNS, "row_present", "source_covered", "numeric_missing")
FORBIDDEN_FEATURE_PREFIXES = ("target_", "reason_", "d_label", "competing_", "scenario_", "latent_", "generator_")
FEATURE_PREFIX = "x_"


class ContractError(ValueError):
    """An unsafe or incompatible input, never an implicit zero-risk fallback."""


class Head(str, Enum):
    FIRE = "fire"
    FLOOD = "flood"
    INTRUSION = "intrusion"
    SENSOR_FAILURE = "sensor_failure"
    SYSTEM_FAILURE = "system_failure"


@dataclass(frozen=True)
class Coverage:
    start: date
    end_exclusive: date

    def validate(self, d: date) -> None:
        if self.end_exclusive <= self.start:
            raise ContractError("INVALID_COVERAGE")
        if self.start > d - timedelta(days=LOOKBACK_DAYS - 1) or self.end_exclusive <= d:
            raise ContractError("INSUFFICIENT_HISTORY")

    def to_dict(self) -> dict[str, str]:
        return {"start": self.start.isoformat(), "end_exclusive": self.end_exclusive.isoformat()}

    @classmethod
    def from_dict(cls, obj: dict[str, str]) -> "Coverage":
        return cls(date.fromisoformat(obj["start"]), date.fromisoformat(obj["end_exclusive"]))


@dataclass(frozen=True)
class GeneratorConfig:
    seed: int = PRIMARY_SEED
    onset_hazard: float = 0.01
    unsignaled_share: float = 0.25
    precursor_max_days: int = 7
    incident_max_days: int = 3
    recovery_max_days: int = 3
    min_onset_spacing_days: int = 13
    heldout_object_share: float = 0.20
    families: tuple[str, ...] = ("A", "B")
    challenge: str = "primary"

    def __post_init__(self) -> None:
        integers = (self.seed, self.precursor_max_days, self.incident_max_days,
                    self.recovery_max_days, self.min_onset_spacing_days)
        if any(type(v) is not int for v in integers):
            raise ContractError("GENERATOR_INTEGERS_REQUIRED")
        if not 0 <= self.onset_hazard <= 1 or not 0 <= self.unsignaled_share <= 1:
            raise ContractError("INVALID_GENERATOR_RATE")
        if not 0 <= self.heldout_object_share < 1:
            raise ContractError("INVALID_HELDOUT_SHARE")
        if self.min_onset_spacing_days < self.precursor_max_days + self.incident_max_days + self.recovery_max_days:
            raise ContractError("OVERLAPPING_SCENARIO_SPANS")
        if not self.families or not set(self.families) <= {"A", "B", "C"}:
            raise ContractError("INVALID_SCENARIO_FAMILY")
        if min(self.precursor_max_days, self.incident_max_days, self.recovery_max_days) < 1:
            raise ContractError("INVALID_SCENARIO_DURATION")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResourceConfig:
    max_threads: int = 4
    max_features: int = 64
    shard_rows: int = 500_000
    max_train_rows: int = 750_000
    evaluation_batch_rows: int = 200_000
    target_rss_gib: float = 8.0
    max_rss_gib: float = 12.0
    cgroup_fraction: float = 0.70
    saved_output_budget_gib: float = 8.0
    bootstrap_replicates: int = 200

    def __post_init__(self) -> None:
        counts = (self.max_threads, self.max_features, self.shard_rows,
                  self.max_train_rows, self.evaluation_batch_rows, self.bootstrap_replicates)
        if any(type(v) is not int or v <= 0 for v in counts):
            raise ContractError("POSITIVE_RESOURCE_INTEGERS_REQUIRED")
        if self.max_threads > 4 or self.max_features > 64:
            raise ContractError("RESOURCE_PROTOCOL_LIMIT_EXCEEDED")
        if not 0 < self.cgroup_fraction <= .70:
            raise ContractError("INVALID_CGROUP_FRACTION")
        if not 0 < self.target_rss_gib <= self.max_rss_gib <= 12:
            raise ContractError("INVALID_RSS_LIMIT")
        if not 0 < self.saved_output_budget_gib <= 8:
            raise ContractError("INVALID_OUTPUT_BUDGET")


# Execution follows artifacts/checks, not calendar deadlines. These dates are
# immutable scientific partitions of the historical background, not a schedule.
PARTITIONS: dict[str, tuple[date, date]] = {
    "train": (date(2022, 2, 1), date(2024, 1, 1)),
    "calibration": (date(2024, 1, 1), date(2024, 7, 1)),
    "development": (date(2024, 7, 1), date(2025, 1, 1)),
    "test": (date(2025, 1, 1), date(2026, 1, 1)),
}


def as_date(value: date | datetime | str) -> date:
    if isinstance(value, datetime):
        return value.date()
    return value if isinstance(value, date) else date.fromisoformat(str(value))


def forecast_times(as_of_date: date | str, issued_at: datetime | str | None = None,
                   *, replay: bool = False) -> dict[str, Any]:
    """New heads use D+3; preserve actual issue time and reject <24h notice."""
    d = as_date(as_of_date)
    tz = ZoneInfo(TIMEZONE)
    cutoff = datetime.combine(d + timedelta(days=1), time(0), tz)
    start = datetime.combine(d + timedelta(days=3), time(0), tz)
    end = datetime.combine(d + timedelta(days=4), time(0), tz)
    if issued_at is None:
        issued = datetime.combine(d + timedelta(days=1), time(6), tz) if replay else datetime.now(tz)
    elif isinstance(issued_at, str):
        issued = datetime.fromisoformat(issued_at)
    else:
        issued = issued_at
    if issued.tzinfo is None:
        raise ContractError("ISSUED_AT_REQUIRES_TIMEZONE")
    if issued < cutoff:
        raise ContractError("ISSUED_BEFORE_CUTOFF")
    lead_hours = (start - issued).total_seconds() / 3600
    return {"as_of_date": d.isoformat(), "cutoff_at": cutoff.isoformat(),
            "issued_at": issued.isoformat(), "window_start": start.isoformat(),
            "window_end_exclusive": end.isoformat(), "actual_min_lead_hours": lead_hours,
            "late": lead_hours < 24, "replay": replay}


def scenario_evidence() -> dict[str, Any]:
    return {"evidence_level": "E4", "label_source": "synthetic_scenario",
            "decision_status": "scenario_demo", "score_kind": "scenario_score",
            "operational_ready": False, "automated_action_allowed": False,
            "score_meaning": "Сценарная оценка на искусственных инцидентах поверх реальной истории; "
                             "качество на подтверждённых реальных инцидентах не установлено."}
