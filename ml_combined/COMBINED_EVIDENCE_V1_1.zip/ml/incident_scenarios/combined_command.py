"""Join independently completed worker JSONs without modifying model scores."""
import argparse
import csv
import json
from pathlib import Path

from .artifacts import atomic_json
from .evidence import combine_evidence


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gas-output')
    parser.add_argument('--sensor-output')
    parser.add_argument('--fire-output')
    parser.add_argument('--registry',required=True)
    parser.add_argument('--catalogue')
    parser.add_argument('--decision-at',required=True)
    parser.add_argument('--recorded-gas-issued-at')
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    load=lambda path:json.loads(Path(path).read_text(encoding='utf-8')) if path else None
    catalogue=None
    if args.catalogue:
        if Path(args.catalogue).suffix.lower()=='.csv':
            with open(args.catalogue,encoding='utf-8-sig',newline='') as handle:catalogue=list(csv.DictReader(handle))
        else:catalogue=load(args.catalogue)
    result=combine_evidence(load(args.gas_output),load(args.sensor_output),load(args.fire_output),
        registry=load(args.registry),catalogue=catalogue,decision_at=args.decision_at,
        worker_issued_at={'gas':args.recorded_gas_issued_at} if args.recorded_gas_issued_at else None)
    atomic_json(args.output,result)
    context=result['evidence_context']
    print(json.dumps({'status':'completed' if context['complete'] else 'partial',
        'recommendations':len(context['recommendations']),'missing_inputs':context['missing_inputs'],
        'gas_scores_changed':False,'automated_action_allowed':False}))


if __name__=='__main__':main()
