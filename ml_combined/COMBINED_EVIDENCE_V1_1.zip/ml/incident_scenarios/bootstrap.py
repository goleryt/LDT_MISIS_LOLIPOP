"""Standard-library Kaggle bootstrap. Run in kernel; scientific imports in venv."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import venv


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for part in iter(lambda: f.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def prepare(wheelhouse: Path, destination: Path, *, online: bool = False) -> Path:
    minor = f"{sys.version_info.major}.{sys.version_info.minor}"
    if minor not in {"3.12", "3.13"}:
        raise RuntimeError("UNSUPPORTED_PYTHON_MINOR")
    if online:
        wheelhouse.mkdir(parents=True, exist_ok=False)
        subprocess.run([sys.executable, "-m", "pip", "download", "--only-binary=:all:",
                        "--dest", str(wheelhouse), "-r", str(Path(__file__).with_name("requirements.txt"))], check=True)
        files = {p.name: digest(p) for p in sorted(wheelhouse.glob("*.whl"))}
        if not files:
            raise RuntimeError("EMPTY_WHEELHOUSE")
        lock = {"python_minor": minor, "platform": sys.platform, "files": files}
        (wheelhouse / "wheelhouse.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
    lock = json.loads((wheelhouse / "wheelhouse.json").read_text(encoding="utf-8"))
    if lock["python_minor"] != minor or lock["platform"] != sys.platform:
        raise RuntimeError("WHEELHOUSE_INTERPRETER_MISMATCH")
    if set(p.name for p in wheelhouse.glob("*.whl")) != set(lock["files"]):
        raise RuntimeError("WHEELHOUSE_FILE_LIST_MISMATCH")
    for name, expected in lock["files"].items():
        if Path(name).name != name or digest(wheelhouse / name) != expected:
            raise RuntimeError("WHEELHOUSE_CHECKSUM_MISMATCH")
    if destination.exists():
        raise RuntimeError("VENV_DESTINATION_MUST_BE_FRESH")
    # Kaggle's Debian Python can create a venv while ensurepip is unavailable.
    # Host pip's --python supports pip-less targets without sharing site-packages.
    venv.EnvBuilder(with_pip=False, system_site_packages=False).create(destination)
    python = destination / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    subprocess.run([sys.executable, "-m", "pip", "--python", str(python), "install", "--no-index", "--no-deps",
                    *[str(wheelhouse / name) for name in sorted(lock["files"])]], check=True)
    subprocess.run([sys.executable, "-m", "pip", "--python", str(python), "check"], check=True)
    return python


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--wheelhouse", required=True, type=Path)
    p.add_argument("--destination", required=True, type=Path)
    p.add_argument("--online", action="store_true")
    args = p.parse_args()
    prepare(args.wheelhouse, args.destination, online=args.online)
