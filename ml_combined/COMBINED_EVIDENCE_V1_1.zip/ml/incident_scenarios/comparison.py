"""Paired weather ablation on one cohort and frozen post-cooldown decisions."""
from __future__ import annotations

from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd

from .contracts import PRIMARY_SEED, ContractError
from .evaluation import _average_precision, _counts, _prepared

METRICS = ("event_precision", "event_recall", "event_f1")


def _block(obj: Any, stamp: Any) -> tuple[str, int]:
    return str(obj), pd.Timestamp(stamp).date().toordinal() // 30


def _vector_metrics(counts: np.ndarray) -> np.ndarray:
    tp, alerts, events = counts
    return np.array([tp / alerts if alerts else 0.0, tp / events if events else 0.0,
                     2 * tp / (alerts + events) if alerts + events else 0.0])


def paired_weather_comparison(sensors_frame: pd.DataFrame, weather_frame: pd.DataFrame,
                              episodes: pd.DataFrame, sensors_threshold: float,
                              weather_threshold: float, head: str, replicates: int = 200,
                              seed: int = PRIMARY_SEED) -> dict[str, Any]:
    """Weather minus sensors; paired objects and fixed 30-day calendar blocks.

    Resamples already frozen, globally matched post-cooldown counts. Every truth
    episode and its matched alert stay in the onset block together, even when
    precursor/recovery cross a block boundary. AP is descriptive on common scored
    rows; no independent-row AP interval or model refit is performed.
    """
    keys = ["incident_type", "entity_key", "as_of_date"]
    left = sensors_frame[sensors_frame.incident_type == head].sort_values(keys).reset_index(drop=True)
    right = weather_frame[weather_frame.incident_type == head].sort_values(keys).reset_index(drop=True)
    if left.duplicated(keys).any() or right.duplicated(keys).any():
        raise ContractError("DUPLICATE_PAIRED_FORECAST_ROW")
    if len(left) != len(right):
        raise ContractError("PAIRED_COHORT_MISMATCH")
    for c in [*keys, "d_object_key", "target", "eligible"]:
        a, b = left[c].copy(), right[c].copy()
        if c == "as_of_date":
            a, b = pd.to_datetime(a).dt.date, pd.to_datetime(b).dt.date
        if not a.equals(b):
            raise ContractError("PAIRED_COHORT_MISMATCH:" + c)
    if ("issued_at" in left) != ("issued_at" in right):
        raise ContractError("PAIRED_ISSUE_TIME_MISMATCH")
    if "issued_at" in left and not pd.to_datetime(left.issued_at, utc=True).equals(pd.to_datetime(right.issued_at, utc=True)):
        raise ContractError("PAIRED_ISSUE_TIME_MISMATCH")
    lframe, truth, lalerts, lmatched = _prepared(left, episodes, sensors_threshold, 3, head)
    rframe, _, ralerts, rmatched = _prepared(right, episodes, weather_threshold, 3, head)
    if not lframe.eligible.equals(rframe.eligible):
        raise ContractError("PAIRED_SCORED_COHORT_MISMATCH")
    lm, rm = _counts(lalerts, truth, lmatched), _counts(ralerts, truth, rmatched)
    delta = {m: float(rm[m] - lm[m]) for m in METRICS}
    selected = lframe.eligible.astype(bool)
    y = lframe.loc[selected, "target"].to_numpy(dtype=int)
    if not np.isin(y, [0, 1]).all():
        raise ContractError("INVALID_TARGET")
    ap = {}
    for name, f in (("sensors", lframe), ("sensors_weather", rframe)):
        p = f.loc[selected, "score"].to_numpy(dtype=float)
        if len(p) and ((p < 0).any() or (p > 1).any() or not np.isfinite(p).all()):
            raise ContractError("SCORE_OUT_OF_RANGE")
        ap[name] = _average_precision(y, p) if len(np.unique(y)) == 2 else None
    counts: dict[tuple[str, int], np.ndarray] = {}
    for row in lframe[["d_object_key", "as_of_date"]].drop_duplicates().itertuples(index=False):
        counts.setdefault(_block(row.d_object_key, pd.Timestamp(row.as_of_date) + timedelta(days=3)), np.zeros((2, 3)))
    episode_blocks = {}
    for row in truth.itertuples(index=False):
        key = _block(row.d_object_key, row.onset)
        episode_blocks[row.episode_id] = key
        counts.setdefault(key, np.zeros((2, 3)))[:, 2] += 1
    for model, alerts in enumerate((lalerts, ralerts)):
        for alert in alerts:
            episode_id = alert["matched_episode_id"]
            key = episode_blocks[episode_id] if episode_id is not None else _block(alert["d_object_key"], alert["window_start"])
            values = counts.setdefault(key, np.zeros((2, 3)))
            values[model, 1] += 1
            values[model, 0] += int(episode_id is not None)
    objects = sorted({k[0] for k in counts})
    event_objects = {k[0] for k, value in counts.items() if value[0, 2] > 0}
    ci: dict[str, Any] = {"blocks": len(counts), "objects": len(objects), "event_objects": len(event_objects),
                          "unit": "paired_objects_then_fixed_30_calendar_day_blocks_whole_episodes"}
    if replicates < 2:
        ci["status"] = "not_requested"
    elif len(counts) < 10 or len(objects) < 5 or len(event_objects) < 5:
        ci["status"] = "suppressed_insufficient_independent_blocks"
    else:
        by_object = {obj: np.stack([value for key, value in sorted(counts.items()) if key[0] == obj]) for obj in objects}
        rng, draws = np.random.default_rng(seed), []
        for _ in range(replicates):
            totals = np.zeros((2, 3))
            for obj in rng.choice(objects, len(objects), replace=True):
                blocks = by_object[obj]
                totals += blocks[rng.integers(0, len(blocks), len(blocks))].sum(axis=0)
            draws.append(_vector_metrics(totals[1]) - _vector_metrics(totals[0]))
        bounds = np.quantile(draws, [.025, .975], axis=0)
        ci.update(status="paired_hierarchical_block_bootstrap", replicates=replicates,
                  **{m: bounds[:, i].tolist() for i, m in enumerate(METRICS)})
    supported = ci.get("status") == "paired_hierarchical_block_bootstrap" and ci["event_f1"][0] > 0
    return {"incident_type": head, "comparison": "sensors_weather_minus_sensors", "same_cohort": True,
            "cohort_entity_days": len(left), "scored_entity_days": int(selected.sum()),
            "emitted_episodes": len(truth), "sensors": lm, "sensors_weather": rm, "delta": delta,
            "average_precision": {**ap, "delta_descriptive": ap["sensors_weather"] - ap["sensors"]
                                   if ap["sensors_weather"] is not None and ap["sensors"] is not None else None},
            "confidence_intervals": ci, "weather_improvement_supported": bool(supported),
            "interpretation": "Evidence concerns the declared synthetic mixture; real incident quality is unknown.",
            "bootstrap_scope": "Frozen post-cooldown matched counts; no model refit or row-independence claim."}
