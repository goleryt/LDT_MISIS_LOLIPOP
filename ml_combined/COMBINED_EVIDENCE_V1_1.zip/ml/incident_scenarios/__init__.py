"""Incident scenario demonstrator: simulated labels on real telemetry background."""

__version__ = "1.0.0"
