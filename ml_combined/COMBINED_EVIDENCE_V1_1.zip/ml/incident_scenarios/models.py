"""Bounded CPU candidates with train-only preprocessing and frozen calibration."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from .contracts import ContractError, HEADS, PRIMARY_SEED, PARTITIONS, as_date
from .evaluation import evaluate_head, select_threshold

CANDIDATES = ("frequency", "rule", "logistic", "lightgbm")


@dataclass
class HeadArtifact:
    head: str
    candidate: str
    features: list[str]
    medians: list[float]
    means: list[float]
    scales: list[float]
    parameters: dict[str, Any]
    calibration: dict[str, Any]
    threshold: float = 1.0
    model_text: str | None = None
    status: str = "fitted"
    _booster: Any = field(default=None, repr=False, compare=False)


def feature_columns(frame: pd.DataFrame) -> list[str]:
    features = sorted(c for c in frame.columns if c.startswith("x_"))
    if not features or len(features) > 64:
        raise ContractError("INVALID_FEATURE_COUNT")
    forbidden = ("target", "episode", "entity_key", "object_key", "channel_key", "scenario", "latent", "generator", "seed", "family", "lookahead", "duration", "d_label", "competing")
    if any(any(word in c for word in forbidden) or c.startswith("x_f_") for c in features):
        raise ContractError("FORBIDDEN_FEATURE")
    if any(not pd.api.types.is_numeric_dtype(frame[c]) for c in features):
        raise ContractError("NONNUMERIC_FEATURE")
    return features


def _eligible(frame, head):
    out = frame[(frame.incident_type == head) & frame.eligible.astype(bool)].copy()
    if not out.target.isin([0, 1]).all():
        raise ContractError("INVALID_TARGET")
    return out


def sample_training(frame, max_rows, seed):
    if max_rows < 2:
        raise ContractError("INVALID_TRAINING_LIMIT")
    rng = np.random.default_rng(seed)
    base_weights = frame["sample_weight"].to_numpy(dtype=float) if "sample_weight" in frame else np.ones(len(frame))
    if not np.isfinite(base_weights).all() or (base_weights <= 0).any():
        raise ContractError("INVALID_SAMPLE_WEIGHTS")
    positives = np.flatnonzero(frame.target.to_numpy() == 1)
    negatives = np.flatnonzero(frame.target.to_numpy() == 0)
    if len(frame) <= max_rows:
        return frame, base_weights, {"method": "all", "rows": len(frame), "external_weights": "sample_weight" in frame}
    if len(positives) < max_rows:
        kept_neg = rng.choice(negatives, min(len(negatives), max_rows - len(positives)), replace=False)
        indices = np.concatenate([positives, kept_neg])
        weights = np.concatenate([np.ones(len(positives)), np.full(len(kept_neg), len(negatives) / len(kept_neg))])
        return frame.iloc[indices], weights * base_weights[indices], {"method": "all_positives_weighted_negative_sample", "source_rows": len(frame), "rows": len(indices), "negative_inclusion_probability": len(kept_neg) / len(negatives), "external_weights": "sample_weight" in frame}
    # Equal-probability whole-group sampling keeps every member of selected episodes.
    groups = frame.get("episode_id", pd.Series(index=frame.index, dtype=object)).copy()
    fallback = groups.isna()
    groups = groups.astype(object)
    groups.loc[fallback] = [f"row:{i}" for i in np.flatnonzero(fallback.to_numpy())]
    codes, uniques = pd.factorize(groups)
    sizes = np.bincount(codes)
    k = min(len(uniques), max_rows // int(sizes.max()))
    if k < 1:
        raise ContractError("EPISODE_EXCEEDS_TRAINING_LIMIT")
    selected = rng.choice(len(uniques), k, replace=False)
    indices = np.flatnonzero(np.isin(codes, selected))
    probability = k / len(uniques)
    return frame.iloc[indices], base_weights[indices] / probability, {"method": "whole_episode_group_sample", "rows": len(indices), "source_rows": len(frame), "group_inclusion_probability": probability, "singleton_fallback_rows": int(fallback.sum()), "external_weights": "sample_weight" in frame}


def _matrix(artifact, frame):
    if feature_columns(frame) != artifact.features:
        raise ContractError("FEATURE_SCHEMA_MISMATCH")
    values = frame[artifact.features].to_numpy(dtype=np.float32, copy=True)
    medians = np.asarray(artifact.medians, dtype=np.float32)
    values = np.where(np.isfinite(values), values, medians)
    return values


def _raw(artifact, frame):
    x = _matrix(artifact, frame)
    if artifact.candidate == "frequency":
        return np.full(len(x), artifact.parameters["prior"], dtype=float)
    if artifact.candidate == "rule":
        ix = artifact.parameters["indices"]
        return np.clip(np.mean(np.maximum(x[:, ix], 0) / np.asarray(artifact.parameters["reference"]), axis=1), 0, 1) if ix else np.full(len(x), artifact.parameters["prior"])
    if artifact.candidate == "logistic":
        x = (x - np.asarray(artifact.means)) / np.asarray(artifact.scales)
        z = x @ np.asarray(artifact.parameters["coefficients"]) + artifact.parameters["intercept"]
        return 1 / (1 + np.exp(-np.clip(z, -700, 700)))
    if artifact.candidate == "lightgbm":
        if artifact._booster is None:
            import lightgbm as lgb
            artifact._booster = lgb.Booster(model_str=artifact.model_text)
        return np.asarray(artifact._booster.predict(x, num_threads=4))
    raise ContractError("UNKNOWN_CANDIDATE")


def _raw_scores(artifact, frame, batch_rows=200_000):
    if not 1 <= batch_rows <= 200_000:
        raise ContractError("INVALID_PREDICTION_BATCH")
    if frame.empty:
        return np.empty(0, dtype=float)
    return np.concatenate([_raw(artifact, frame.iloc[start:start + batch_rows])
                           for start in range(0, len(frame), batch_rows)])


def predict_scores(artifact: HeadArtifact, frame: pd.DataFrame, *, batch_rows: int = 200_000) -> np.ndarray:
    p = _raw_scores(artifact, frame, batch_rows)
    if artifact.calibration.get("method") == "platt":
        z = np.log(np.clip(p, 1e-7, 1 - 1e-7) / np.clip(1 - p, 1e-7, 1))
        z = artifact.calibration["coefficient"] * z + artifact.calibration["intercept"]
        p = 1 / (1 + np.exp(-np.clip(z, -700, 700)))
    return np.clip(p, 0, 1)


def _fit_platt(raw, y):
    z = np.log(np.clip(raw, 1e-7, 1 - 1e-7) / np.clip(1 - raw, 1e-7, 1))
    beta = np.array([0.0, np.log((int(y.sum()) + .5) / (len(y) - int(y.sum()) + .5))])
    def objective(value):
        logits = value[0] * z + value[1]
        return float(np.sum(np.logaddexp(0, logits) - y * logits) + .5 * value[0] ** 2)

    # Full Newton steps can overshoot into saturation with rare positives and
    # well-separated scores. Backtracking preserves the same penalized objective.
    for _ in range(200):
        p = 1 / (1 + np.exp(-np.clip(beta[0] * z + beta[1], -700, 700)))
        variance = np.maximum(p * (1 - p), 1e-12)
        gradient = np.array([np.dot(z, p - y) + beta[0], np.sum(p - y)])
        if np.max(np.abs(gradient)) < 1e-7:
            return {"method": "platt", "status": "frozen", "coefficient": float(beta[0]), "intercept": float(beta[1])}
        hessian = np.array([[np.dot(z * z, variance) + 1, np.dot(z, variance)],
                            [np.dot(z, variance), variance.sum()]])
        step = np.linalg.solve(hessian, gradient)
        decrement = float(np.dot(gradient, step))
        if decrement >= 0 and decrement < 1e-12:
            return {"method": "platt", "status": "frozen", "coefficient": float(beta[0]), "intercept": float(beta[1])}
        loss = objective(beta)
        scale = 1.0
        for _ in range(60):
            proposal = beta - scale * step
            if objective(proposal) <= loss - 1e-4 * scale * decrement:
                beta = proposal
                break
            scale *= .5
        else:
            raise ContractError("CALIBRATOR_LINE_SEARCH_FAILED")
    raise ContractError("CALIBRATOR_DID_NOT_CONVERGE")


def fit_head(train: pd.DataFrame, calibration: pd.DataFrame, development: pd.DataFrame, head: str,
             *, max_train_rows: int = 750_000, seed: int = PRIMARY_SEED,
             candidates=None, development_episodes: pd.DataFrame | None = None):
    if head not in HEADS:
        raise ContractError("UNKNOWN_HEAD")
    if development_episodes is None:
        raise ContractError("DEVELOPMENT_EPISODES_REQUIRED_FOR_EVENT_SELECTION")
    for name, frame in (("train", train), ("calibration", calibration), ("development", development)):
        start, end = PARTITIONS[name]
        dates = pd.to_datetime(frame.as_of_date, errors="raise")
        if dates.isna().any() or not ((dates >= pd.Timestamp(start)) & (dates < pd.Timestamp(end))).all():
            raise ContractError("PARTITION_DATE_MISMATCH")
        if "partition" in frame and not (frame.partition == name).all():
            raise ContractError("PARTITION_METADATA_MISMATCH")
        if "family" in frame and (frame.family == "C").any():
            raise ContractError("HELDOUT_FAMILY_IN_FITTING_INPUT")
        if "heldout_object" in frame and frame.heldout_object.fillna(False).astype(bool).any():
            raise ContractError("HELDOUT_OBJECT_IN_FITTING_INPUT")
    features = feature_columns(train)
    for frame in (calibration, development):
        if feature_columns(frame) != features:
            raise ContractError("FEATURE_SCHEMA_MISMATCH")
    source = _eligible(train, head)
    if source.empty:
        n = len(features)
        artifact = HeadArtifact(head, "frequency", features, [0.] * n, [0.] * n, [1.] * n,
                                {"prior": 0.}, {"method": "identity", "status": "unavailable"},
                                threshold=1.0 + np.finfo(float).eps, status="insufficient_training_support")
        return artifact, {"head": head, "selected": "frequency", "selection_status": artifact.status,
                          "sampling": {"rows": 0}, "calibration_rows": 0,
                          "development_emitted_events": len(development_episodes), "refit": False,
                          "candidates": {}, "output_policy": "MODEL_UNTRAINED abstain"}
    sampled, weights, sampling = sample_training(source, max_train_rows, seed)
    # Fit every preprocessing statistic on bounded training rows only.
    x = sampled[features].to_numpy(dtype=np.float32, copy=True)
    x[~np.isfinite(x)] = np.nan
    medians = np.asarray([np.nanmedian(x[:, i]) if np.isfinite(x[:, i]).any() else 0 for i in range(x.shape[1])])
    x = np.where(np.isfinite(x), x, medians).astype(np.float32)
    means, scales = x.mean(axis=0), x.std(axis=0)
    scales = np.where(scales > 1e-8, scales, 1)
    del x
    y = sampled.target.to_numpy(dtype=int)
    ca = _eligible(calibration, head)
    dev = development[development.incident_type == head].copy()
    prior = float(np.average(y, weights=weights))
    reports, artifacts = {}, []
    requested = tuple(dict.fromkeys(("frequency", *(candidates or CANDIDATES))))
    if not set(requested) <= set(CANDIDATES):
        raise ContractError("UNKNOWN_CANDIDATE")
    for candidate in requested:
        if candidate in {"logistic", "lightgbm"} and len(np.unique(y)) < 2:
            reports[candidate] = {"status": "insufficient_training_classes"}
            continue
        a = HeadArtifact(head, candidate, features, medians.tolist(), means.tolist(), scales.tolist(), {}, {"method": "identity", "status": "insufficient_calibration_classes"})
        matrix = _matrix(a, sampled)
        if candidate == "frequency":
            a.parameters = {"prior": prior}
        elif candidate == "rule":
            ix = [i for i, name in enumerate(features) if any(word in name for word in ("alarm", "link_fault", "power_off", "disturbance"))]
            a.parameters = {"indices": ix, "reference": np.maximum(np.quantile(matrix[:, ix], .95, axis=0), 1).tolist() if ix else [], "prior": prior}
        elif candidate == "logistic":
            from sklearn.linear_model import LogisticRegression
            estimator = LogisticRegression(C=1.0, solver="lbfgs", max_iter=300, random_state=seed)
            estimator.fit((matrix - means) / scales, y, sample_weight=weights)
            if int(estimator.n_iter_.max()) >= 300:
                raise ContractError("LOGISTIC_DID_NOT_CONVERGE")
            a.parameters = {"coefficients": estimator.coef_[0].tolist(), "intercept": float(estimator.intercept_[0])}
        else:
            import lightgbm as lgb
            estimator = lgb.LGBMClassifier(n_estimators=300, num_leaves=31, max_bin=127, min_child_samples=100, learning_rate=.05, n_jobs=4, random_state=seed, deterministic=True, force_col_wise=True, verbosity=-1)
            estimator.fit(matrix, y, sample_weight=weights)
            a.model_text = estimator.booster_.model_to_string()
            a._booster = estimator.booster_
        del matrix
        if len(ca) and ca.target.nunique() == 2:
            raw = _raw_scores(a, ca)
            a.calibration = _fit_platt(raw, ca.target.to_numpy(dtype=int))
        scored = dev.copy()
        scored["score"] = predict_scores(a, dev)
        a.threshold = select_threshold(scored, development_episodes, head)
        report = evaluate_head(scored, development_episodes, threshold=a.threshold, head=head, bootstrap_replicates=0)
        reports[candidate] = {"status": "fitted", "calibration": a.calibration, "development": report}
        artifacts.append(a)
    if not artifacts:
        raise ContractError("NO_FITTED_CANDIDATE")
    # Max F1, then higher threshold, then simpler candidate. No subsequent refit.
    dev_truth = development_episodes[development_episodes.incident_type == head]
    supported = ca.target.nunique() == 2 and dev.loc[dev.eligible.astype(bool), "target"].nunique() == 2 and len(dev_truth) > 0
    promotable = artifacts if supported else [a for a in artifacts if a.candidate in {"frequency", "rule"}]
    winner = max(promotable, key=lambda a: (reports[a.candidate]["development"]["event_f1"], a.threshold, -CANDIDATES.index(a.candidate)))
    if not supported:
        winner.status = "insufficient_calibration_or_development_support"
        winner.threshold = 1.0 + np.finfo(float).eps
    return winner, {"head": head, "selected": winner.candidate, "sampling": sampling,
                    "selection_status": winner.status, "calibration_rows": len(ca),
                    "calibration_positive_rows": int(ca.target.sum()), "development_emitted_events": len(dev_truth),
                    "threshold_search": "all_unique_if_<=201_else_201_quantiles_plus_no_alert",
                    "candidates": reports, "refit": False, "lightgbm_fixed_trees": 300}
