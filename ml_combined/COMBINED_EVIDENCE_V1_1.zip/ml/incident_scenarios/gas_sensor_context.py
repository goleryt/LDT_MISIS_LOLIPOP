"""Rule-defined context linking gas forecasts to future sensor-failure risk.

This is not a trained stack, a probability correction, or a suppression rule.
"""
from copy import deepcopy
from datetime import datetime
import math

from .contracts import ContractError, TIMEZONE


def _moment(value):
    from zoneinfo import ZoneInfo
    stamp = datetime.fromisoformat(str(value))
    return stamp.replace(tzinfo=ZoneInfo(TIMEZONE)) if stamp.tzinfo is None else stamp


def combine_product_outputs(gas_output, sensor_output):
    """Keep gas payload byte-equivalent as JSON and append a separate context list.

    Same cutoff date, raw channel and object binding are required for a join.
    Non-overlapping forecast windows explicitly remain future-maintenance context.
    """
    if gas_output.get('as_of_date') != sensor_output.get('as_of_date'):
        raise ContractError('GAS_SENSOR_CUTOFF_MISMATCH')
    if 'sensor_failure' not in sensor_output.get('enabled_heads', []):
        raise ContractError('SENSOR_FAILURE_OUTPUT_REQUIRED')
    index = {}
    for row in sensor_output.get('predictions', []):
        if row.get('incident_type') != 'sensor_failure':
            continue
        if row.get('as_of_date') != sensor_output['as_of_date']:
            raise ContractError('SENSOR_ROW_CUTOFF_MISMATCH')
        channel = row.get('ид_канала_данных')
        if channel is None:
            continue
        channel = str(channel)
        if channel in index:
            raise ContractError('DUPLICATE_SENSOR_CHANNEL_CONTEXT')
        if row.get('eligible'):
            score, threshold = row.get('score'), row.get('threshold')
            if not isinstance(score, (int, float)) or not math.isfinite(score) or not 0 <= score <= 1:
                raise ContractError('INVALID_SENSOR_CONTEXT_SCORE')
            if not isinstance(threshold, (int, float)) or not math.isfinite(threshold) or not 0 <= threshold <= 1:
                raise ContractError('INVALID_SENSOR_CONTEXT_THRESHOLD')
            if bool(row.get('above_threshold')) != (score >= threshold):
                raise ContractError('SENSOR_CONTEXT_THRESHOLD_MISMATCH')
        index[channel] = row
    contexts = []
    for gas in gas_output.get('gas', []):
        channel = gas.get('ид_канала_данных')
        sensor = index.get(str(channel)) if channel is not None else None
        binding_matches = (sensor is not None and gas.get('ид_объект') is not None
                           and sensor.get('ид_объект') is not None
                           and str(gas['ид_объект']) == str(sensor['ид_объект']))
        available = binding_matches and bool(sensor.get('eligible'))
        warning = bool(available and sensor.get('above_threshold'))
        overlap = None
        if available:
            try:
                gs, ge = _moment(gas['window_start']), _moment(gas['window_end_exclusive'])
                ss, se = _moment(sensor['window_start']), _moment(sensor['window_end_exclusive'])
                if not gs < ge or not ss < se:
                    raise ValueError('INVALID_WINDOW')
                overlap = max(gs, ss) < min(ge, se)
            except (KeyError, TypeError, ValueError):
                # A missing/invalid horizon cannot establish temporal applicability.
                overlap = None
        code = 'FUTURE_SENSOR_FAILURE_RISK' if warning else ('NO_SENSOR_THRESHOLD_WARNING' if available else 'SENSOR_CONTEXT_UNAVAILABLE')
        contexts.append({
            'ид_канала_данных': channel, 'ид_объект': gas.get('ид_объект'),
            'context_code': code, 'sensor_score': sensor['score'] if available else None,
            'sensor_model_version': sensor.get('model_version') if sensor else None,
            'context_available_at': sensor.get('issued_at') if sensor else None,
            'sensor_window_start': sensor.get('window_start') if sensor else None,
            'sensor_window_end_exclusive': sensor.get('window_end_exclusive') if sensor else None,
            'forecast_windows_overlap': overlap,
            'current_measurement_unreliable': None,
            'gas_score_modified': False, 'gas_alarm_suppressed': False,
            'recommendation_source': 'declared_rule_not_model_explanation',
            'recommendation': ('Сохранить штатную обработку газовой тревоги. Запланировать проверку канала; '
                               'при газовой тревоге сверить показания независимым измерением. '
                               'Прогноз будущего отказа не доказывает неисправность датчика сейчас.' if warning else
                               'Сохранить штатную обработку газового прогноза. Отсутствие предупреждения об отказе не подтверждает исправность датчика.'),
            'evidence_level': 'E4', 'automated_action_allowed': False,
        })
    result = deepcopy(gas_output)
    result['sensor_failure'] = deepcopy([r for r in sensor_output.get('predictions', []) if r.get('incident_type') == 'sensor_failure'])
    result['gas_sensor_context'] = contexts
    result['gas_sensor_integration'] = {
        'version': 'gas-sensor-context-v1', 'kind': 'rule_context_not_trained_stack',
        'gas_payload_unchanged': True, 'gas_probability_improvement_established': False,
        'sensor_bundle_sha256': sensor_output.get('bundle_sha256'),
        'automated_action_allowed': False,
    }
    return result
