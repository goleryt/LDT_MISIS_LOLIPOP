"""One finite, causal 7/30 calendar-day builder for fitting and serving."""
from __future__ import annotations

from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd

from .contracts import (CHANNEL, COUNT_COLUMNS, DAY, HEADS, OBJECT, SENSOR_TYPE,
                        SYSTEM_TYPE, Coverage, ContractError, as_date)
from .daily import adapt_cached_panel, to_pandas
from .weather import WEATHER_FEATURES

GROUP_PATTERNS = {
    "fire": r"газ|дым|тепл|температ|пожар|пламен|извещат",
    "flood": r"затоп|уров|насос|вод|дренаж|приямк|залив",
    "intrusion": r"движ|двер|люк|охран|доступ|проник|кд",
    "system_failure": r"насос|вент|фаз|питан|систем|элект|тепл|вод|дренаж",
    "sensor_failure": r".+",
}
METADATA = ["entity_key", OBJECT, CHANNEL, "as_of_date", "incident_type", "eligible", "abstain_reason"]


def _channel_history(data: pd.DataFrame, coverage: Coverage, requested: Any) -> pd.DataFrame:
    blocks = []
    end = as_date(requested) if requested is not None else min(coverage.end_exclusive - timedelta(days=1), data[DAY].max())
    # Restrict before roster construction: a future channel cannot enter a past cohort.
    data = data[data[DAY] <= end]
    if requested is not None:
        data = data[data[DAY] >= end - timedelta(days=29)]
    for channel, group in data.groupby(CHANNEL, sort=True):
        group = group.sort_values(DAY)
        first_seen = group[DAY].min()
        start = end - timedelta(days=29) if requested is not None else first_seen - timedelta(days=29)
        stop = min(end, group[DAY].max() + timedelta(days=29))
        idx = pd.date_range(start, stop, freq="D")
        g = group.set_index(pd.to_datetime(group[DAY])).reindex(idx)
        g[CHANNEL] = channel
        present = g["row_present"].astype("boolean").fillna(False).astype(bool)
        # Calendar absence is distinct from an explicitly uncovered source row.
        covered = pd.Series((idx.date >= coverage.start) & (idx.date < coverage.end_exclusive), index=idx)
        covered &= g["source_covered"].astype("boolean").fillna(True).astype(bool)
        for c in (OBJECT, SENSOR_TYPE, SYSTEM_TYPE):
            g[c] = g[c].ffill(limit=29)
        out = g[[CHANNEL, OBJECT, SENSOR_TYPE, SYSTEM_TYPE]].copy()
        out["as_of_date"] = idx.date
        for w in (7, 30):
            roll = lambda series: series.rolling(w, min_periods=1)
            for c in COUNT_COLUMNS:
                out[f"x_{c}_{w}d"] = roll(g[c].fillna(0)).sum()
            out[f"x_present_days_{w}d"] = roll(present.astype(float)).sum()
            out[f"x_event_days_{w}d"] = roll(g.n_events.fillna(0).gt(0).astype(float)).sum()
            out[f"x_numeric_days_{w}d"] = roll(g.n_numeric.fillna(0).gt(0).astype(float)).sum()
            out[f"x_no_numeric_days_{w}d"] = roll((present & g.n_numeric.fillna(0).eq(0)).astype(float)).sum()
            out[f"x_gap_days_{w}d"] = w - out[f"x_present_days_{w}d"]
            out[f"x_alarm_rate_{w}d"] = out[f"x_n_alarm_{w}d"] / out[f"x_n_events_{w}d"].replace(0, np.nan)
            out[f"x_numeric_mean_{w}d"] = roll(g.num_mean * g.n_numeric).sum() / out[f"x_n_numeric_{w}d"].replace(0, np.nan)
            out[f"x_numeric_min_{w}d"] = roll(g.num_min).min()
            out[f"x_numeric_max_{w}d"] = roll(g.num_max).max()
            out[f"x_gas_max_{w}d"] = roll(g.gas_max).max()
        out["x_source_covered_days_30d"] = covered.astype(float).rolling(30, min_periods=1).sum()
        # Latest values reset after 30 days; never inherit old carried states.
        out["x_numeric_last_30d"] = g.num_last.ffill(limit=29)
        out["x_gas_last_30d"] = g.gas_last.ffill(limit=29)
        out["x_numeric_range_7d"] = out.x_numeric_max_7d - out.x_numeric_min_7d
        out["x_numeric_shift_7d_30d"] = out.x_numeric_mean_7d - out.x_numeric_mean_30d
        out["_covered"] = covered
        if requested is not None:
            out = out[out.as_of_date == end]
        else:
            out = out[out.as_of_date >= first_seen]
        blocks.append(out.reset_index(drop=True))
    return pd.concat(blocks, ignore_index=True) if blocks else pd.DataFrame()


def _objects(channels: pd.DataFrame, head: str) -> pd.DataFrame:
    channels = channels[channels[OBJECT].notna()].copy()
    if channels.empty:
        return pd.DataFrame()
    type_text = channels[SENSOR_TYPE].fillna("") + " " + channels[SYSTEM_TYPE].fillna("")
    channels["_relevant"] = type_text.str.contains(GROUP_PATTERNS[head], case=False, regex=True)
    # Values from unlike physical sensor types are never averaged together.
    sum_cols = [c for c in channels if c.startswith("x_n_")]
    mean_cols = [c for c in channels if c.startswith("x_") and c not in sum_cols
                 and "numeric_" not in c and "gas_" not in c]
    keys = [OBJECT, "as_of_date"]
    grouped = channels.groupby(keys, sort=True)
    out = grouped[sum_cols].sum().join(grouped[mean_cols].mean())
    out["x_channel_count"] = grouped.size()
    out["x_relevant_channel_count"] = grouped._relevant.sum()
    channels["_relevant_active"] = channels._relevant & channels.x_n_events_7d.gt(0)
    out["x_relevant_active_channels_7d"] = channels.groupby(keys)._relevant_active.sum()
    for w in (7, 30):
        for short, source in (("alarm", "n_alarm"), ("events", "n_events")):
            c = f"_relevant_{short}_{w}"
            channels[c] = channels[f"x_{source}_{w}d"].where(channels._relevant, 0)
            out[f"x_relevant_{short}_{w}d"] = channels.groupby(keys)[c].sum()
        c = f"_relevant_numeric_{w}"
        channels[c] = channels._relevant & channels[f"x_n_numeric_{w}d"].gt(0)
        out[f"x_relevant_numeric_channels_{w}d"] = channels.groupby(keys)[c].sum()
        if head == "fire":
            out[f"x_gas_max_{w}d"] = grouped[f"x_gas_max_{w}d"].max()
    # Any explicit source gap affects the object; averaging could conceal it.
    out["x_source_covered_days_30d"] = grouped.x_source_covered_days_30d.min()
    out[CHANNEL] = None
    return out.reset_index()


def build_features(daily: Any, head: str, coverage: Coverage, weather: Any = None,
                   as_of_date: Any = None) -> pd.DataFrame:
    """Rows known at D; finite input support [D-29,D], weather through D-1.

    A source coverage declaration describes collection dates, not measurement
    frequency. Absence, a present zero-event row, and missing numeric values
    remain different features. Unknown/future metadata never enables a head.
    """
    head = str(getattr(head, "value", head))
    if head not in HEADS:
        raise ContractError("UNKNOWN_INCIDENT_TYPE")
    if coverage.end_exclusive <= coverage.start:
        raise ContractError("INVALID_COVERAGE")
    data = adapt_cached_panel(daily)
    if data.empty:
        return pd.DataFrame(columns=METADATA)
    channels = _channel_history(data, coverage, as_of_date)
    if channels.empty:
        return pd.DataFrame(columns=METADATA)
    if head == "sensor_failure":
        out = channels.drop(columns=["_covered"]).copy()
        relevant = out[SENSOR_TYPE].notna() & out[SENSOR_TYPE].astype(str).str.len().gt(0)
        active = out.x_n_events_7d.gt(0)
        out["entity_key"] = out[CHANNEL]
        out = out.drop(columns=[SENSOR_TYPE, SYSTEM_TYPE])
    else:
        out = _objects(channels, head)
        if out.empty:
            return pd.DataFrame(columns=METADATA)
        relevant = out.x_relevant_channel_count.gt(0)
        active = out.x_relevant_active_channels_7d.gt(0)
        out["entity_key"] = out[OBJECT]
    sufficient = out.x_source_covered_days_30d.eq(30)
    # Coverage.validate also catches explicit requested dates outside coverage.
    declared = out.as_of_date.map(lambda d: coverage.start <= d - timedelta(days=29)
                                 and d < coverage.end_exclusive)
    sufficient &= declared
    out["incident_type"] = head
    out["eligible"] = sufficient & relevant & active
    out["abstain_reason"] = np.select([~sufficient, ~relevant, ~active],
                                      ["INSUFFICIENT_HISTORY", "NO_RELEVANT_CHANNEL", "NO_RECENT_OBSERVATIONS"], default="")
    if weather is not None:
        w = to_pandas(weather)
        date_col = "as_of_date" if "as_of_date" in w else DAY
        if date_col not in w:
            raise ContractError("WEATHER_DATE_MISSING")
        w["as_of_date"] = pd.to_datetime(w[date_col]).dt.date
        if w.as_of_date.duplicated().any():
            raise ContractError("DUPLICATE_WEATHER_DATE")
        # Weather module is the only upstream allowlist; metadata is not a feature.
        if set(c for c in w if c.startswith("w_")) - set(WEATHER_FEATURES):
            raise ContractError("WEATHER_FEATURE_NOT_ALLOWLISTED")
        if set(WEATHER_FEATURES) - set(w):
            raise ContractError("WEATHER_FEATURES_MISSING")
        cols = list(WEATHER_FEATURES)
        if any(not pd.api.types.is_numeric_dtype(w[c]) for c in cols):
            raise ContractError("WEATHER_FEATURE_NOT_NUMERIC")
        out = out.merge(w[["as_of_date", *cols]].rename(columns={c: "x_weather_" + c[2:] for c in cols}),
                        on="as_of_date", how="left", validate="many_to_one")
        out["x_weather_missing"] = out[["x_weather_" + c[2:] for c in cols]].isna().any(axis=1).astype(float) if cols else 1.0
    x = sorted(c for c in out if c.startswith("x_"))
    if len(x) > 64:
        raise ContractError("FEATURE_LIMIT_EXCEEDED")
    out[x] = out[x].astype(float).replace([np.inf, -np.inf], np.nan)
    return out.loc[:, [*METADATA, *x]].sort_values(["as_of_date", "entity_key"]).reset_index(drop=True)
