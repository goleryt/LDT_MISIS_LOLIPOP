"""Primary-first, immutable CPU jobs. Partial previews never masquerade as full stages."""
from __future__ import annotations

import argparse
from dataclasses import asdict, fields, replace
from contextlib import contextmanager
from datetime import timedelta
import io
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile
import hashlib

from .artifacts import (atomic_json, environment_identity, fingerprint, source_identity,
                        verify_stage, write_stage, configure_threads)
from .contracts import HEADS, PARTITIONS, PRIMARY_SEED, DAY, OBJECT, Coverage, GeneratorConfig, ResourceConfig, ContractError, scenario_evidence
from .task_support import read_checkpoint, write_checkpoint, run_worker

VARIANTS = ('sensors_weather', 'sensors_only', 'weather_only')
CHALLENGES = ('unseen_family_C', 'hazard_low', 'hazard_high', 'unsignaled_zero',
              'unsignaled_half', 'seed_2', 'seed_3', 'seed_4', 'missing_rows', 'delayed_source')
WORKFLOW = 'incident-bounded-jobs-v1'


def plan():
    jobs = []
    def add(key, kind, deps=(), cap=1200, **params):
        jobs.append(dict(key=key, kind=kind, deps=list(deps), cap_seconds=cap, **params))
    for h in HEADS:
        add(f'fit/sensors_weather/{h}', 'fit', cap=2700, head=h, variant='sensors_weather')
    for v in VARIANTS:
        if v != 'sensors_weather':
            for h in HEADS:
                add(f'fit/{v}/{h}', 'fit', cap=2700, head=h, variant=v)
        add(f'export/{v}', 'export', [f'fit/{v}/{h}' for h in HEADS], cap=300, variant=v)
        for h in HEADS:
            add(f'primary/{v}/{h}', 'primary', [f'export/{v}'], head=h, variant=v)
        add(f'accept/{v}', 'accept', [f'export/{v}', *[f'primary/{v}/{h}' for h in HEADS]], cap=600, variant=v)
    for h in HEADS:
        add(f'paired/{h}', 'paired', [f'primary/{v}/{h}' for v in ('sensors_only', 'sensors_weather')], head=h)
        add(f'placebo/{h}', 'placebo', [f'fit/sensors_weather/{h}'], head=h)
    for challenge in CHALLENGES:
        for h in HEADS:
            add(f'stress/{challenge}/{h}', 'stress', ['export/sensors_weather'], cap=720, head=h, challenge=challenge)
    add('mixed', 'mixed', ['export/sensors_weather'], cap=1800)
    add('full_protocol', 'assemble', [j['key'] for j in jobs], cap=1200)
    return jobs


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, default=str).encode('utf-8')


def _jobroot(context, key):
    return Path(context['output']) / 'jobs' / key


def _record(context, key, name):
    return json.loads((_jobroot(context, key) / name).read_text(encoding='utf-8'))


def _artifact(context, head, variant):
    from .models import HeadArtifact
    from .bundle import _validate_model
    a = HeadArtifact(**_record(context, f'fit/{variant}/{head}', 'model.json'))
    _validate_model(a)
    return a


def _bytes_frame(frame):
    import polars as pl
    output = io.BytesIO()
    pl.from_pandas(frame, include_index=False).write_parquet(output, compression='zstd')
    return output.getvalue()


def _weather():
    from .weather import prepare_weather, load_cached_weather
    return prepare_weather(load_cached_weather())


def _fit(context, spec, resources):
    from .pipeline import _bounded_train, _partition_frames, _episodes, _variant
    from .models import fit_head
    h, v = spec['head'], spec['variant']
    if context.get('reuse_models'):
        from .bundle import load_bundle
        a = load_bundle(Path(context['reuse_models'])/v/'incident_scenarios_v1.zip')[h]
        report = json.loads((Path(context['reuse_models'])/'selection'/f'{h}_{v}.json').read_text(encoding='utf-8'))
        record = {f.name:getattr(a,f.name) for f in fields(a) if not f.name.startswith('_')}
        return {'model.json':_json(record),'selection.json':_json(report),
                'imported_from.json':_json({'stage_fingerprint':context['imported_models']})}
    train, sampling = _bounded_train(context['scenarios'], h, resources.max_train_rows, PRIMARY_SEED)
    calibration = _partition_frames(context['scenarios'], h, 'calibration')
    development = _partition_frames(context['scenarios'], h, 'development')
    print('FIT_ROWS',h,v,len(train),len(calibration),len(development),flush=True)
    a, report = fit_head(*[_variant(f, v) for f in (train, calibration, development)], h,
                         max_train_rows=resources.max_train_rows,
                         development_episodes=_episodes(context['scenarios'], h, 'development'))
    report['upstream_sampling'] = sampling
    record = {f.name: getattr(a, f.name) for f in fields(a) if not f.name.startswith('_')}
    return {'model.json': _json(record), 'selection.json': _json(report)}


def _export(context, spec, resources):
    from .bundle import export_bundle
    from .acceptance import canonical_fixture
    from .runtime import predict_day
    v = spec['variant']
    artifacts = {h: _artifact(context, h, v) for h in HEADS}
    with tempfile.TemporaryDirectory() as directory:
        bundle = export_bundle(artifacts, directory, metadata={
            'source_fingerprint': context['parents']['scenarios'], 'environment': context['environment'],
            'resources': asdict(resources), 'variant': v, 'imported_models':context.get('imported_models')})
        files = {bundle.name: bundle.read_bytes(), bundle.name+'.sha256': bundle.with_suffix('.zip.sha256').read_bytes()}
    fixture, day, coverage = canonical_fixture()
    files['acceptance_daily.parquet'] = _bytes_frame(fixture)
    files['acceptance_expected.json'] = _json(predict_day(artifacts, fixture, day, coverage=coverage,
        weather=_weather() if v != 'sensors_only' else None, replay=True, request_id='artifact-acceptance'))
    return files


def _primary(context, spec, resources):
    import pandas as pd
    from .pipeline import _read, _episodes, _variant
    from .sealed_evaluation import _narrow_score, _evaluate_cohorts, _attention_budgets
    from .evaluation import _prepared
    h, v = spec['head'], spec['variant']
    a = _artifact(context, h, v)
    parts = [_narrow_score(_variant(_read(p), v), a, resources)
             for p in sorted((Path(context['scenarios'])/h).glob('*/test.parquet'))]
    rows = pd.concat(parts, ignore_index=True)
    episodes = _episodes(context['scenarios'], h, 'test')
    report = _evaluate_cohorts(rows, episodes, a, resources)
    report['attention_budgets'] = _attention_budgets(rows, episodes, a)
    _, _, alerts, _ = _prepared(rows, episodes, a.threshold, 3, h)
    onsets = {r.episode_id: pd.Timestamp(r.onset) for r in episodes.itertuples(index=False)}
    leads = sorted((onsets[r['matched_episode_id']]-pd.Timestamp(r['issued_at'])).total_seconds()/3600
                   for r in alerts if r['matched_episode_id'] is not None)
    actual = {'matched_events': len(leads), 'minimum_hours': min(leads) if leads else None,
              'median_hours': float(pd.Series(leads).median()) if leads else None,
              'maximum_hours': max(leads) if leads else None,
              'meaning': 'onset minus replay issuance for matched synthetic events; not live latency'}
    return {'report.json': _json(report), 'scores.parquet': _bytes_frame(rows),
            'alerts.json': _json([{'issued_at': r['issued_at'], OBJECT: r[OBJECT]} for r in alerts]),
            'matched_lead.json': _json(actual)}


def _accept(context, spec, resources):
    from .acceptance import check_bundle
    v = spec['variant']
    root = _jobroot(context, f'export/{v}')
    checks = check_bundle(root/'incident_scenarios_v1.zip', _record(context, f'export/{v}', 'acceptance_expected.json'),
                          weather=_weather() if v != 'sensors_only' else None)
    return {'acceptance.json': _json({'mode': context['mode'], 'variant': v,
        'scope': 'primary_preview_only', 'protocol_complete': False,
        'checks': checks, **scenario_evidence()})}


def _paired(context, spec, resources):
    from .pipeline import _read, _episodes
    from .comparison import paired_weather_comparison
    h = spec['head']
    # Reuse verified scores. No second pass through feature construction or models.
    frames = [_read(_jobroot(context, f'primary/{v}/{h}')/'scores.parquet') for v in ('sensors_only','sensors_weather')]
    report = paired_weather_comparison(*frames, _episodes(context['scenarios'], h, 'test'),
        sensors_threshold=_artifact(context,h,'sensors_only').threshold,
        weather_threshold=_artifact(context,h,'sensors_weather').threshold,
        head=h, replicates=resources.bootstrap_replicates)
    return {'report.json': _json(report)}


def _placebo(context, spec, resources):
    from .pipeline import _partition_frames, _episodes
    from .weather import train_weather_placebo, WEATHER_FEATURES
    from .models import predict_scores
    from .evaluation import evaluate_head
    h = spec['head']
    development = _partition_frames(context['scenarios'], h, 'development')
    mapping = train_weather_placebo(_weather(), seed=PRIMARY_SEED).set_index('as_of_date')
    for name in WEATHER_FEATURES:
        development['x_weather_'+name[2:]] = development.as_of_date.map(mapping[name])
    cols = [c for c in development if c.startswith('x_weather_') and c != 'x_weather_missing']
    development['x_weather_missing'] = development[cols].isna().any(axis=1).astype('float32')
    a = _artifact(context,h,'sensors_weather')
    development['score'] = predict_scores(a, development)
    return {'report.json': _json(evaluate_head(development, _episodes(context['scenarios'],h,'development'),
        head=h, threshold=a.threshold, bootstrap_replicates=0))}


def _stress(context, spec, resources):
    import pandas as pd
    import gc
    from .pipeline import _read, _label_features
    from .simulation import heldout_objects, generate_scenarios, apply_overlays, attach_targets
    from .features import build_features
    from .sealed_evaluation import CHALLENGES as SETTINGS, _stress_observations, _narrow_score, _evaluate_cohorts
    h, challenge = spec['head'], spec['challenge']
    generator = replace(GeneratorConfig(), challenge=challenge, **SETTINGS[challenge])
    coverage = Coverage.from_dict(context['coverage'])
    a, weather = _artifact(context,h,'sensors_weather'), _weather()
    parts, truths, audits = [], [], []
    for p in sorted((Path(context['background'])/'daily').glob('*.parquet')):
        daily = _read(p)
        heldout = heldout_objects(daily)
        daily = daily[(daily[DAY] >= PARTITIONS['test'][0]-timedelta(days=30)) & (daily[DAY] < PARTITIONS['test'][1])].copy()
        if challenge in {'missing_rows','delayed_source'}:
            overlays, ep, audit = generate_scenarios(daily,h,generator,coverage,frozen_heldout=heldout)
            changed = _stress_observations(apply_overlays(daily,overlays),challenge)
            f = attach_targets(build_features(changed,h,coverage,weather=weather),ep)
            f['heldout_object'] = f[OBJECT].isin(heldout)
            lo, hi = PARTITIONS['test']
            f = f[(f.as_of_date >= lo) & (f.as_of_date+timedelta(days=4) <= hi)]
        else:
            f, ep, audit = _label_features(daily,h,generator,coverage,weather,frozen_heldout=heldout)
            f = f[f.partition == 'test']
            f['heldout_object'] = f[OBJECT].isin(heldout)
        ep = ep[ep.partition == 'test'].copy()
        ep['heldout_object'] = ep[OBJECT].isin(heldout)
        parts.append(_narrow_score(f,a,resources)); truths.append(ep); audits.append(audit)
        del f, daily
        gc.collect()
    report = _evaluate_cohorts(pd.concat(parts,ignore_index=True),pd.concat(truths,ignore_index=True),a,resources)
    report['audit'] = audits
    report['calibration_interpretation'] = 'Not a calibration claim outside the primary simulated mixture.'
    return {'report.json': _json(report)}


def _mixed(context, spec, resources):
    from .sealed_evaluation import _joint_evaluation
    with tempfile.TemporaryDirectory() as directory:
        _joint_evaluation(Path(context['background']),Path(directory),
                          {h:_artifact(context,h,'sensors_weather') for h in HEADS},
                          Coverage.from_dict(context['coverage']),_weather(),resources)
        return {p.relative_to(directory).as_posix():p.read_bytes() for p in Path(directory).rglob('*') if p.is_file()}


@contextmanager
def _assemble(context, spec, resources):
    from .acceptance import stage_accept
    from .sealed_evaluation import CHALLENGES as SETTINGS
    from .contracts import scenario_evidence
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        fit, evaluation = root/'03_fit', root/'04_sealed_evaluate'
        for v in VARIANTS:
            export = _jobroot(context,f'export/{v}')
            for p in export.iterdir():
                if p.is_file() and p.name != 'manifest.json':
                    target = fit/v/p.name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)
            for h in HEADS:
                atomic_json(fit/'selection'/f'{h}_{v}.json',_record(context,f'fit/{v}/{h}','selection.json'))
                atomic_json(evaluation/'metrics'/f'{h}_{v}_primary.json',_record(context,f'primary/{v}/{h}','report.json'))
        if context.get('reuse_models'):
            atomic_json(fit/'imported_models_manifest.json',json.loads((Path(context['reuse_models'])/'stage_manifest.json').read_text()))
        combined = {}
        for h in HEADS:
            atomic_json(fit/'selection'/f'{h}_development_weather_placebo.json',_record(context,f'placebo/{h}','report.json'))
            atomic_json(evaluation/'metrics'/f'{h}_paired_weather_comparison.json',_record(context,f'paired/{h}','report.json'))
            for challenge in CHALLENGES:
                atomic_json(evaluation/'metrics'/f'{h}_{challenge}.json',_record(context,f'stress/{challenge}/{h}','report.json'))
            target = evaluation/'primary_scores'/f'{h}.parquet'; target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(_jobroot(context,f'primary/sensors_weather/{h}')/'scores.parquet',target)
            for a in _record(context,f'primary/sensors_weather/{h}','alerts.json'):
                combined.setdefault(a['issued_at'][:10],set()).add(a[OBJECT])
        for p in _jobroot(context,'mixed').rglob('*'):
            if p.is_file() and p.name != 'manifest.json':
                target = evaluation/p.relative_to(_jobroot(context,'mixed')); target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)
        atomic_json(evaluation/'combined_workload.json',{'unique_objects_by_issue_day':{d:len(v) for d,v in combined.items()},
            'units':'unique_objects_per_day_across_five_heads','scope':'union_of_independent_single_head_benchmarks_not_joint_dispatcher_load','evidence':scenario_evidence()})
        model_m = write_stage(fit,stage='03_fit',config={'mode':context['mode'],'variants':VARIANTS,'resources':asdict(resources),'refit':False},
            parents={'scenarios':context['parents']['scenarios'],**({'imported_models':context['imported_models']} if context.get('imported_models') else {})},
            environment=context['environment'],code=context['code'])
        write_stage(evaluation,stage='04_evaluate',config={'mode':context['mode'],'challenges':SETTINGS,
            'resources':asdict(resources),'frozen_thresholds':True,'evidence':scenario_evidence()},
            parents={**context['parents'],'models':model_m['fingerprint']},environment=context['environment'],code=context['code'])
        stage_accept(evaluation,root/'05_export_acceptance',models=fit,background=context['background'],
                     mode=context['mode'],resources=resources,environment=context['environment'],code=context['code'])
        # Private full stage archive retains every manifested file. The separate
        # backend packager excludes score panels from the portable handoff.
        yield root


WORKERS = dict(fit=_fit,export=_export,primary=_primary,accept=_accept,paired=_paired,
               placebo=_placebo,stress=_stress,mixed=_mixed,assemble=_assemble)


def identity(context, spec, completed):
    return {'workflow':WORKFLOW,'task':spec,'parents':context['parents'],
            'dependencies':{k:completed[k]['fingerprint'] for k in spec['deps']},
            'code':context['code'],'environment':context['environment'],'mode':context['mode'],
            'resources':context['resources'],'imported_models':context.get('imported_models')}


def _memory_limit(resources):
    limit = int(resources.max_rss_gib*1024**3)
    for name in ('/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory/memory.limit_in_bytes'):
        try:
            value = Path(name).read_text().strip()
            if value != 'max':
                limit = min(limit,int(int(value)*resources.cgroup_fraction))
        except OSError:
            pass
    return limit


def output_bytes(root):
    return sum(p.stat().st_size for p in Path(root).rglob('*') if p.is_file())


def _require_output_space(context, additional=0):
    limit = context['resources']['saved_output_budget_gib']*1024**3
    if output_bytes(context.get('budget_root',context['output']))+additional > limit:
        raise ContractError('OUTPUT_BUDGET_EXCEEDED')


def publish_primary_preview(context):
    """Publish the useful primary result BEFORE optional jobs can fail or time out."""
    output = Path(context['output'])
    target = output.parent/'PRIMARY_PREVIEW.zip'
    if target.exists():
        return
    source = output/'EXECUTED_SOURCE.zip'
    files = {'run_status.json':output/'run_status.json','context.json':output/'context.json'}
    if source.exists():
        with zipfile.ZipFile(source) as archive:
            for name,expected in context['code'].items():
                member = 'ml/sensor_failure/'+name[7:] if name.startswith('legacy/') else 'ml/incident_scenarios/'+name
                if hashlib.sha256(archive.read(member)).hexdigest() != expected:
                    raise ContractError('PREVIEW_SOURCE_MISMATCH')
        files['incident_scenarios_source.zip'] = source
    for key in ['export/sensors_weather','accept/sensors_weather',*[f'primary/sensors_weather/{h}' for h in HEADS]]:
        for p in _jobroot(context,key).rglob('*'):
            if p.is_file() and p.name not in {'scores.parquet','alerts.json'}:
                files[p.relative_to(output/'jobs').as_posix()] = p
    for h in HEADS:
        files[f'selection/{h}.json'] = _jobroot(context,f'fit/sensors_weather/{h}')/'selection.json'
    _require_output_space(context,sum(p.stat().st_size for p in files.values()))
    temporary = target.with_suffix('.partial')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,path in files.items():
            archive.write(path,name)
        archive.writestr('README.txt','PRIMARY PREVIEW ONLY. Synthetic primary evaluation and technical acceptance. Full protocol is separate; no automatic actions. Some heads may abstain or have insufficient support.')
    temporary.replace(target)
    print('PRIMARY_PREVIEW_SAVED',flush=True)


def run(background, scenarios, output, *, acceptance_python=None, budget_seconds=32400,
        shutdown_reserve_seconds=1800, mode='FULL', only=None, models_input=None, resume=None):
    if not 60 < budget_seconds <= 32400 or not 2 <= shutdown_reserve_seconds < budget_seconds:
        raise ContractError('INVALID_BOUNDED_BUDGET')
    started = time.monotonic()
    if not acceptance_python or not Path(acceptance_python).is_file():
        raise ContractError('FRESH_ACCEPTANCE_PYTHON_REQUIRED')
    # Linux venv executables may resolve to the same host symlink target while
    # still providing separate site-packages. Compare venv entry paths instead.
    if Path(acceptance_python).absolute() == Path(sys.executable).absolute():
        raise ContractError('SEPARATE_ACCEPTANCE_ENVIRONMENT_REQUIRED')
    output = Path(output); output.mkdir(parents=True,exist_ok=True)
    env, code = environment_identity(),source_identity(Path(__file__).parent)
    from .pipeline import _require_parent
    b = verify_stage(background,expected_stage='01_background')
    s = verify_stage(scenarios,expected_stage='02_scenarios')
    for m in (b,s):
        _require_parent(m,env,code,mode)
    if s['parents']['background'] != b['fingerprint']:
        raise ContractError('BROKEN_INPUT_LINEAGE')
    context = dict(output=str(output.resolve()),background=str(Path(background).resolve()),
        budget_root=str(output.resolve().parent),
        scenarios=str(Path(scenarios).resolve()),environment=env,code=code,mode=mode,
        parents={'background':b['fingerprint'],'scenarios':s['fingerprint']},
        coverage=s['extra']['coverage'],resources=asdict(ResourceConfig()))
    if models_input:
        from .compatibility import trained_code_compatible
        m = verify_stage(models_input,expected_stage='03_fit')
        if (m['config']['mode'] != mode or m['environment'] != env
                or m['parents']['scenarios'] != s['fingerprint'] or not trained_code_compatible(m['code'],code)):
            raise ContractError('COMPLETED_MODELS_INCOMPATIBLE')
        context.update(reuse_models=str(Path(models_input).resolve()),imported_models=m['fingerprint'])
    context_path = output/'context.json'; atomic_json(context_path,context)
    completed, statuses = {}, {}
    requested = set(only) if only else None
    jobs = plan()
    if requested and not requested <= {j['key'] for j in jobs}:
        raise ContractError('UNKNOWN_TASK')
    def publish():
        full = 'full_protocol' in completed
        preview = 'accept/sensors_weather' in completed
        atomic_json(output/'run_status.json',{'workflow':WORKFLOW,'mode':mode,
            'status':'complete' if full else 'partial','protocol_complete':full,
            'primary_preview_ready':preview,'preview_scope':'synthetic_primary_only',
            'elapsed_seconds':time.monotonic()-started,'budget_seconds':budget_seconds,
            'tasks':statuses,**scenario_evidence()})
    for spec in jobs:
        key = spec['key']
        if any(d not in completed for d in spec['deps']):
            statuses[key] = {'status':'not_started','reason':'dependencies_incomplete'}; publish(); continue
        ident = identity(context,spec,completed)
        if resume and not _jobroot(context,key).exists():
            source = Path(resume)/'jobs'/key
            saved = read_checkpoint(source,ident)
            if saved:
                # Re-publish verified files atomically; do not copy stale pending jobs.
                _require_output_space(context,sum((source/n).stat().st_size for n in saved['files']))
                write_checkpoint(_jobroot(context,key),ident,{n:(source/n).read_bytes() for n in saved['files']})
        old = read_checkpoint(_jobroot(context,key),ident)
        if old:
            completed[key] = old; statuses[key] = {'status':'completed','reused':True}; publish()
            if key == 'accept/sensors_weather':
                publish_primary_preview(context)
            continue
        if requested and key not in requested:
            statuses[key] = {'status':'not_started','reason':'not_requested'}; publish(); continue
        remaining = budget_seconds-(time.monotonic()-started)
        finalization = spec['kind'] in {'export','accept','assemble'}
        allowance = remaining-2 if finalization else remaining-shutdown_reserve_seconds-2
        if allowance <= 0:
            statuses[key] = {'status':'not_started','reason':'budget_exhausted'}; publish(); continue
        _require_output_space(context)
        print('START_JOB',key,flush=True)
        worker_python = acceptance_python if spec['kind'] in {'accept','assemble'} else sys.executable
        if not worker_python:
            raise ContractError('FRESH_ACCEPTANCE_PYTHON_REQUIRED')
        command = [str(worker_python),'-u','-m','ml.incident_scenarios.jobs','worker',
                   '--context',str(context_path.resolve()),'--spec',json.dumps(spec),
                   '--identity',json.dumps(ident)]
        result = run_worker(command,log_path=output/'logs'/(key.replace('/','_')+'.log'),
            timeout_seconds=min(spec['cap_seconds'],allowance),max_rss_bytes=_memory_limit(ResourceConfig()))
        if result['status'] == 'completed':
            saved = read_checkpoint(_jobroot(context,key),ident)
            if saved is None:
                raise ContractError('SUCCESS_WITHOUT_CHECKPOINT')
            completed[key] = saved
        statuses[key] = result
        print('END_JOB',key,result['status'],round(result['elapsed_seconds'],1),flush=True)
        publish()
        if key == 'accept/sensors_weather' and key in completed:
            publish_primary_preview(context)
    publish()
    print('FULL_PROTOCOL_PASSED' if 'full_protocol' in completed else 'PARTIAL_RESULTS_SAVED',flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command',required=True)
    sub.add_parser('plan')
    p = sub.add_parser('run')
    for name in ('background','scenarios','output','acceptance-python'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--budget-seconds',type=float,default=32400)
    p.add_argument('--only',nargs='+')
    p.add_argument('--models-input')
    p.add_argument('--resume')
    p.add_argument('--mode',choices=('FULL','SMOKE'),default='FULL')
    p = sub.add_parser('worker')
    for name in ('context','spec','identity'):
        p.add_argument('--'+name,required=True)
    args = vars(parser.parse_args()); command = args.pop('command')
    if command == 'plan':
        print(json.dumps(plan(),indent=2)); return
    if command == 'run':
        run(**args); return
    context = json.loads(Path(args['context']).read_text(encoding='utf-8'))
    configure_threads(ResourceConfig(**context['resources']))
    spec, ident = json.loads(args['spec']),json.loads(args['identity'])
    if environment_identity() != context['environment'] or source_identity(Path(__file__).parent) != context['code']:
        raise ContractError('WORKER_IDENTITY_MISMATCH')
    files = WORKERS[spec['kind']](context,spec,ResourceConfig(**context['resources']))
    if spec['kind'] == 'assemble':
        from .task_support import write_checkpoint_from_directory
        with files as directory:
            _require_output_space(context,output_bytes(directory))
            write_checkpoint_from_directory(_jobroot(context,spec['key']),ident,directory)
    else:
        _require_output_space(context,sum(len(b) for b in files.values()))
        write_checkpoint(_jobroot(context,spec['key']),ident,files)


if __name__ == '__main__':
    main()
