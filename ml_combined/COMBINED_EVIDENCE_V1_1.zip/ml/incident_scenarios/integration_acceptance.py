"""Verify the assembled delivery in a fresh process; never trains a model."""
import argparse
from datetime import timedelta
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .artifacts import atomic_json
from .bundle import load_bundle
from .command import score_journal
from .contracts import DAY, CHANNEL, HEADS, Coverage, COUNT_COLUMNS, NUMERIC_COLUMNS, ContractError
from .features import build_features
from .models import predict_scores
from .rescue_features import transform_history
from .runtime import predict_day


def verify(root):
    root = Path(root)
    load = lambda name: json.loads((root / name).read_text(encoding='utf-8'))
    bundle = root / 'models/incident_sensor_integrated_v2.zip'
    artifacts = load_bundle(bundle)
    daily = pd.DataFrame(load('examples/daily.json'))
    daily[DAY] = pd.to_datetime(daily[DAY]).dt.date
    coverage = Coverage.from_dict(load('examples/coverage.json'))
    day = load('examples/request.json')['as_of_date']
    import datetime
    day = datetime.date.fromisoformat(day)
    output = predict_day(bundle, daily, day, coverage=coverage, replay=True, request_id='integration-acceptance')
    assert output['enabled_heads'] == ['sensor_failure']
    assert output['predictions'] and all(row['incident_type'] == 'sensor_failure' for row in output['predictions'])
    assert any(row['eligible'] and row['score'] is not None for row in output['predictions'])
    assert output == load('examples/expected_sensor.json')

    # Compare actual LightGBM against the original Kaggle Python3.13 golden fixture.
    base = pd.DataFrame(load('provenance/sensor_fixture_base_history.json'))
    expected = load('provenance/sensor_fixture_expected.json')
    transformed = transform_history(base, 'sensor_failure', expected['as_of_date'])
    valid = transformed.eligible.astype(bool)
    scored = predict_scores(artifacts['sensor_failure'], transformed.loc[valid])
    reference = [row['score'] for row in expected['scores'] if row['eligible']]
    np.testing.assert_allclose(scored, reference, rtol=1e-12, atol=1e-12)

    # Independent inference route: full daily history -> training transform -> model.
    base = build_features(daily[daily[DAY] <= day], 'sensor_failure', coverage)
    frame = transform_history(base, 'sensor_failure', day)
    reference = predict_scores(artifacts['sensor_failure'], frame)
    np.testing.assert_allclose([r['score'] for r in output['predictions']], reference, rtol=1e-12, atol=1e-12)
    returning = daily[~((daily[CHANNEL] == 'fixture-channel-0') & (daily[DAY] >= day-timedelta(days=29)) & (daily[DAY] < day))].copy()
    returned = predict_day(bundle, returning, day, coverage=coverage, replay=True)
    reference_frame = transform_history(build_features(returning[returning[DAY] <= day], 'sensor_failure', coverage), 'sensor_failure', day)
    np.testing.assert_allclose([r['score'] for r in returned['predictions']], predict_scores(artifacts['sensor_failure'], reference_frame), rtol=1e-12, atol=1e-12)
    try:
        predict_day(bundle, daily, day, coverage=Coverage(day-timedelta(days=29), day+timedelta(days=1)), replay=True)
    except ContractError as error:
        assert str(error) == 'INSUFFICIENT_HISTORY'
    else:
        raise AssertionError('33_DAY_HISTORY_CONTRACT_NOT_ENFORCED')
    changed = daily.copy()
    outside = (changed[DAY] > day) | (changed[DAY] < day-timedelta(days=32))
    changed.loc[outside, 'n_alarm'] = 0
    assert predict_day(bundle, changed, day, coverage=coverage, replay=True, request_id='integration-acceptance') == output
    gap = daily.copy()
    gap.loc[:, list(COUNT_COLUMNS)] = 0
    gap.loc[:, list(NUMERIC_COLUMNS)] = np.nan
    gap['numeric_missing'] = True
    gap['source_covered'] = False
    abstained = predict_day(bundle, gap, day, coverage=coverage, replay=True)
    assert abstained['predictions'] and all(r['score'] is None and not r['above_threshold'] for r in abstained['predictions'])

    # Remaining four heads retain their original artifact and inference behavior.
    original = load_bundle(root / 'provenance/original_bundle.zip', verify_python=False)
    weather = pd.DataFrame(load('examples/weather_replay.json'))
    all_before = predict_day(original, daily, day, coverage=coverage, weather=weather, replay=True)
    all_after = predict_day(bundle, daily, day, coverage=coverage, weather=weather, replay=True, heads=list(HEADS))
    before = [r for r in all_before['predictions'] if r['incident_type'] != 'sensor_failure']
    after = [r for r in all_after['predictions'] if r['incident_type'] != 'sensor_failure']
    # Maturity annotations are delivery metadata; predictive fields must match.
    for rows in (before, after):
        for row in rows:
            row.pop('model_maturity', None)
    assert before == after

    raw = pd.DataFrame(load('examples/journal.json'))
    cat = pd.DataFrame(load('examples/catalogue.json'))
    raw_output = score_journal(bundle, raw, cat, day, coverage=coverage, replay=True, request_id='raw-integration')
    assert raw_output['predictions'] and all(r['ид_канала_данных'] == 'demo-channel' for r in raw_output['predictions'])
    assert raw_output == load('examples/expected_raw_sensor.json')
    from .gas_sensor_context import combine_product_outputs
    gas = load('examples/gas_output_synthetic.json')
    combined = combine_product_outputs(gas, raw_output)
    assert combined['gas'] == gas['gas'] and combined == load('examples/expected_combined.json')
    assert len(combined['gas_sensor_context']) == len(gas['gas'])
    checks = {'status': 'passed', 'default_sensor_only': True, 'actual_exported_lightgbm': True,
              'kaggle_313_golden_score_parity': True, 'raw_daily_training_serving_parity': True,
              'future_and_old_history_invariance': True, 'source_gap_abstention': True,
              'other_four_head_outputs_unchanged': True, 'raw_journal_to_prediction': True,
              'gas_context_join_verified': True, 'gas_payload_unchanged': True,
              'gas_context_fixture': 'synthetic_existing_output_schema_not_live_H2_inference',
              'sensor_raw_history_days': 33,
              'returning_channel_metadata_lag_parity': True, 'insufficient_history_rejected': True,
              'live_backend_deployed': False, 'full_stress_protocol_complete': False,
              'operational_ready': False, 'bundle_sha256': artifacts.zip_sha256}
    return checks


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default='.')
    parser.add_argument('--output', default='acceptance/integration_acceptance.json')
    args = parser.parse_args()
    result = verify(args.root)
    atomic_json(args.output, result)
    print(json.dumps(result))
