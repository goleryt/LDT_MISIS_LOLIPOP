"""Finite daily observation overlays with separate synthetic latent truth.

Run full generation in Kaggle. This module never trains a model or changes the
real journal. Link and power symptoms are also emitted for benign counterexamples.
"""
from __future__ import annotations

import hashlib
from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from .contracts import (CHANNEL, COUNT_COLUMNS, DAILY_COLUMNS, DAY, NUMERIC_COLUMNS, OBJECT, PARTITIONS,
                        SENSOR_TYPE, SYSTEM_TYPE, TIMEZONE, Coverage, GeneratorConfig,
                        ContractError, as_date)
from .daily import adapt_cached_panel, to_pandas
from .features import GROUP_PATTERNS, build_features

EPISODE_COLUMNS = ["episode_id", "incident_type", "entity_key", OBJECT, CHANNEL,
                   "onset", "end", "precursor_start", "recovery_end", "family", "seed",
                   "unsignaled", "partition", "challenge"]
OVERLAY_COLUMNS = [DAY, CHANNEL, OBJECT, SENSOR_TYPE, SYSTEM_TYPE, "episode_id", "overlay_kind",
                   *["delta_" + c for c in COUNT_COLUMNS], "numeric_shift", "numeric_flatline",
                   "numeric_std_multiplier"]


def _hash(*parts: Any) -> str:
    return hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).hexdigest()


def _rng(seed: int, *parts: Any) -> np.random.Generator:
    return np.random.default_rng(int(_hash(seed, *parts)[:16], 16))


def heldout_objects(daily: Any, share: float = 0.20) -> set[str]:
    """Stable hash sample of the TRAIN roster; future-only objects never enter."""
    if not 0 <= share < 1:
        raise ContractError("INVALID_HELDOUT_SHARE")
    data = adapt_cached_panel(daily)
    lo, hi = PARTITIONS["train"]
    roster = data.loc[(data[DAY] >= lo) & (data[DAY] < hi), OBJECT].dropna().unique()
    threshold = int(share * 2**256)
    return {v for v in roster if int(_hash("heldout-object-v1", v), 16) < threshold}


def fit_train_scales(daily: Any, *, heldout_share: float = 0.20) -> dict[str, float]:
    """Optional within-type physical amplitudes fitted strictly on TRAIN rows.

    The returned mapping must be frozen and passed unchanged to all partitions.
    No identifier or scale is ever copied to the feature matrix.
    """
    data = adapt_cached_panel(daily)
    lo, hi = PARTITIONS["train"]
    excluded = heldout_objects(data, heldout_share)
    train = data[(data[DAY] >= lo) & (data[DAY] < hi) & data.n_numeric.gt(0)
                 & ~data[OBJECT].isin(excluded)]
    scales = {}
    for kind, group in train.groupby(SENSOR_TYPE):
        spread = group.num_std.fillna(0).clip(lower=0)
        positive = spread[spread > 0]
        scales[str(kind)] = float(positive.median()) if len(positive) else 0.0
    return scales


def _amplitude(kind: str, scales: dict[str, float] | None) -> float:
    if "газ" in kind.lower():
        return 0.15  # percentage points; taxonomy declares gas percent units
    if "температ" in kind.lower() or "тепл" in kind.lower():
        return 2.0  # degrees for named temperature channels
    return float((scales or {}).get(kind, 0.0))


def _partition(onset: date, config: GeneratorConfig) -> str | None:
    # Reserve the maximum span, even when a sampled episode is shorter.
    start = onset - timedelta(days=config.precursor_max_days)
    end = onset + timedelta(days=config.incident_max_days + config.recovery_max_days)
    for name, (lo, hi) in PARTITIONS.items():
        if lo <= start and end <= hi:
            return name
    return None


def _midnight(d: date) -> datetime:
    return datetime.combine(d, time(), ZoneInfo(TIMEZONE))


def _patch(meta: pd.Series, d: date, episode_id: str | None, kind: str,
           head: str, strength: float, family: str, scales: dict[str, float] | None) -> dict[str, Any]:
    row = {DAY: d, CHANNEL: meta[CHANNEL], OBJECT: meta[OBJECT], SENSOR_TYPE: meta[SENSOR_TYPE],
           SYSTEM_TYPE: meta[SYSTEM_TYPE], "episode_id": episode_id, "overlay_kind": kind,
           **{"delta_" + c: 0 for c in COUNT_COLUMNS}, "numeric_shift": 0.0,
           "numeric_flatline": False, "numeric_std_multiplier": 1.0}
    symptom = max(1, int(round(4 * strength)))
    if kind == "benign_service":
        row.update(delta_n_events=symptom * 2, delta_n_service=symptom, delta_n_power_off=symptom)
        return row
    if kind == "benign_communication":
        row.update(delta_n_events=symptom, delta_n_link_fault=symptom)
        return row
    if head in {"fire", "flood", "intrusion"}:
        row.update(delta_n_events=symptom, delta_n_alarm=symptom)
    elif head == "sensor_failure":
        row.update(delta_n_events=symptom * 2, delta_n_link_fault=symptom, delta_n_tech_like=symptom)
    else:
        row.update(delta_n_events=symptom * 2, delta_n_power_off=symptom, delta_n_link_fault=symptom)
    if head != "intrusion":
        amp = _amplitude(str(meta[SENSOR_TYPE]), scales)
        # Channel-unit changes only; missing numeric observations remain missing.
        row["numeric_shift"] = amp * strength * (1.0 if family != "B" else -0.5)
        if head == "sensor_failure" and family == "B":
            row["numeric_flatline"] = True
        if family == "C":
            row["numeric_std_multiplier"] = 1.0 + strength
    return row


def generate_scenarios(daily: Any, head: str, config: GeneratorConfig, coverage: Coverage,
                       *, scales: dict[str, float] | None = None,
                       frozen_heldout: set[str] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Sample hazard on eligible D rows, then retain all emitted episode truth.

    Onset is D+3. Unsignaled draws use a separate random stream independent of
    visible values. Families A/B fit; C is admitted only in the test partition.
    Sparse overlays may create an observed day on a channel already known at D.
    """
    data = adapt_cached_panel(daily)
    features = build_features(data, head, coverage)
    heldout = heldout_objects(data, config.heldout_object_share) if frozen_heldout is None else set(frozen_heldout)
    candidates = features[features.eligible].sort_values(["as_of_date", "entity_key"])
    by_channel = {k: g.sort_values(DAY) for k, g in data.groupby(CHANNEL)}
    # Metadata index is causal at D; no future catalogue membership participates.
    by_object = ({k: g.sort_values(DAY) for k, g in data[data[OBJECT].notna()].groupby(OBJECT)}
                 if head != "sensor_failure" else {})
    patches, episodes, last_onset = [], [], {}
    audit = {"seed": config.seed, "config": config.to_dict(), "eligible_entity_days": int(len(candidates)),
             "hazard_trials": 0, "hazard_draws": 0, "spacing_rejections": 0, "boundary_rejections": 0,
             "family_rejections": 0, "heldout_rejections": 0, "benign_counterexamples": 0,
             "visible_at_forecast_cutoff": 0,
             "scale_source": "frozen_train_mapping" if scales is not None else "fixed_physical_units",
             "frozen_scales": dict(scales or {}), "heldout_object_count": len(heldout),
             "heldout_challenge_available": bool(heldout), "emitted_episodes": 0}
    for row in candidates.itertuples(index=False):
        d, entity = row.as_of_date, row.entity_key
        onset = d + timedelta(days=3)
        partition = _partition(onset, config)
        if partition is None or onset - timedelta(days=config.precursor_max_days) < coverage.start or onset + timedelta(days=config.incident_max_days + config.recovery_max_days) > coverage.end_exclusive:
            audit["boundary_rejections"] += 1
            continue
        if partition != "test" and getattr(row, OBJECT) in heldout:
            audit["heldout_rejections"] += 1
            continue
        families = tuple(f for f in config.families if f != "C" or partition == "test")
        if not families:
            audit["family_rejections"] += 1
            continue
        audit["hazard_trials"] += 1
        hazard_hit = int(_hash(config.seed, head, entity, d, "hazard")[:16], 16) / 2**64 < config.onset_hazard
        benign_hit = int(_hash(config.seed, head, entity, d, "benign")[:16], 16) / 2**64 < config.onset_hazard
        if not hazard_hit and not benign_hit:
            continue
        history = by_channel[entity] if head == "sensor_failure" else by_object[entity]
        known = history[(history[DAY] <= d) & (history[DAY] >= d - timedelta(days=29))]
        meta = known.groupby(CHANNEL, sort=True).tail(1)
        if head != "sensor_failure":
            current = []
            for channel in meta[CHANNEL]:
                channel_past = by_channel[channel]
                channel_past = channel_past[channel_past[DAY] <= d]
                latest = channel_past.iloc[-1]
                if latest[OBJECT] == entity:
                    current.append(latest)
            if not current:
                continue
            meta = pd.DataFrame(current)
            text = meta[SENSOR_TYPE].fillna("") + " " + meta[SYSTEM_TYPE].fillna("")
            meta = meta[text.str.contains(GROUP_PATTERNS[head], case=False, regex=True)]
        if meta.empty:
            continue
        benign = _rng(config.seed, head, entity, d, "benign-kind")
        if benign_hit:
            kind = str(benign.choice(["benign_service", "benign_communication", "benign_precursor"]))
            for _, sensor in meta.iterrows():
                patches.append(_patch(sensor, d, None, kind, head, 1.0, "A", scales))
            audit["benign_counterexamples"] += 1
        draw = _rng(config.seed, head, entity, d, "hazard")
        if not hazard_hit:
            continue
        audit["hazard_draws"] += 1
        if entity in last_onset and (onset - last_onset[entity]).days < config.min_onset_spacing_days:
            audit["spacing_rejections"] += 1
            continue
        family = str(draw.choice(families))
        unsignaled = bool(_rng(config.seed, head, entity, d, "unsignaled").random() < config.unsignaled_share)
        precursor_days = int(draw.integers(min(3, config.precursor_max_days), config.precursor_max_days + 1))
        incident_days = int(draw.integers(1, config.incident_max_days + 1))
        recovery_days = int(draw.integers(1, config.recovery_max_days + 1))
        precursor_start = onset - timedelta(days=precursor_days)
        end, recovery_end = onset + timedelta(days=incident_days), onset + timedelta(days=incident_days + recovery_days)
        episode_id = _hash("scenario-v1", config.seed, head, entity, onset, family, config.challenge)[:24]
        episodes.append({"episode_id": episode_id, "incident_type": head, "entity_key": entity,
                         OBJECT: getattr(row, OBJECT), CHANNEL: entity if head == "sensor_failure" else None,
                         "onset": _midnight(onset), "end": _midnight(end),
                         "precursor_start": _midnight(precursor_start), "recovery_end": _midnight(recovery_end),
                         "family": family, "seed": config.seed, "unsignaled": unsignaled,
                         "partition": partition, "challenge": config.challenge})
        last_onset[entity] = onset
        if not unsignaled and precursor_start <= d:
            audit["visible_at_forecast_cutoff"] += 1
        for dt in pd.date_range(precursor_start, recovery_end - timedelta(days=1)):
            day = dt.date()
            if day < onset:
                if unsignaled:
                    continue
                kind, strength = "precursor", (day - precursor_start).days / precursor_days + 0.25
                if family == "B":
                    strength *= 1.0 if day.day % 2 else 0.5
                if family == "C":
                    strength = 0.7 if day >= onset - timedelta(days=4) else 0.0
                    if strength == 0:
                        continue
            elif day < end:
                kind, strength = "incident", 1.5
            else:
                kind, strength = "recovery", (recovery_end - day).days / recovery_days * 0.5
            for _, sensor in meta.iterrows():
                sensor_history = by_channel[sensor[CHANNEL]]
                past = sensor_history[(sensor_history[DAY] <= min(day, d))
                                      & (sensor_history[DAY] >= min(day, d) - timedelta(days=29))]
                if past.empty:
                    continue
                causal_meta = past.iloc[-1]
                if head != "sensor_failure" and causal_meta[OBJECT] != entity:
                    continue
                patches.append(_patch(causal_meta, day, episode_id, kind, head, strength, family, scales))
    ep = pd.DataFrame(episodes, columns=EPISODE_COLUMNS)
    overlays = pd.DataFrame(patches, columns=OVERLAY_COLUMNS)
    audit["emitted_episodes"] = len(ep)
    audit["achieved_onset_rate"] = len(ep) / audit["hazard_trials"] if audit["hazard_trials"] else 0.0
    audit["achieved_onset_rate_all_eligible"] = len(ep) / len(candidates) if len(candidates) else 0.0
    audit["achieved_hazard_draw_rate"] = audit["hazard_draws"] / audit["hazard_trials"] if audit["hazard_trials"] else 0.0
    audit["achieved_unsignaled_share"] = float(ep.unsignaled.mean()) if len(ep) else None
    audit["overlay_rows"] = len(overlays)
    return overlays, ep, audit


def apply_overlays(daily: Any, overlays: Any) -> pd.DataFrame:
    """Apply observation changes only; recompute flags and validate all invariants."""
    data, patches = adapt_cached_panel(daily), to_pandas(overlays)
    if patches.empty:
        return data
    if set(patches) - set(OVERLAY_COLUMNS):
        raise ContractError("UNSUPPORTED_OVERLAY_COLUMN")
    if not {DAY, CHANNEL} <= set(patches):
        raise ContractError("OVERLAY_KEYS_MISSING")
    patches[DAY] = patches[DAY].map(as_date)
    keys = [CHANNEL, DAY]
    delta_cols = ["delta_" + c for c in COUNT_COLUMNS]
    for c in delta_cols:
        if c not in patches:
            patches[c] = 0
        original = patches[c]
        converted = pd.to_numeric(original, errors="coerce")
        if (original.notna() & converted.isna()).any():
            raise ContractError("INVALID_OVERLAY_COUNT_DELTA")
        patches[c] = converted.fillna(0)
        if (~np.isfinite(patches[c]) | (patches[c] < 0) | (patches[c] % 1 != 0)).any():
            raise ContractError("INVALID_OVERLAY_COUNT_DELTA")
    defaults = {"numeric_shift": 0.0, "numeric_flatline": False, "numeric_std_multiplier": 1.0}
    for c, default in defaults.items():
        if c not in patches:
            patches[c] = default
        patches[c] = patches[c].fillna(default)
    if (~np.isfinite(patches.numeric_shift) | ~np.isfinite(patches.numeric_std_multiplier)
            | patches.numeric_std_multiplier.lt(0)).any():
        raise ContractError("INVALID_OVERLAY_NUMERIC_CHANGE")
    grouped = patches.groupby(keys, sort=False)
    change = grouped[delta_cols + ["numeric_shift"]].sum()
    change["numeric_flatline"] = grouped.numeric_flatline.max()
    change["numeric_std_multiplier"] = grouped.numeric_std_multiplier.prod()
    base = data.set_index(keys)
    extra_keys = change.index.difference(base.index)
    if len(extra_keys):
        if not {OBJECT, SENSOR_TYPE, SYSTEM_TYPE} <= set(patches):
            raise ContractError("NEW_OVERLAY_ROW_METADATA_MISSING")
        extra = pd.DataFrame(index=extra_keys, columns=base.columns)
        meta = grouped[[OBJECT, SENSOR_TYPE, SYSTEM_TYPE]].first()
        extra[[OBJECT, SENSOR_TYPE, SYSTEM_TYPE]] = meta.reindex(extra_keys)
        extra[list(COUNT_COLUMNS)] = 0
        extra[["row_present", "source_covered", "numeric_missing"]] = True
        base = pd.concat([base, extra])
    changed = base.loc[change.index].copy()
    changed[list(NUMERIC_COLUMNS)] = changed[list(NUMERIC_COLUMNS)].apply(pd.to_numeric)
    for c in COUNT_COLUMNS:
        changed[c] = pd.to_numeric(changed[c]) + change["delta_" + c]
    numeric = changed.n_numeric.gt(0)
    gas = changed[SENSOR_TYPE].fillna("").str.contains("газ", case=False)
    for c in ("num_min", "num_mean", "num_max", "num_last", "gas_max", "gas_last"):
        values = pd.to_numeric(changed[c]) + change.numeric_shift
        values = values.where(~gas, values.clip(0, 100))
        changed.loc[numeric, c] = values.loc[numeric]
    flat = numeric & change.numeric_flatline.astype(bool)
    for c in ("num_min", "num_mean", "num_max"):
        changed.loc[flat, c] = changed.loc[flat, "num_last"]
    for c in ("gas_max", "gas_last"):
        changed.loc[flat & gas, c] = changed.loc[flat & gas, "num_last"]
    upper = (changed.num_max - changed.num_min) / 2 * np.sqrt(changed.n_numeric / (changed.n_numeric - 1).clip(lower=1))
    changed["num_std"] = np.minimum(pd.to_numeric(changed.num_std) * change.numeric_std_multiplier, upper)
    changed.loc[flat, "num_std"] = 0.0
    changed["row_present"] = True
    changed["numeric_missing"] = ~numeric
    base.loc[change.index, changed.columns] = changed
    return adapt_cached_panel(base.reset_index())


def attach_targets(features: Any, episodes: Any) -> pd.DataFrame:
    """Exactly onset in [D+3,D+4); no future eligibility/competing-event filter."""
    out, ep = to_pandas(features), to_pandas(episodes)
    keys = set()
    if not ep.empty:
        for row in ep.itertuples(index=False):
            onset = pd.Timestamp(row.onset)
            if onset.tzinfo is None:
                raise ContractError("EPISODE_ONSET_REQUIRES_TIMEZONE")
            day = onset.tz_convert(TIMEZONE).date() - timedelta(days=3)
            keys.add((row.incident_type, row.entity_key, day))
    out["target"] = [int((r.incident_type, r.entity_key, as_date(r.as_of_date)) in keys)
                               for r in out.itertuples(index=False)]
    return out
