"""Forecast-window and emitted-episode evaluation for synthetic scenarios."""
from __future__ import annotations

from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd

from .contracts import ContractError, PRIMARY_SEED, TIMEZONE, forecast_times


def _context(frame: pd.DataFrame, episodes: pd.DataFrame, head: str | None):
    columns = ["incident_type", "entity_key", "d_object_key", "as_of_date", "score", "eligible", "target", "abstain_reason"]
    if "issued_at" in frame:
        columns.append("issued_at")
    f = frame[columns].copy()
    if head is not None:
        f = f[f.incident_type == head]
    kinds = set(f.incident_type.unique()) if head is None else {head}
    e = episodes[episodes.incident_type.isin(kinds)].copy()
    if e.episode_id.duplicated().any():
        raise ContractError("DUPLICATE_EPISODE_ID")
    if f.duplicated(["incident_type", "entity_key", "as_of_date"]).any():
        raise ContractError("DUPLICATE_FORECAST_ROW")
    finite = np.isfinite(pd.to_numeric(f.score, errors="coerce"))
    missing_score = f.eligible.astype(bool) & ~finite
    f.loc[missing_score, "eligible"] = False
    f.loc[missing_score, "abstain_reason"] = "MODEL_NO_SCORE"
    valid = f.eligible.astype(bool) & finite
    columns = ["incident_type", "entity_key", "d_object_key", "as_of_date", "score"]
    if "issued_at" in f:
        columns.append("issued_at")
    candidates = f.loc[valid, columns].copy()
    times_cache, times_rows = {}, []
    for row in candidates.itertuples(index=False):
        supplied = getattr(row, "issued_at", None)
        supplied = None if supplied is None or pd.isna(supplied) else supplied
        key = str(row.as_of_date), str(supplied)
        if key not in times_cache:
            times_cache[key] = forecast_times(row.as_of_date, supplied, replay=supplied is None)
        times_rows.append(times_cache[key])
    if len(candidates):
        for column in ("issued_at", "window_start", "window_end_exclusive", "actual_min_lead_hours", "late"):
            candidates[column] = [r[column] for r in times_rows]
        late_index = candidates.index[candidates.late]
        f.loc[late_index, "eligible"] = False
        f.loc[late_index, "abstain_reason"] = "LATE_RUN"
        candidates["_issue_order"] = pd.to_datetime(candidates.issued_at, utc=True)
        candidates = candidates[~candidates.late].sort_values(["_issue_order", "score", "entity_key"], ascending=[True, False, True], kind="stable")
    lookup = {}
    for row in e.itertuples(index=False):
        onset = pd.Timestamp(row.onset)
        if onset.tzinfo is None:
            raise ContractError("EPISODE_ONSET_REQUIRES_TIMEZONE")
        lookup.setdefault((row.incident_type, row.entity_key), []).append((onset, row.episode_id))
    for entries in lookup.values():
        entries.sort()
    return f, e, candidates, lookup


def _prepared(frame: pd.DataFrame, episodes: pd.DataFrame, threshold: float,
              cooldown_days: int, head: str | None = None, context=None):
    f, e, candidates, lookup = context if context is not None else _context(frame, episodes, head)
    if cooldown_days < 0:
        raise ContractError("INVALID_COOLDOWN")
    alerts, last = [], {}
    for row in candidates.loc[candidates.score >= threshold].to_dict("records"):
        key = (row["incident_type"], row["entity_key"])
        issued = pd.Timestamp(row["issued_at"])
        if key in last and issued - last[key] < timedelta(days=cooldown_days):
            continue
        last[key] = issued
        alerts.append(row)
    matched = set()
    for row in alerts:
        start, end = pd.Timestamp(row["window_start"]), pd.Timestamp(row["window_end_exclusive"])
        issued = pd.Timestamp(row["issued_at"])
        row["matched_episode_id"] = None
        for onset, episode_id in lookup.get((row["incident_type"], row["entity_key"]), []):
            if episode_id not in matched and start <= onset < end and onset - issued >= timedelta(hours=24):
                matched.add(episode_id)
                row["matched_episode_id"] = episode_id
                break
    return f, e, alerts, matched


def _counts(alerts, episodes, matched):
    tp, fp, fn = len(matched), len(alerts) - len(matched), len(episodes) - len(matched)
    return {"tp": tp, "fp": fp, "fn": fn,
            "event_precision": tp / (tp + fp) if tp + fp else 0.0,
            "event_recall": tp / (tp + fn) if tp + fn else 0.0,
            "event_f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0}


def evaluate_head(frame_with_score: pd.DataFrame, episodes: pd.DataFrame, *, threshold: float,
                  cooldown_days: int = 3, bootstrap_replicates: int = 200,
                  head: str | None = None, seed: int = PRIMARY_SEED) -> dict[str, Any]:
    f, e, alerts, matched = _prepared(frame_with_score, episodes, threshold, cooldown_days, head)
    metrics = _counts(alerts, e, matched)
    scored = f[f.eligible.astype(bool) & np.isfinite(pd.to_numeric(f.score, errors="coerce"))]
    y, p = scored.target.to_numpy(dtype=int), scored.score.to_numpy(dtype=float)
    if not np.isin(y, [0, 1]).all():
        raise ContractError("INVALID_TARGET")
    if len(p) and ((p < 0).any() or (p > 1).any()):
        raise ContractError("SCORE_OUT_OF_RANGE")
    ece = 0.0
    for left, right in zip(np.linspace(0, 1, 11)[:-1], np.linspace(0, 1, 11)[1:]):
        mask = (p >= left) & ((p < right) if right < 1 else (p <= right))
        if mask.any():
            ece += float(mask.mean()) * abs(float(p[mask].mean() - y[mask].mean()))
    attention = {}
    for alert in alerts:
        issue_day = pd.Timestamp(alert["issued_at"]).tz_convert(TIMEZONE).date().isoformat()
        attention.setdefault(issue_day, set()).add(str(alert["d_object_key"]))
    reasons = f.loc[~f.eligible.astype(bool), "abstain_reason"].fillna("UNSPECIFIED").value_counts().to_dict()
    metrics.update({"scored_entity_days": len(scored), "all_entity_days": len(f),
                    "positive_scored_days": int(y.sum()), "emitted_events": len(e),
                    "alert_episodes": len(alerts), "matched_events": len(matched),
                    "average_precision": _average_precision(y, p) if len(y) and len(np.unique(y)) == 2 else None,
                    "brier_score": float(np.mean((p - y) ** 2)) if len(y) else None,
                    "ece_10_bins": ece if len(y) else None,
                    "abstain_count": int((~f.eligible.astype(bool)).sum()),
                    "abstain_reasons": {str(k): int(v) for k, v in reasons.items()},
                    "scored_coverage": len(scored) / len(f) if len(f) else 0.0,
                    "threshold": float(threshold), "cooldown_days": cooldown_days,
                    "attention_objects_by_issue_day": {k: len(v) for k, v in attention.items()},
                    "minimum_actual_lead_hours": min((r["actual_min_lead_hours"] for r in alerts), default=None),
                    "fp_meaning": "Unmatched alerts against synthetic truth; real background incidents are unknown.",
                    "calibration_scope": "Declared primary synthetic mixture only."})
    metrics["confidence_intervals"] = _bootstrap(f, e, alerts, bootstrap_replicates, seed)
    return metrics


def _average_precision(y, p):
    order = np.argsort(-p, kind="stable")
    y, p = y[order], p[order]
    ends = np.append(np.flatnonzero(np.diff(p)), len(p) - 1)
    true = np.cumsum(y)[ends]
    precision = true / (ends + 1)
    increments = np.diff(np.append(0, true)) / int(y.sum())
    return float(np.sum(increments * precision))


def _bootstrap(frame, episodes, alerts, replicates, seed):
    """Resample fixed, paired object/30-day units; never split an episode."""
    if replicates < 2:
        return {"status": "not_requested"}
    counts = {}
    def block(obj, stamp):
        return str(obj), int(pd.Timestamp(stamp).date().toordinal() // 30)
    for row in frame[["d_object_key", "as_of_date"]].drop_duplicates().itertuples(index=False):
        counts.setdefault(block(row.d_object_key, pd.Timestamp(row.as_of_date) + timedelta(days=3)), [0, 0, 0])
    episode_blocks = {}
    for row in episodes.itertuples(index=False):
        key = block(row.d_object_key, row.onset)
        episode_blocks[row.episode_id] = key
        counts.setdefault(key, [0, 0, 0])[2] += 1
    for alert in alerts:
        episode = alert["matched_episode_id"]
        key = episode_blocks[episode] if episode is not None else block(alert["d_object_key"], alert["window_start"])
        value = counts.setdefault(key, [0, 0, 0])
        value[1] += 1
        if episode is not None:
            value[0] += 1
    objects = {key[0] for key in counts}
    event_objects = {key[0] for key, value in counts.items() if value[2] > 0}
    if len(counts) < 10 or len(objects) < 5 or len(event_objects) < 5:
        return {"status": "suppressed_insufficient_independent_blocks", "blocks": len(counts), "objects": len(objects)}
    array = np.asarray([counts[key] for key in sorted(counts)], dtype=float)
    rng = np.random.default_rng(seed)
    results = []
    for _ in range(replicates):
        tp, n_alerts, n_events = array[rng.integers(0, len(array), len(array))].sum(axis=0)
        results.append([tp / n_alerts if n_alerts else 0.0, tp / n_events if n_events else 0.0,
                        2 * tp / (n_alerts + n_events) if n_alerts + n_events else 0.0])
    bounds = np.quantile(results, [0.025, 0.975], axis=0)
    return {"status": "block_bootstrap", "unit": "object_30_calendar_days_whole_episodes",
            "blocks": len(array), "objects": len(objects), "replicates": replicates,
            **{name: bounds[:, i].tolist() for i, name in enumerate(("event_precision", "event_recall", "event_f1"))}}


def select_threshold(frame_with_score: pd.DataFrame, episodes: pd.DataFrame, head: str | None = None,
                     *, cooldown_days: int = 3, max_thresholds: int = 201) -> float:
    f = frame_with_score if head is None else frame_with_score[frame_with_score.incident_type == head]
    scores = f.loc[f.eligible.astype(bool), "score"].to_numpy(dtype=float)
    scores = scores[np.isfinite(scores)]
    if not len(scores):
        return 1.0 + np.finfo(float).eps
    unique = np.unique(scores)
    values = unique if len(unique) <= max_thresholds else np.unique(np.quantile(unique, np.linspace(0, 1, max_thresholds)))
    values = np.append(values, np.nextafter(float(unique.max()), np.inf))
    best = (-1.0, -1.0)
    context = _context(f, episodes, head)
    fast = _threshold_groups(context, cooldown_days)
    for threshold in values:
        if fast is None:
            _, e, alerts, matched = _prepared(f, episodes, float(threshold), cooldown_days, head, context)
            score = _counts(alerts, e, matched)["event_f1"]
        else:
            groups, cooldown_ns = fast
            tp, n_alerts = _threshold_counts(groups, float(threshold), cooldown_ns)
            denominator = n_alerts + len(context[1])
            score = 2 * tp / denominator if denominator else 0.0
        pair = (score, float(threshold))
        best = max(best, pair)
    return best[1]


def _threshold_groups(context, cooldown_days):
    """Prepare the disjoint-window case; retain the original matcher otherwise.

    Each entity has independent cooldown state. When its forecast windows are
    disjoint and each window contains at most one possible match, the number of
    true positives is just the sum of the retained alerts' fixed match flags.
    """
    if cooldown_days < 0:
        raise ContractError("INVALID_COOLDOWN")
    _, _, candidates, lookup = context
    try:
        cooldown = timedelta(days=cooldown_days)
        cooldown_ns = ((cooldown.days * 86400 + cooldown.seconds) * 1_000_000
                       + cooldown.microseconds) * 1000
        groups = []
        if candidates.empty:
            return groups, cooldown_ns
        # Non-string/missing keys retain the exact dictionary semantics of the
        # general matcher rather than depending on pandas grouping conventions.
        if not all(isinstance(key, str) for key in candidates.incident_type):
            return None
        if not all(isinstance(key, str) for key in candidates.entity_key):
            return None
        for key, frame in candidates.groupby(["incident_type", "entity_key"], sort=False):
            scores = frame.score.to_numpy()
            if not np.issubdtype(scores.dtype, np.number):
                return None
            issued = np.array([pd.Timestamp(t).value for t in frame.issued_at], dtype=np.int64)
            starts = np.array([pd.Timestamp(t).value for t in frame.window_start], dtype=np.int64)
            ends = np.array([pd.Timestamp(t).value for t in frame.window_end_exclusive], dtype=np.int64)
            if len(frame) > 1 and np.any(starts[1:] < ends[:-1]):
                return None
            day_ns = 24 * 3600 * 1_000_000_000
            if any(int(t) + day_ns > np.iinfo(np.int64).max for t in issued):
                return None
            onsets = np.array([pd.Timestamp(t).value for t, _ in lookup.get(key, [])], dtype=np.int64)
            left = np.searchsorted(onsets, np.maximum(starts, issued + day_ns), side="left")
            right = np.searchsorted(onsets, ends, side="left")
            counts = np.maximum(right - left, 0)
            if np.any(counts > 1):
                return None
            # Keep the original dtype: float32 comparisons round the scalar
            # threshold differently from a promoted float64 score array.
            groups.append((scores, issued, counts == 1))
        return groups, cooldown_ns
    except (OverflowError, ValueError):
        # Timestamp ranges unsupported by nanosecond arrays still work through
        # the existing Timestamp/timedelta implementation.
        return None


def _threshold_counts(groups, threshold, cooldown_ns):
    tp = n_alerts = 0
    for scores, issued, matches in groups:
        selected = np.flatnonzero(scores >= threshold)
        if not len(selected):
            continue
        if cooldown_ns == 0:
            n_alerts += len(selected)
            tp += int(matches[selected].sum())
            continue
        times = issued[selected]
        position = 0
        while position < len(selected):
            n_alerts += 1
            tp += int(matches[selected[position]])
            next_issue = int(times[position]) + cooldown_ns
            if next_issue > np.iinfo(np.int64).max:
                break
            position = int(np.searchsorted(times, next_issue, side="left"))
    return tp, n_alerts
