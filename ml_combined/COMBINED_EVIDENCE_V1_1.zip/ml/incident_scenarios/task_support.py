"""Immutable job checkpoints and bounded workers (Linux process-group monitoring)."""
from __future__ import annotations

import json
import hashlib
import math
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import shutil
import signal
import subprocess
import sys
import tempfile
import time

from .artifacts import fingerprint, sha256
from .contracts import ContractError


def _relative(name):
    if (not isinstance(name, str) or not name or "\\" in name or ":" in name
            or PurePosixPath(name).is_absolute() or PureWindowsPath(name).drive
            or any(p in {"", ".", ".."} for p in name.split("/"))
            or name == "manifest.json"):
        raise ContractError("UNSAFE_CHECKPOINT_PATH")
    return name


def read_checkpoint(path, identity: dict):
    path = Path(path)
    if path.is_symlink():
        raise ContractError("UNSAFE_CHECKPOINT_PATH")
    if not path.exists():
        return None
    try:
        if path.is_symlink() or not path.is_dir():
            raise ContractError("UNSAFE_CHECKPOINT_PATH")
        if (path / "manifest.json").is_symlink():
            raise ContractError("UNSAFE_CHECKPOINT_PATH")
        manifest = json.loads((path / "manifest.json").read_text(encoding="utf-8"))
        if (manifest["identity"] != identity
                or manifest["fingerprint"] != fingerprint(identity)):
            raise ContractError("CHECKPOINT_IDENTITY_MISMATCH")
        files = manifest["files"]
        if not isinstance(files, dict):
            raise ContractError("CHECKPOINT_FILE_LIST_MISMATCH")
        for name in files:
            _relative(name)
        entries = list(path.rglob("*"))
        if any(p.is_symlink() for p in entries):
            raise ContractError("UNSAFE_CHECKPOINT_PATH")
        actual = {p.relative_to(path).as_posix() for p in entries if p.is_file()}
        if actual != {*files, "manifest.json"}:
            raise ContractError("CHECKPOINT_FILE_LIST_MISMATCH")
        for name, digest in files.items():
            if sha256(path / name) != digest:
                raise ContractError("CHECKPOINT_FILE_MISMATCH")
        return manifest
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise ContractError("INVALID_CHECKPOINT") from error


def write_checkpoint(path, identity: dict, files: dict[str, bytes]):
    path = Path(path)
    if path.exists() or path.is_symlink():
        raise ContractError("CHECKPOINT_ALREADY_EXISTS")
    for name, data in files.items():
        _relative(name)
        if not isinstance(data, bytes):
            raise TypeError("Checkpoint contents must be bytes")
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = Path(tempfile.mkdtemp(prefix=f".{path.name}.pending-", dir=path.parent))
    try:
        for name, data in files.items():
            target = pending / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        manifest = {"identity": identity, "fingerprint": fingerprint(identity),
                    "files": {name: sha256(pending / name) for name in files}}
        (pending / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
        if path.exists() or path.is_symlink():
            raise ContractError("CHECKPOINT_ALREADY_EXISTS")
        pending.rename(path)
        return manifest
    finally:
        if pending.exists():
            shutil.rmtree(pending)


def write_checkpoint_from_directory(path, identity: dict, source_root):
    """Publish every source file using bounded streaming copies and hashes."""
    path, source_root = Path(path), Path(source_root)
    if path.exists() or path.is_symlink():
        raise ContractError("CHECKPOINT_ALREADY_EXISTS")
    if source_root.is_symlink() or not source_root.is_dir():
        raise ContractError("UNSAFE_CHECKPOINT_PATH")
    if (source_root / "manifest.json").exists() or (source_root / "manifest.json").is_symlink():
        raise ContractError("UNSAFE_CHECKPOINT_PATH")
    entries = sorted(source_root.rglob("*"))
    sources = {}
    for entry in entries:
        if entry.is_symlink() or not (entry.is_file() or entry.is_dir()):
            raise ContractError("UNSAFE_CHECKPOINT_PATH")
        if entry.is_file():
            sources[_relative(entry.relative_to(source_root).as_posix())] = entry
    # The pending directory must never become part of its own source tree.
    if path.resolve().is_relative_to(source_root.resolve()):
        raise ContractError("UNSAFE_CHECKPOINT_PATH")
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = Path(tempfile.mkdtemp(prefix=f".{path.name}.pending-", dir=path.parent))
    try:
        hashes = {}
        for name, source in sources.items():
            target = pending / name
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with source.open("rb") as incoming, target.open("wb") as outgoing:
                for block in iter(lambda: incoming.read(1024 * 1024), b""):
                    outgoing.write(block)
                    digest.update(block)
            hashes[name] = digest.hexdigest()
        manifest = {"identity": identity, "fingerprint": fingerprint(identity), "files": hashes}
        (pending / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
        if path.exists() or path.is_symlink():
            raise ContractError("CHECKPOINT_ALREADY_EXISTS")
        pending.rename(path)
        return manifest
    finally:
        if pending.exists():
            shutil.rmtree(pending)


def _linux_processes():
    result = {}
    page_size = os.sysconf("SC_PAGE_SIZE")
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
            result[int(entry.name)] = (int(fields[1]), int(fields[2]), int(fields[19]),
                                      max(0, int(fields[21])) * page_size, fields[0])
        except (OSError, ValueError, IndexError):
            continue
    return result


def _linux_tree(process, tracked):
    """Follow PPIDs and observed groups, retaining orphans by PID/start identity."""
    table = _linux_processes()
    selected = {pid for pid, start in tracked.items()
                if pid in table and table[pid][2] == start}
    if process.returncode is None and process.pid in table:
        selected.add(process.pid)
    caller_group = os.getpgrp()
    while True:
        groups = {table[pid][1] for pid in selected} - {caller_group}
        added = {pid for pid, row in table.items()
                 if row[0] in selected or row[1] in groups}
        if added <= selected:
            break
        selected.update(added)
    tracked.clear()
    tracked.update({pid: table[pid][2] for pid in selected})
    return {pid: table[pid] for pid in selected}


def _rss(process, tracked):
    if sys.platform.startswith("linux"):
        return sum(row[3] for row in _linux_tree(process, tracked).values())
    # Local Windows checks monitor only the direct process, if psutil is present.
    try:
        import psutil
        return psutil.Process(process.pid).memory_info().rss
    except ImportError:
        return 0
    except psutil.Error:
        return 0


def _stop(process, tracked):
    if sys.platform.startswith("linux"):
        def deliver(sig):
            tree = _linux_tree(process, tracked)
            groups = {row[1] for row in tree.values()} - {os.getpgrp()}
            for group in groups:
                try:
                    os.killpg(group, sig)
                except ProcessLookupError:
                    pass
            for pid, row in tree.items():
                if row[1] not in groups and pid != os.getpid():
                    try:
                        os.kill(pid, sig)
                    except ProcessLookupError:
                        pass
        deliver(signal.SIGTERM)
        # Keep the group grace period even if the group leader exits first.
        until = time.monotonic() + 0.5
        while time.monotonic() < until:
            process.poll()
            time.sleep(0.025)
        deliver(signal.SIGKILL)
    elif process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            process.kill()
    try:
        process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        # SIGKILL can remain pending in uninterruptible kernel I/O. The caller
        # still needs a bounded return; returncode=None records that condition.
        pass


def run_worker(command: list[str], *, log_path, timeout_seconds: float,
               max_rss_bytes: int) -> dict:
    if max_rss_bytes <= 0:
        raise ValueError("max_rss_bytes must be positive")
    if not math.isfinite(timeout_seconds):
        raise ValueError("timeout_seconds must be finite")
    start, peak = time.monotonic(), 0
    if timeout_seconds <= 0:
        return {"status": "timed_out", "returncode": None,
                "elapsed_seconds": 0.0, "peak_rss_bytes": 0}
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("ab", buffering=0) as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=sys.platform.startswith("linux"))
        tracked = {}
        status = None
        try:
            while True:
                peak = max(peak, _rss(process, tracked))
                if peak > max_rss_bytes:
                    status = "memory_exceeded"
                    break
                if time.monotonic() - start >= timeout_seconds:
                    status = "timed_out"
                    break
                if process.poll() is not None:
                    living_children = (sys.platform.startswith("linux") and
                                       any(row[4] != "Z" for row in _linux_tree(process, tracked).values()))
                    if not living_children:
                        status = "completed" if process.returncode == 0 else "failed"
                        break
                time.sleep(min(0.1, max(0.0, timeout_seconds - (time.monotonic() - start))))
        finally:
            if status not in {"completed", "failed"}:
                _stop(process, tracked)
        return {"status": status, "returncode": process.returncode,
                "elapsed_seconds": time.monotonic() - start, "peak_rss_bytes": peak}
