"""Allowlisted daily observations; no old states, rolling features, or labels."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .contracts import (CHANNEL, COUNT_COLUMNS, DAILY_COLUMNS, DAY, NUMERIC_COLUMNS,
                        OBJECT, SENSOR_TYPE, SYSTEM_TYPE, ContractError)


def to_pandas(frame: Any) -> pd.DataFrame:
    if isinstance(frame, pd.DataFrame):
        return frame.copy()
    if hasattr(frame, "to_pandas"):
        try:
            return frame.to_pandas()
        except ModuleNotFoundError as exc:
            if exc.name != "pyarrow" or not hasattr(frame, "to_dict"):
                raise
            return pd.DataFrame(frame.to_dict(as_series=False))
    return pd.DataFrame(frame)


def adapt_cached_panel(frame: Any) -> pd.DataFrame:
    """Select daily facts from FULL v3. Source coverage is declared separately.

    Legacy v3 zero-event rows are an artificial seven-day grid, not source
    observations, and are removed. Explicit canonical row_present flags preserve
    genuine present zero-event rows. Missing coverage flags apply supplied rows.
    """
    data = to_pandas(frame)
    required = set(DAILY_COLUMNS) - {"row_present", "source_covered", "numeric_missing"}
    if missing := required - set(data):
        raise ContractError("DAILY_COLUMNS_MISSING:" + ",".join(sorted(missing)))
    data = data.loc[:, [c for c in DAILY_COLUMNS if c in data]].copy()
    try:
        data[DAY] = pd.to_datetime(data[DAY], errors="raise").dt.date
    except (ValueError, TypeError) as exc:
        raise ContractError("INVALID_DAILY_DATE") from exc
    for c in COUNT_COLUMNS + NUMERIC_COLUMNS:
        try:
            data[c] = pd.to_numeric(data[c], errors="raise")
        except (ValueError, TypeError) as exc:
            raise ContractError("INVALID_DAILY_NUMERIC:" + c) from exc
    legacy_grid = "row_present" not in data
    for c in ("row_present", "source_covered"):
        if c not in data:
            data[c] = data.n_events.gt(0) if c == "row_present" else True
    if "numeric_missing" not in data:
        data["numeric_missing"] = data["n_numeric"].eq(0)
    validate_daily(data)
    if legacy_grid:
        data = data[data.row_present].copy()
    for c in COUNT_COLUMNS:
        data[c] = data[c].astype("int64")
    return data.loc[:, list(DAILY_COLUMNS)].sort_values([CHANNEL, DAY]).reset_index(drop=True)


def validate_daily(frame: Any) -> None:
    data = to_pandas(frame)
    if missing := set(DAILY_COLUMNS) - set(data):
        raise ContractError("DAILY_COLUMNS_MISSING:" + ",".join(sorted(missing)))
    if data[[CHANNEL, DAY]].isna().any().any():
        raise ContractError("DAILY_KEY_MISSING")
    if data.duplicated([CHANNEL, DAY]).any():
        raise ContractError("DUPLICATE_CHANNEL_DAY")
    for c in COUNT_COLUMNS:
        values = pd.to_numeric(data[c], errors="coerce")
        if (values.isna() | ~np.isfinite(values) | (values < 0) | (values % 1 != 0)).any():
            raise ContractError("INVALID_DAILY_COUNT:" + c)
        if c != "n_events" and (values > data["n_events"]).any():
            raise ContractError("COUNT_EXCEEDS_EVENTS:" + c)
    for c in NUMERIC_COLUMNS:
        values = pd.to_numeric(data[c], errors="coerce")
        if (data[c].notna() & (values.isna() | ~np.isfinite(values))).any():
            raise ContractError("INVALID_DAILY_NUMERIC:" + c)
    numeric = data["n_numeric"] > 0
    core = ["num_min", "num_mean", "num_max", "num_last"]
    if data.loc[numeric, core].isna().any().any():
        raise ContractError("NUMERIC_SUMMARY_MISSING")
    if data.loc[~numeric, list(NUMERIC_COLUMNS)].notna().any().any():
        raise ContractError("NUMERIC_SUMMARY_WITHOUT_OBSERVATIONS")
    if ((data.num_min > data.num_mean) | (data.num_mean > data.num_max)
            | (data.num_last < data.num_min) | (data.num_last > data.num_max)
            | (data.num_std < 0)).any():
        raise ContractError("INCONSISTENT_NUMERIC_SUMMARY")
    many = data.n_numeric > 1
    if data.loc[many, "num_std"].isna().any():
        raise ContractError("NUMERIC_STD_MISSING")
    # Sample standard deviation cannot exceed half-range * sqrt(n/(n-1)).
    upper = (data.num_max - data.num_min) / 2 * np.sqrt(data.n_numeric / (data.n_numeric - 1).clip(lower=1))
    if (data.loc[many, "num_std"] > upper.loc[many] + 1e-8).any():
        raise ContractError("NUMERIC_STD_EXCEEDS_RANGE")
    one = data.n_numeric == 1
    if ((data.loc[one, "num_min"] != data.loc[one, "num_max"])
            | (data.loc[one, "num_std"].fillna(0) != 0)).any():
        raise ContractError("INCONSISTENT_SINGLE_OBSERVATION")
    gas = data.gas_max.notna() | data.gas_last.notna()
    if (gas & (~numeric | ~data[SENSOR_TYPE].fillna("").str.contains("газ", case=False))).any():
        raise ContractError("GAS_SUMMARY_WRONG_SENSOR_TYPE")
    if (gas & (data.gas_max.isna() | data.gas_last.isna()
               | (data.gas_last > data.gas_max) | (data.gas_last < data.num_min)
               | (data.gas_max > data.num_max) | (data.gas_last < 0) | (data.gas_max > 100))).any():
        raise ContractError("INCONSISTENT_GAS_SUMMARY")
    gas_sensor = numeric & data[SENSOR_TYPE].eq("Газовый датчик")
    if (gas_sensor & (data.gas_max.isna() | data.gas_last.isna()
                      | (data.gas_max != data.num_max) | (data.gas_last != data.num_last)
                      | (data.num_min < 0) | (data.num_max > 100))).any():
        raise ContractError("GAS_SUMMARY_MISSING_OR_INCONSISTENT")
    for c in ("row_present", "source_covered", "numeric_missing"):
        if data[c].isna().any() or not data[c].isin([True, False, 0, 1]).all():
            raise ContractError("INVALID_DAILY_FLAG:" + c)
    if (data.numeric_missing.astype(bool) != ~numeric).any():
        raise ContractError("INCONSISTENT_NUMERIC_MISSING")
    if ((~data.row_present.astype(bool)) & (data.n_events > 0)).any():
        raise ContractError("EVENTS_WITHOUT_ROW")
    if ((~data.source_covered.astype(bool)) & (data.n_events > 0)).any():
        raise ContractError("EVENTS_OUTSIDE_SOURCE_COVERAGE")


def raw_to_daily(records: Any, catalogue: Any) -> pd.DataFrame:
    """Reuse v3 taxonomy classification and daily aggregation, never its states.

    Emits observed channel-days only. Exact Russian source names and pseudonym
    key salt match v3; this is daily parity, not episode-label equivalence.
    """
    import polars as pl
    from ml.sensor_failure import event_panel_v3 as old

    raw, cat = to_pandas(records), to_pandas(catalogue)
    required = set(old.EVENT_COLUMNS) - {"ид_события"}
    if required - set(raw) or set(old.CATALOGUE_COLUMNS) - set(cat):
        raise ContractError("RAW_SOURCE_COLUMNS_MISSING")
    if cat["ид_канала_данных"].duplicated().any():
        raise ContractError("DUPLICATE_CATALOGUE_CHANNEL")
    tax = old.load_taxonomy(Path(old.__file__).parent / "config" / "state_taxonomy_v3.json")
    raw_pl, cat_pl = pl.from_pandas(raw), pl.from_pandas(cat.loc[:, old.CATALOGUE_COLUMNS])
    ev = old.classify_events(pl, raw_pl, tax, cat_pl)
    if ev.height != len(raw):
        raise ContractError("INVALID_RAW_EVENT_TIMESTAMP")
    agg = old.daily_aggregates(pl, ev, old.second_table(pl, ev, tax), tax)
    agg = agg.with_columns((pl.col("n_tech_value") + pl.col("n_gas_out_of_range")
                           + pl.col("n_undefined_measurement")).alias("n_tech_like"))
    data = to_pandas(agg).rename(columns={"day": DAY})
    metadata = cat.rename(columns={"ид_канала_данных": "ch", "ид_объект": "_raw_object"})
    data = data.merge(metadata, on="ch", how="left", validate="many_to_one")
    data[CHANNEL] = data.ch.map(old.pseudo_key)
    data[OBJECT] = data._raw_object.map(lambda v: None if pd.isna(v) else old.pseudo_key(v))
    return adapt_cached_panel(data)
