"""2025 is read only after models, calibration and thresholds are frozen."""
from __future__ import annotations

from dataclasses import asdict, replace
from datetime import timedelta
import gc
import json
from pathlib import Path

from .artifacts import atomic_json, check_resources, verify_stage, write_stage
from .contracts import (COUNT_COLUMNS, NUMERIC_COLUMNS, DAY, HEADS, OBJECT, PARTITIONS,
                        PRIMARY_SEED, Coverage, GeneratorConfig, ContractError, scenario_evidence)
from .pipeline import (_episodes, _label_features, _read, _resume, _save, _variant, VARIANTS)

# Evaluation-only factors, one at a time; models are never retrained here.
CHALLENGES = {
    "unseen_family_C": {"families": ("C",)},
    "hazard_low": {"onset_hazard": .001},
    "hazard_high": {"onset_hazard": .05},
    "unsignaled_zero": {"unsignaled_share": 0.0},
    "unsignaled_half": {"unsignaled_share": .5},
    "seed_2": {"seed": PRIMARY_SEED + 1},
    "seed_3": {"seed": PRIMARY_SEED + 2},
    "seed_4": {"seed": PRIMARY_SEED + 3},
    "missing_rows": {},
    "delayed_source": {},
}


def _narrow_score(frame, artifact, resources):
    import numpy as np
    from .models import predict_scores
    columns = ["incident_type", "entity_key", OBJECT, "as_of_date", "eligible",
               "abstain_reason", "target", "heldout_object"]
    result = frame[columns].copy()
    result["score"] = np.nan
    if artifact.status == "insufficient_training_support":
        result["eligible"] = False
        result["abstain_reason"] = "MODEL_UNTRAINED"
        return result
    mask = frame.eligible.astype(bool)
    result.loc[mask, "score"] = predict_scores(artifact, frame.loc[mask], batch_rows=resources.evaluation_batch_rows)
    return result


def _stress_observations(daily, challenge):
    """Stress visible observations after generation; truth remains unchanged."""
    import numpy as np
    result = daily.copy()
    if challenge == "missing_rows":
        # Fixed random stream independent of the event labels.
        return result[np.random.default_rng(PRIMARY_SEED + 99).random(len(result)) >= .10].copy()
    if challenge == "delayed_source":
        # One covered-source outage every seven days, no fabricated numeric zeros.
        mask = result[DAY].map(lambda d: d.toordinal() % 7 == 0)
        result.loc[mask, list(COUNT_COLUMNS)] = 0
        result.loc[mask, list(NUMERIC_COLUMNS)] = np.nan
        result.loc[mask, "row_present"] = False
        result.loc[mask, "source_covered"] = False
        result.loc[mask, "numeric_missing"] = True
    return result


def _evaluate_cohorts(frame, episodes, artifact, resources):
    from .evaluation import evaluate_head
    results = {}
    for cohort in ("all", "seen_objects", "heldout_objects"):
        if cohort == "all":
            f, e = frame, episodes
        else:
            f = frame[frame.heldout_object == (cohort == "heldout_objects")]
            e = episodes[episodes.heldout_object == (cohort == "heldout_objects")]
        report = evaluate_head(f, e, threshold=artifact.threshold, head=artifact.head,
                               bootstrap_replicates=resources.bootstrap_replicates)
        report["cohort"] = cohort
        report["support"] = "available" if len(e) and len(f) else "insufficient_support"
        results[cohort] = report
    return results


def _attention_budgets(frame, episodes, artifact):
    import numpy as np
    from .evaluation import evaluate_head
    reports = {}
    for k in (5, 25):
        f = frame.copy()
        valid = f.eligible & f.score.notna() & (f.score >= artifact.threshold)
        selected = f.loc[valid].sort_values(["as_of_date", "score", "entity_key"],
                                           ascending=[True, False, True], kind="stable").groupby("as_of_date", sort=False).head(k).index
        # Budget overflow is explicitly abstained; denominator retains all truth.
        miss = valid & ~f.index.isin(selected)
        f.loc[miss, "eligible"] = False
        f.loc[miss, "abstain_reason"] = "ATTENTION_BUDGET"
        report = evaluate_head(f, episodes, threshold=artifact.threshold, head=artifact.head,
                               bootstrap_replicates=0)
        report["budget_entities_per_day"] = k
        report["unit"] = "channels" if artifact.head == "sensor_failure" else "objects"
        reports[str(k)] = report
    return reports


def stage_evaluate(scenarios, output, *, background, models, mode, resources, environment, code):
    import pandas as pd
    from .bundle import load_bundle
    from .evaluation import _prepared
    from .features import build_features
    from .simulation import generate_scenarios, apply_overlays, attach_targets, heldout_objects
    from .weather import prepare_weather, load_cached_weather
    scenarios, output, background, models = map(Path, (scenarios, output, background, models))
    scenario_m = verify_stage(scenarios, expected_stage="02_scenarios")
    background_m = verify_stage(background, expected_stage="01_background")
    model_m = verify_stage(models, expected_stage="03_fit")
    if model_m["parents"]["scenarios"] != scenario_m["fingerprint"] or scenario_m["parents"]["background"] != background_m["fingerprint"]:
        raise ContractError("EVALUATION_LINEAGE_MISMATCH")
    for manifest in (scenario_m, background_m, model_m):
        from .compatibility import upstream_code_compatible
        if manifest["environment"] != environment or not upstream_code_compatible(manifest, code) or manifest["config"]["mode"] != mode:
            raise ContractError("EVALUATION_RUNTIME_IDENTITY_MISMATCH")
    cfg = {"mode": mode, "challenges": CHALLENGES, "resources": asdict(resources),
           "frozen_thresholds": True, "evidence": scenario_evidence()}
    parents = {"scenarios": scenario_m["fingerprint"], "models": model_m["fingerprint"],
               "background": background_m["fingerprint"]}
    if _resume(output, "04_evaluate", cfg, parents, environment, code):
        return
    coverage = Coverage.from_dict(scenario_m["extra"]["coverage"])
    bundles = {v: load_bundle(models / v / "incident_scenarios_v1.zip") for v in VARIANTS}
    weather = prepare_weather(load_cached_weather())
    primary_alerts = []
    for head in HEADS:
        episodes = _episodes(scenarios, head, "test")
        scored = {v: [] for v in VARIANTS}
        for p in sorted((scenarios / head).glob("*/test.parquet")):
            f = _read(p)
            for variant in VARIANTS:
                scored[variant].append(_narrow_score(_variant(f, variant), bundles[variant][head], resources))
            del f
            check_resources(resources, output)
        for variant in VARIANTS:
            rows = pd.concat(scored.pop(variant), ignore_index=True)
            a = bundles[variant][head]
            report = _evaluate_cohorts(rows, episodes, a, resources)
            report["attention_budgets"] = _attention_budgets(rows, episodes, a)
            atomic_json(output / "metrics" / f"{head}_{variant}_primary.json", report)
            if variant == "sensors_weather":
                _save(rows, output / "primary_scores" / f"{head}.parquet")
                _, _, alerts, _ = _prepared(rows, episodes, a.threshold, 3, head)
                primary_alerts.extend({"issued_at": r["issued_at"], OBJECT: r[OBJECT], "incident_type": head} for r in alerts)
            del rows
        for challenge, settings in CHALLENGES.items():
            parts, truths, audits = [], [], []
            for part in sorted((background / "daily").glob("*.parquet")):
                daily = _read(part)
                frozen_heldout = heldout_objects(daily)
                daily = daily[(daily[DAY] >= PARTITIONS["test"][0] - timedelta(days=30))
                              & (daily[DAY] < PARTITIONS["test"][1])].copy()
                generator = replace(GeneratorConfig(), challenge=challenge, **settings)
                if challenge in {"missing_rows", "delayed_source"}:
                    # Generate truth from the original eligible cohort first.
                    overlays, ep, audit = generate_scenarios(daily, head, generator, coverage, frozen_heldout=frozen_heldout)
                    changed = _stress_observations(apply_overlays(daily, overlays), challenge)
                    f = attach_targets(build_features(changed, head, coverage, weather=weather), ep)
                    f["heldout_object"] = f[OBJECT].isin(frozen_heldout)
                    lo, hi = PARTITIONS["test"]
                    f = f[(f.as_of_date >= lo) & (f.as_of_date + timedelta(days=4) <= hi)]
                else:
                    f, ep, audit = _label_features(daily, head, generator, coverage, weather, frozen_heldout=frozen_heldout)
                    f = f[f.partition == "test"]
                    f["heldout_object"] = f[OBJECT].isin(frozen_heldout)
                ep = ep[ep.partition == "test"]
                ep["heldout_object"] = ep[OBJECT].isin(frozen_heldout)
                parts.append(_narrow_score(f, bundles["sensors_weather"][head], resources))
                truths.append(ep)
                audits.append(audit)
                del f, daily
                gc.collect()
                check_resources(resources, output)
            rows, ep = pd.concat(parts, ignore_index=True), pd.concat(truths, ignore_index=True)
            report = _evaluate_cohorts(rows, ep, bundles["sensors_weather"][head], resources)
            report["audit"] = audits
            report["calibration_interpretation"] = "Not a calibration claim outside the primary simulated mixture."
            atomic_json(output / "metrics" / f"{head}_{challenge}.json", report)
            del rows, ep, parts, truths
            gc.collect()
        print(json.dumps({"stage": "04_evaluate", "head": head, "status": "complete"}))
    combined = {}
    for alert in primary_alerts:
        combined.setdefault(alert["issued_at"][:10], set()).add(alert[OBJECT])
    atomic_json(output / "combined_workload.json", {"unique_objects_by_issue_day": {d: len(v) for d, v in combined.items()},
                "units": "unique_objects_per_day_across_five_heads",
                "scope": "union_of_independent_single_head_benchmarks_not_joint_dispatcher_load",
                "evidence": scenario_evidence()})
    from .comparison import paired_weather_comparison
    for head in HEADS:
        # Controls are scored on the exact same primary cohort above.
        frames = []
        for variant in ("sensors_only", "sensors_weather"):
            a = bundles[variant][head]
            frames.append(pd.concat([_narrow_score(_variant(_read(p), variant), a, resources)
                          for p in sorted((scenarios / head).glob("*/test.parquet"))], ignore_index=True))
        atomic_json(output / "metrics" / f"{head}_paired_weather_comparison.json",
                    paired_weather_comparison(*frames, _episodes(scenarios, head, "test"),
                    sensors_threshold=bundles["sensors_only"][head].threshold,
                    weather_threshold=bundles["sensors_weather"][head].threshold, head=head,
                    replicates=resources.bootstrap_replicates))
    _joint_evaluation(background, output, bundles["sensors_weather"], coverage, weather, resources)
    write_stage(output, stage="04_evaluate", config=cfg, parents=parents, environment=environment, code=code)


def _joint_evaluation(background, output, bundle, coverage, weather, resources):
    import pandas as pd
    from .simulation import generate_scenarios, apply_overlays, attach_targets, heldout_objects
    from .features import build_features
    from .evaluation import _prepared
    scores, truths = {h: [] for h in HEADS}, {h: [] for h in HEADS}
    generator = replace(GeneratorConfig(), challenge="mixed_heads")
    for part in sorted((background / "daily").glob("*.parquet")):
        original = _read(part)
        heldout = heldout_objects(original)
        daily = original[(original[DAY] >= PARTITIONS["test"][0] - timedelta(days=30))
                         & (original[DAY] < PARTITIONS["test"][1])].copy()
        changed, episodes = daily, {}
        for head in HEADS:
            overlay, ep, audit = generate_scenarios(daily, head, generator, coverage, frozen_heldout=heldout)
            changed = apply_overlays(changed, overlay)
            episodes[head] = ep[ep.partition == "test"].copy()
            episodes[head]["heldout_object"] = episodes[head][OBJECT].isin(heldout)
        for head in HEADS:
            f = attach_targets(build_features(changed, head, coverage, weather=weather), episodes[head])
            f["heldout_object"] = f[OBJECT].isin(heldout)
            lo, hi = PARTITIONS["test"]
            f = f[(f.as_of_date >= lo) & (f.as_of_date + timedelta(days=4) <= hi)]
            scores[head].append(_narrow_score(f, bundle[head], resources))
            truths[head].append(episodes[head])
        del original, daily, changed, episodes
        gc.collect()
        check_resources(resources, output)
    combined = {}
    for head in HEADS:
        f, e = pd.concat(scores.pop(head), ignore_index=True), pd.concat(truths.pop(head), ignore_index=True)
        atomic_json(output / "metrics" / f"{head}_mixed_heads.json", _evaluate_cohorts(f, e, bundle[head], resources))
        _, _, alerts, _ = _prepared(f, e, bundle[head].threshold, 3, head)
        for alert in alerts:
            combined.setdefault(alert["issued_at"][:10], set()).add(alert[OBJECT])
    atomic_json(output / "mixed_heads_workload.json", {"unique_objects_by_issue_day": {d: len(v) for d, v in combined.items()},
                "scope": "one_shared_observation_history_with_five_simulated_incident_types",
                "evidence": scenario_evidence()})
