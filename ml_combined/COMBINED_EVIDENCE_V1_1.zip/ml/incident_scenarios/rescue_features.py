"""Frozen rescue transform shared by cached replay and daily inference."""
TRANSFORM_VERSION = "incident-rescue-causal-counts-v2"
HEADS = ("fire", "sensor_failure")
RAW_LOOKBACK_DAYS = 33


def build_transformed_day(daily, head, coverage, as_of_date):
    """Build exact calendar lags from daily facts; no persisted feature cache needed.

    Lagged counts use seven days, but their object-binding guard uses metadata
    carried for up to 30 days at D-3. Exact serving therefore needs D-32..D.
    Earlier eligibility is irrelevant; current-day eligibility stays canonical.
    """
    from datetime import timedelta
    import pandas as pd
    from .contracts import DAY, as_date
    from .daily import adapt_cached_panel
    from .features import build_features
    day = as_date(as_of_date)
    coverage.validate(day)
    coverage.validate(day - timedelta(days=3))
    data = adapt_cached_panel(daily)
    data = data[(data[DAY] >= day - timedelta(days=RAW_LOOKBACK_DAYS-1)) & (data[DAY] <= day)]
    current = build_features(data, head, coverage, as_of_date=day)
    if current.empty:
        return current
    frames = [current]
    # D-2 is not used by the frozen transform.
    for lag in (1, 3):
        previous = build_features(data, head, coverage, as_of_date=day - timedelta(days=lag))
        if not previous.empty:
            frames.append(previous)
    return transform_history(pd.concat(frames, ignore_index=True), head, as_of_date=day)
def transform_config(head):
    if head not in HEADS:
        raise ValueError("UNSUPPORTED_RESCUE_HEAD")
    signals = (["x_relevant_alarm_7d", "x_relevant_events_7d"] if head == "fire" else
               ["x_n_alarm_7d", "x_n_link_fault_7d", "x_n_power_off_7d", "x_n_tech_like_7d"])
    return {"version": TRANSFORM_VERSION, "head": head, "signals": signals,
            "calendar_lags": [1, 3], "drop_weather": True, "maximum_features": 64,
            "raw_history_days": 30, "required_base_dates": "D-3 through D; exact missing dates remain missing",
            "adapter_scope": "base feature history only; requires SDK integration before backend replacement"}
def _pandas(frame):
    import pandas as pd
    return pd.DataFrame(frame.to_dict(as_series=False)) if hasattr(frame, "to_dict") and frame.__class__.__module__.startswith("polars") else frame.copy()
def transform_history(base, head, as_of_date=None):
    """Causal calendar joins before eligibility filtering or training sampling."""
    import numpy as np
    import pandas as pd
    config = transform_config(head)
    out = _pandas(base)
    required = {"entity_key", "as_of_date", "incident_type", *config["signals"]}
    required.update(name.replace("_7d", "_30d") for name in config["signals"])
    if required - set(out):
        raise ValueError("BASE_FEATURES_MISSING:" + ",".join(sorted(required - set(out))))
    out["as_of_date"] = pd.to_datetime(out.as_of_date, errors="raise").dt.normalize()
    requested = None if as_of_date is None else pd.Timestamp(as_of_date).normalize()
    if requested is not None:
        out = out[(out.as_of_date <= requested) & (out.as_of_date >= requested - pd.Timedelta(days=29))].copy()
    if out.entity_key.isna().any() or out.as_of_date.isna().any() or (out.incident_type != head).any():
        raise ValueError("INVALID_BASE_FEATURE_KEYS")
    if out.duplicated(["entity_key", "as_of_date"]).any():
        raise ValueError("DUPLICATE_BASE_FEATURE_KEY")
    if any(c.startswith("x_rescue_") for c in out):
        raise ValueError("ALREADY_TRANSFORMED_FEATURES")
    out = out.drop(columns=[c for c in out if c.startswith("x_weather_")]).reset_index(drop=True)
    index = pd.MultiIndex.from_frame(out[["entity_key", "as_of_date"]])
    for signal in config["signals"]:
        current = pd.to_numeric(out[signal], errors="raise").to_numpy(dtype=float)
        lookup = pd.Series(current, index=index)
        short = signal.removeprefix("x_")
        for lag in config["calendar_lags"]:
            keys = pd.MultiIndex.from_arrays([out.entity_key, out.as_of_date - pd.Timedelta(days=lag)])
            previous = lookup.reindex(keys).to_numpy(dtype=float)
            guard = "x_relevant_channel_count" if head == "fire" else "d_object_key"
            if guard in out:
                old = pd.Series(out[guard].to_numpy(), index=index).reindex(keys).to_numpy()
                continuous = (old == out[guard].to_numpy()) & pd.notna(old)
                previous = np.where(continuous, previous, np.nan)
            difference = current - previous
            out[f"x_rescue_{short}_diff_{lag}d"] = difference
            out[f"x_rescue_{short}_relative_diff_{lag}d"] = difference / (1 + np.abs(previous))
        long = pd.to_numeric(out[signal.replace("_7d", "_30d")], errors="raise").to_numpy(dtype=float)
        out[f"x_rescue_{short}_ratio_7to30"] = current / (1 + np.abs(long))
    if head == "fire":
        out["x_rescue_relevant_alarm_rate_7d"] = out.x_relevant_alarm_7d / (1 + out.x_relevant_events_7d.abs())
        for signal in config["signals"]:
            out[f"x_rescue_{signal.removeprefix('x_')}_per_channel"] = out[signal] / (1 + out.x_relevant_channel_count.abs())
    features = [c for c in out if c.startswith("x_")]
    if len(features) > 64:
        raise ValueError("RESCUE_FEATURE_LIMIT_EXCEEDED")
    out[features] = out[features].apply(pd.to_numeric, errors="raise").astype(float).replace([np.inf, -np.inf], np.nan)
    if requested is not None:
        out = out[out.as_of_date == requested].copy()
    out["as_of_date"] = out.as_of_date.dt.date
    return out.sort_values(["as_of_date", "entity_key"]).reset_index(drop=True)
