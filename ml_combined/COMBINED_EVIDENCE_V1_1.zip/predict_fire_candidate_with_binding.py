"""Enabled experimental fire prediction; recommendations require manual review."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk-root', required=True)
    home=Path(__file__).resolve().parent
    parser.add_argument('--candidate-root', default=str(home/'fire_candidate' if (home/'fire_candidate').is_dir() else home))
    parser.add_argument('--daily', required=True)
    parser.add_argument('--coverage', required=True)
    parser.add_argument('--catalogue', help='Cutoff-valid Russian catalogue CSV for explicit raw object bindings')
    parser.add_argument('--as-of', required=True)
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--issued-at')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(args.sdk_root).resolve()))
    import numpy as np
    import pandas as pd
    from ml.incident_scenarios.artifacts import atomic_json
    from ml.incident_scenarios.bundle import artifact_fingerprint
    from ml.incident_scenarios.contracts import Coverage, forecast_times, scenario_evidence, ContractError
    from ml.incident_scenarios.models import HeadArtifact, predict_scores
    from ml.incident_scenarios.rescue_features import build_transformed_day, TRANSFORM_VERSION
    root = Path(args.candidate_root)
    manifest = json.loads((root/'manifest.json').read_text())
    for name, checksum in manifest['files'].items():
        if Path(name).name != name or hashlib.sha256((root/name).read_bytes()).hexdigest() != checksum:
            raise ContractError('FIRE_CANDIDATE_CHECKSUM_MISMATCH')
    artifact = HeadArtifact(**json.loads((root/'model.json').read_text()))
    if artifact.head != 'fire':
        raise ContractError('FIRE_CANDIDATE_HEAD_MISMATCH')
    times = forecast_times(args.as_of, args.issued_at, replay=args.replay)
    if times['late']:
        raise ContractError('LATE_RUN')
    daily = pd.DataFrame(json.loads(Path(args.daily).read_text(encoding='utf-8')))
    coverage = Coverage.from_dict(json.loads(Path(args.coverage).read_text()))
    frame = build_transformed_day(daily, 'fire', coverage, args.as_of)
    rows = []
    catalogue=None
    if args.catalogue:
        from ml.incident_scenarios.bindings import catalogue_rows
        catalogue=pd.read_csv(args.catalogue,dtype=str,keep_default_na=False)
        catalogue_rows(catalogue)
    if not frame.empty:
        valid = frame.eligible.astype(bool)
        frame['score'] = np.nan
        frame.loc[valid, 'score'] = predict_scores(artifact, frame.loc[valid, artifact.features])
        for _, row in frame.iterrows():
            eligible = bool(row.eligible)
            rows.append({'entity_key': row.entity_key, 'd_object_key': row.d_object_key,
                'incident_type': 'fire', 'eligible': eligible, 'score': float(row.score) if eligible else None,
                'threshold': artifact.threshold, 'above_threshold': bool(eligible and row.score >= artifact.threshold),
                'abstain_reason': None if eligible else row.abstain_reason,
                'model_version': artifact_fingerprint(artifact, TRANSFORM_VERSION), 'feature_version': TRANSFORM_VERSION,
                'model_maturity': 'post_test_adaptive_research_candidate', **times, **scenario_evidence()})
    output = {'enabled_heads': ['fire'], 'predictions': rows, 'raw_history_days': 33,
              'default_activation_allowed': True,
              'activation_scope': 'experimental_manual_review',
              'ui_visibility': 'visible_experimental',
              'operational_ready': False, 'automated_action_allowed': False,
              **times, **scenario_evidence()}
    if catalogue is not None:
        from ml.incident_scenarios.bindings import bind_predictions
        bind_predictions(output,catalogue)
    atomic_json(args.output, output)
    print(json.dumps({'status': 'completed', 'predictions': len(rows), 'operational_ready': False}))


if __name__ == '__main__':
    main()
