# Fire capacity research v4

Registered after v3 found no admissible threshold, before fitting or reading new fire test predictions.

Hypothesis: a seven-leaf tree is too restrictive for heterogeneous object-level fire precursor patterns. Change only LightGBM num_leaves from 7 to 15. Preserve 150 trees, learning_rate=.05, min_child_samples=20, four CPU threads, seed, cached data, causal features, train-only preprocessing, CAL Platt fit, labels, partitions and cooldown. One model; no hyperparameter grid.

Use original TRAIN 2022–2023, CAL 2024 H1, DEV 2024 H2, TEST 2025. Held-out objects do not enter fitting, preprocessing, calibration or development threshold selection. Synthetic onset target [D+3,D+4), object-day. No data regeneration.

Apply exactly the v3 development-constrained policy: maximum development event F1 among original 201-quantile thresholds meeting TP>=5, precision>=.20, recall>=.20 and F1>=original baseline development F1+.02. Tie: higher threshold. If none passes, stop before test. The unconstrained F1-optimal threshold is reported for diagnostics only.

Save candidate, calibrator, development grid, chosen threshold and registration hashes before test access. Evaluate one frozen selected artifact once on 2025 all/seen/held-out cohorts with 200 block-bootstrap replicates and fixed 5/25 object attention budgets. Internal exploratory test screen: TP>=10, P>=.20, R>=.20, F1>=original baseline test F1+.02. No default activation on a failed screen. Do not select another model or threshold using test.

This is post-test-adaptive E4 scenario research, not independent confirmation or real fire validation. Earlier baseline 2025 results are known. Preserve failed v2/v3 results. No claim of full robustness; H2 and accepted sensor package remain unchanged. One local cached-panel run under a hard 10-minute process deadline; save trained candidate before evaluation.
