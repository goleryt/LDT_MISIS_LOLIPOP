# Газовый proxy v3 — bundle для backend (experimental_shadow)

score будущего наблюдаемого строгого пересечения газового порога 1 % снизу вверх в [D+2; D+3) по данным до конца D; не вероятность пожара и не подтверждённый инцидент.

```python
from predictor import load_bundle, build_features, predict
bundle = load_bundle('.')
records = build_features(['journal_extract.csv'], 'catalogue.csv', '2026-09-24', bundle)
results = predict(records, bundle)
```

- Рецепт: `refit_2025h1`; train D < 2025-01-01, d_label_decision_end ≤ 2025-01-01; калибровка [2025-01-01; 2025-07-01), decision_end ≤ 2025-07-01.
- Признаков: 97 (список и типы — `feature_contract.json`); история журнала ≥ 400 суток до D.
- Eligibility: f_gas_n_7d > 0 and f_gas_last is not null and f_gas_last < gas_threshold_percent; иначе `abstain` с причиной.
- Audit ([2025-07-01; 2026-01-01), decision_end ≤ 2026-01-01): PR-AUC G2 0.352 против правила 0.059; 25/сутки с cooldown: precision 0.034–0.531, доля неизвестных исходов среди оповещений 0.497.
- `operational_ready = false`: автоматические заявки по score выключены; бюджет и cooldown — на backend.
- Файлы: `model.txt` (LightGBM), `bundle.json` (калибровка, контракт), `predictor.py`, `features_v3/` (код признаков ноутбука 14 и таксономия), `SHA256SUMS.json`.
